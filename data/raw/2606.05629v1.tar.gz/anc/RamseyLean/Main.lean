import RamseyLean

def main : IO Unit :=
  IO.println "RamseyLean formalization loaded."
