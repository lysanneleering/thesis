theory ChurchTTinHOML imports HOMLinHOL 
begin
\<comment>\<open>Further concepts: One world; as expected this is needed for proving Boolean extensionality\<close> 
  abbreviation "OneWorld \<equiv> \<forall>x::i. \<forall>y::i. x = y"
\<comment>\<open>Proof theory/metatheory of HO(M)L (embedded in HOL): here we prove core principles of Church's Type Theory\<close> 
  lemma ModPon:                        "\<lfloor>\<phi> \<^bold>\<supset> \<psi>\<rfloor> \<Longrightarrow> \<lfloor>\<phi>\<rfloor> \<Longrightarrow> \<lfloor>\<psi>\<rfloor>"                     by simp
  lemma Gen:                              "\<forall>x. \<lfloor>\<Phi>(x)\<rfloor> \<Longrightarrow> \<lfloor>\<^bold>\<forall>x. \<Phi>(x)\<rfloor>"                    by simp
  lemma Ax1:                               "\<lfloor>(\<phi> \<^bold>\<or> \<phi>) \<^bold>\<supset> \<phi>\<rfloor>"                                      by simp
  lemma Ax2:                               "\<lfloor>\<phi> \<^bold>\<supset> (\<phi> \<^bold>\<or> \<phi>)\<rfloor>"                                      by simp
  lemma Ax3:                               "\<lfloor>(\<phi> \<^bold>\<or> q) \<^bold>\<supset> (q \<^bold>\<or> \<phi>)\<rfloor>"                             by simp
  lemma Ax4:                               "\<lfloor>(\<phi> \<^bold>\<supset> q) \<^bold>\<supset> ((r \<^bold>\<or> \<phi>) \<^bold>\<supset> (r \<^bold>\<or> q))\<rfloor>"           by simp
  lemma Ax5\<alpha>:                            "\<lfloor>(\<^bold>\<forall>x. \<Phi>(x)) \<^bold>\<supset> \<Phi>(x)\<rfloor>"                              by simp
  lemma Ax6\<alpha>:                            "\<lfloor>(\<^bold>\<forall>x. \<phi> \<^bold>\<or> \<Phi>(x)) \<^bold>\<supset> (\<phi> \<^bold>\<or> (\<^bold>\<forall>x. \<Phi>(x)))\<rfloor>"     by simp
  lemma Ax7\<alpha>\<beta>:                          "\<lfloor>(\<^bold>\<forall>x. ((f x) \<^bold>= (g x))) \<^bold>\<supset> (f \<^bold>= g)\<rfloor>"            by auto
  lemma Ax7\<sigma>:  assumes 1: OneWorld shows   "\<lfloor>(\<phi> \<^bold>\<leftrightarrow> \<psi>) \<^bold>\<supset> (\<phi> \<^bold>= \<psi>)\<rfloor>"
    proof (intro allI impI ext) fix w v assume "(\<phi> \<^bold>\<leftrightarrow> \<psi>) w" with 1 show "\<phi> v = \<psi> v" by smt qed
  lemma Ax7\<sigma>tr:                         "\<lfloor>(\<phi> \<^bold>= \<psi>) \<^bold>\<supset> (\<phi> \<^bold>\<leftrightarrow>  \<psi>)\<rfloor>"                             by simp
\<comment>\<open>Relative consistency: obvious/trivial, since no single axiom was introduced\<close>
  lemma MetaConsistency:             True                                    nitpick[satisfy,user_axioms,expect=genuine] oops
  lemma AbsoluteConsistency:       "\<exists>\<phi>. \<not>\<lfloor>\<phi>\<rfloor>"                          by auto
  lemma ConsistentWrtNegation:   "\<not>(\<exists>\<phi>. \<lfloor>\<phi>\<rfloor> \<and> \<lfloor>\<^bold>\<not> \<phi>\<rfloor>)"          by auto
\<comment>\<open>Formalized notions: equipollence, cardinality, different notion of infinity\<close>
  abbreviation Ex1B  (binder "\<^bold>\<exists>\<^sub>1" [8]9) where "\<^bold>\<exists>\<^sub>1x. \<Phi>(x) \<equiv> (\<^bold>\<exists>x. \<Phi>(x) \<^bold>\<and> (\<^bold>\<forall>z. \<Phi>(z) \<^bold>\<supset> (z \<^bold>= x)))" 
  definition "Equipollent \<equiv> (\<lambda>p::'a\<Rightarrow>\<sigma>. \<lambda>q::'b\<Rightarrow>\<sigma>. (\<^bold>\<exists>s. (\<^bold>\<forall>x. p x \<^bold>\<supset> q (s x)) \<^bold>\<and> (\<^bold>\<forall>y. q y \<^bold>\<supset> (\<^bold>\<exists>\<^sub>1x. p x \<^bold>\<and> (y \<^bold>= s x)))))"
  definition "Cardinality \<equiv> (\<lambda>p::'b\<Rightarrow>\<sigma>. Equipollent p)"
  definition "CardinalNumbers  \<equiv> (\<lambda>u::(('b\<Rightarrow>\<sigma>)\<Rightarrow>\<sigma>) . (\<^bold>\<exists>p::('b\<Rightarrow>\<sigma>). (u \<^bold>= (Equipollent p))))"
  definition "Inf0 \<equiv> \<^bold>\<exists>r::e\<Rightarrow>e\<Rightarrow>\<sigma>. \<^bold>\<forall>x y z. ((\<^bold>\<exists>w. r x w) \<^bold>\<and> \<^bold>\<not> (r x x) \<^bold>\<and> (r x y \<^bold>\<supset> (r y z \<^bold>\<supset> r x z)))"
  definition "Inf1 \<equiv> \<^bold>\<exists>n::e\<Rightarrow>\<sigma>. \<^bold>\<exists>m::e\<Rightarrow>\<sigma>. (\<^bold>\<forall>x. m x \<^bold>\<supset> n x) \<^bold>\<and> (\<^bold>\<exists>u. n u \<^bold>\<and> \<^bold>\<not>(m u)) \<^bold>\<and> (Equipollent n m)"
  definition "Inf2 \<equiv> \<^bold>\<exists>n::e\<Rightarrow>\<sigma>.\<^bold>\<exists>u.\<^bold>\<exists>s. n u \<^bold>\<and> (\<^bold>\<forall>x. n x \<^bold>\<supset> n (s x)) \<^bold>\<and> (\<^bold>\<forall>x. n x \<^bold>\<supset> (s x)\<^bold>\<noteq>u) \<^bold>\<and> (\<^bold>\<forall>x y. (n x \<^bold>\<and> n y \<^bold>\<and> s x\<^bold>=s y) \<^bold>\<supset> x\<^bold>=y)"
\<comment>\<open>Definitions/abbreviations for modalised natural numbers (modeled as analysable objects naturally contained in HOL)\<close>
  named_theorems Nat
  definition Zero ("\<zero>") where [Nat]:                "\<zero> \<equiv> ((\<^bold>=) (\<lambda>x. \<^bold>\<bottom>))"
  definition Succ ("\<S>") where [Nat]:               "\<S> \<equiv> (\<lambda>n. \<lambda>p. (\<^bold>\<exists>x. p x \<^bold>\<and> (n (\<lambda>t. (t \<^bold>\<noteq> x) \<^bold>\<and> p t))))"
  definition Naturals ("\<nat>") where [Nat]:         "\<nat> \<equiv> (\<lambda>n. (\<^bold>\<forall>p. (p \<zero> \<^bold>\<and> (\<^bold>\<forall>x. p x \<^bold>\<supset> p (\<S> x))) \<^bold>\<supset> p n))"
  definition Finite ("\<F>\<i>\<n>\<i>\<t>\<e>") where [Nat]:       "\<F>\<i>\<n>\<i>\<t>\<e> \<equiv> (\<lambda>p. (\<^bold>\<exists>n. \<nat> n \<^bold>\<and> n p))"
end



