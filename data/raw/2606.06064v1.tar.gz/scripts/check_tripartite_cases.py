#!/usr/bin/env python3
"""Optional MILP audit for the finite tripartite internal-edge bounds.

This script is not part of the proof in the manuscript. It independently checks
small cases of the following problem. Fix D=T_3 with parts of sizes p,q,r and
let E contain all D-cross-edges except m missing cross-edges. How many internal
E-edges can be added while E remains K_5-free?

Requires scipy >= 1.9 with scipy.optimize.milp.
"""
from __future__ import annotations
from itertools import combinations
import numpy as np
from scipy import optimize
from scipy import sparse


def max_internal_edges(sizes: tuple[int, int, int], missing_cross: tuple[tuple[tuple[int, int], tuple[int, int]], ...]) -> int:
    parts = [[(a, i) for i in range(sizes[a])] for a in range(3)]
    vertices = [v for part in parts for v in part]
    missing = {tuple(sorted(edge)) for edge in missing_cross}

    var_edges = []
    for a in range(3):
        for i, j in combinations(range(sizes[a]), 2):
            var_edges.append(tuple(sorted(((a, i), (a, j)))))
    edge_to_var = {edge: k for k, edge in enumerate(var_edges)}
    nvar = len(var_edges)

    rows, cols, data, lower, upper = [], [], [], [], []
    row = 0

    def add_constraint(indices: list[int], ub: int) -> None:
        nonlocal row
        for idx in indices:
            rows.append(row)
            cols.append(idx)
            data.append(1.0)
        lower.append(-np.inf)
        upper.append(float(ub))
        row += 1

    for S in combinations(vertices, 5):
        S = set(S)
        # A missing cross-edge already blocks this 5-set.
        blocked = False
        for u, v in combinations(S, 2):
            if u[0] != v[0] and tuple(sorted((u, v))) in missing:
                blocked = True
                break
        if blocked:
            continue
        internal_vars = []
        for u, v in combinations(S, 2):
            if u[0] == v[0]:
                internal_vars.append(edge_to_var[tuple(sorted((u, v)))])
        # Not all internal edges inside the 5-set may be present.
        add_constraint(internal_vars, len(internal_vars) - 1)

    A = sparse.coo_matrix((data, (rows, cols)), shape=(row, nvar)).tocsr()
    constraints = optimize.LinearConstraint(A, np.array(lower), np.array(upper))
    result = optimize.milp(
        c=-np.ones(nvar),
        integrality=np.ones(nvar),
        bounds=optimize.Bounds(0, 1),
        constraints=constraints,
        options={"disp": False},
    )
    if not result.success:
        raise RuntimeError(result.message)
    return int(round(-result.fun))


def cross_edges(sizes: tuple[int, int, int]) -> list[tuple[tuple[int, int], tuple[int, int]]]:
    edges = []
    for a, b in [(0, 1), (0, 2), (1, 2)]:
        for i in range(sizes[a]):
            for j in range(sizes[b]):
                edges.append(tuple(sorted(((a, i), (b, j)))))
    return edges


def audit_case(sizes: tuple[int, int, int], max_m: int = 2) -> None:
    print(f"sizes={sizes}")
    edges = cross_edges(sizes)
    for m in range(max_m + 1):
        best = -1
        best_missing = None
        for missing in combinations(edges, m):
            value = max_internal_edges(sizes, missing)
            if value > best:
                best = value
                best_missing = missing
        print(f"  m={m}: max x={best}, example missing={best_missing}")


def main() -> None:
    for sizes in [(4, 4, 4), (5, 5, 4), (6, 5, 5), (5, 5, 5), (6, 6, 5), (6, 6, 6), (7, 6, 6), (7, 7, 6)]:
        audit_case(sizes, max_m=2)


if __name__ == "__main__":
    main()
