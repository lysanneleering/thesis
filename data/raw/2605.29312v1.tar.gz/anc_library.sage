#
# ExperimentalLibrary.sage ---> anc_library.sage
#
# Akira Kurihara
#



###
from time import time, gmtime, localtime, strftime



##################################################
#
# xjacobi_symbol(k,d)
#
##################################################



#
#
# returns the symbol [ k / d ]
#
# d >= 1
# k integer
# we assume gcd(k,d)=1
#


###
def xjacobi_symbol(k,d):
    if d%2==1:
        return jacobi_symbol(k,d)
    elif d%4==2:
        return 1
    else:
        return (-1)^((k-1)/2)
#



##################################################
#
# ratioxrm1(p,red)
# checkLemma6(p)
#
# ratio = det M_{p,r,e,d}(x^r-1) / Delta(x^r-1)^(g/2)
#
# xrm1 = "x^r - 1"
#
##################################################



#
# returns the RHS of Lemma 6
#
# red in U(p) | (r|p-1)
#
# assume p >= 3
#
# f(x) = x^r -1
#



###
def ratioxrm1(p,red):
    F=GF(p)
    #
    r=red[0]
    e=red[1]
    d=red[2]
    s=(p-1)/r
    ghalf=(e*d-s*(d*(d+1)/2))/(r-1)
    #
    fact1=F(-1)^(d*(d-1)/2)
    fact2=F(-1)^((r-1)*ghalf)
    #
    # looks like F(binomial(e-p,*)) is a little bit faster than F(binomial(e,*)) 
    #
    EMP=e-p
    fact3=prod(F(binomial(EMP,i*s)) for i in range(1,d+1))
    detM=fact1*fact2*fact3
    #
    fact4=F(-1)^((r-1)*(r-2)/2)
    fact5=F(r)^r
    Delta=fact4*fact5
    #
    ratio=detM/Delta^ghalf
    #
    return ratio
#



#
# check Lamma 6
#



###
def checkLemma6(p):
    #
    F=GF(p)
    R=PolynomialRing(F,'x')
    xe=R.gens()
    x=xe[0]
    #
    OK=True
    for red in Uprdivpm1(p):
        #
        r=red[0]
        e=red[1]
        d=red[2]
        s=(p-1)/r
        ghalf=(e*d-s*(d*(d+1)/2))/(r-1)
        #
        fx=x^r-1
        fxe=fx^e
        Coeff=fxe.coefficients(sparse=False)
        Mat=matrix(d,d,lambda i,j:Coeff[p*i+j+p-d] if p*i+j+p-d<=r*e else F(0))
        detM=Mat.determinant()
        #
        Delta=F(-1)^((r-1)*(r-2)/2)*F(r)^r
        #
        ratio1=detM/Delta^ghalf
        #
        ratio2=ratioxrm1(p,red)
        #
        ans=(ratio1==ratio2)
        OK=OK and ans
    #
    return OK
#



##################################################
#
# B0p(p)
# BMinusp(p)
# BPlusp(p)
# Bp(p)
#
# is_B0p(p,red)
# is_BMinusp(p,red)
# is_BPlusp(p,red)
# is_Bp(p,red)
#
##################################################



#
# returns the list of red = [r,e,d] of B0(p)
#
# 2 <= r <= p+1
# max(floor((p+1)/2),ceil((p-1)*(r-1)/r)) <= e <= p-1
# d = r-1
#



###
def B0p(p):
    TheList=[]
    for r in range(2,p+2):
        emin=max(floor((p+1)/2),ceil((p-1)*(r-1)/r))
        for e in range(emin,p):
            d=r-1
            red=[r,e,d]
            TheList.append(red)
    #
    return TheList
#



#
# returns B_{-}(p)
#
# 3 <= r
# r | p-1, put rs = p-1
#
# e = (r-1)s
# d = r-2
#



###
def BMinusp(p):
    TheList=[]
    Div=divisors(p-1)
    for r in Div:
        if r >= 3:
            s=(p-1)/r
            e=(r-1)*s
            d=r-2
            red=[r,e,d]
            TheList.append(red)
    #
    return TheList
#



#
# returns B_{+}(p)
#
# 2 <= r <= p
# e = p-1
# d = r
#



###
def BPlusp(p):
    TheList=[]
    e=p-1
    for r in range(2,p+1):
        d=r
        red=[r,e,d]
        TheList.append(red)
    #
    return TheList
#



#
# returns B(p)
#



###
def Bp(p):
    L0=B0p(p)
    LM=BMinusp(p)
    LP=BPlusp(p)
    L0.extend(LM)
    L0.extend(LP)
    L0.sort()
    return L0
#



#
# returns whether or not [r,e,d] is in B_0(p)
#
# red is in Z^3
#



###
def is_B0p(p,red):
    r=red[0]
    e=red[1]
    d=red[2]
    #
    emin=max(floor((p+1)/2),ceil((p-1)*(r-1)/r))
    #
    if (2 <= r <= p+1) and (emin <= e <= p-1) and d==r-1:
        ans=True
    else:
        ans=False
    #
    return ans
#



#
# returns whether or not [r,e,d] is in B_{-}(p)
#
# red is in Z^3
#



###
def is_BMinusp(p,red):
    r=red[0]
    e=red[1]
    d=red[2]
    #
    if (3<=r) and ((p-1)%r == 0):
        s=(p-1)/r
        if e == (r-1)*s and d == r-2:
            ans=True
        else:
            ans=False
    else:
        ans=False
    #
    return ans
#



#
# returns whether or not [r,e,d] is in B_{+}(p)
#
# red is in Z^3
#



###
def is_BPlusp(p,red):
    r=red[0]
    e=red[1]
    d=red[2]
    #
    if (2 <= r <= p) and e==p-1 and d==r:
        ans=True
    else:
        ans=False
    #
    return ans
#



#
# returns whether or not [r,e,d] is in B(p)
#
# red is in Z^3
#



###
def is_Bp(p,red):
    return is_B0p(p,red) or is_BMinusp(p,red) or is_BPlusp(p,red)
#



##################################################
#
# proveTheorem3(p)
# does_survive(p,rede,fx)
#
##################################################



#
# try to prove Theorem 3 for p
#
# p >= 3
#



###
def proveTheorem3(p):
    print("-----(( p =",p,strftime("  %Y-%m-%d %H:%M:%S",localtime()),"))-----")
    sys.stdout.flush()
    #
    F=GF(p)
    p1div=divisors(p-1)
    #
    C1nonB=[]
    C2nonB=[]
    C3nonB=[]
    C4nonB=[]
    #
    # C1nonB
    #
    for r in p1div:
        if r >= 2:
            s=(p-1)/r
            for ell in range(1,s+1):
                e=s+(r-1)*ell
                d=1
                red=[r,e,d]
                if not(is_Bp(p,red)):
                    C1nonB.append(red)
    C1nonB.sort()
    #
    # C2nonB
    #
    for r in p1div:
        if r >= 2:
            t=ZZ(p-1)/ZZ(r*(r-1))
            if t in ZZ:
                for d in range(2,r+1):
                    for ell in range(d*t,r*t+1):
                        e=(r-1)*ell
                        red=[r,e,d]
                        if not(is_Bp(p,red)):
                            C2nonB.append(red)
    C2nonB.sort()
    #
    # C3nonB
    #
    for r in p1div:
        if r >= 3:
            s=(p-1)/r
            t=ZZ(p+1)/ZZ(r-1)
            if t in ZZ:
                for d in range(2,r):
                    for ell in range(d*(t-s),t+1):
                        e=(r-1)*ell-(d+1)
                        red=[r,e,d]
                        if not(is_Bp(p,red)):
                            C3nonB.append(red)
    C3nonB.sort()
    #
    # C4nonB
    #
    # The following 1 Line Modified on 2021-12-08 according to the below
    #
    AList=[]
    #
    # The above 1 Line Modified on 2021-12-08 according to the below
    #
    for r in p1div:
        if r >= 3:
            s=(p-1)/r
            d=r-2
            boundP=floor(s/(r-1))
            boundM=-boundP
            if r==3:
                boundM+=1
            for ell in range(boundM,boundP+1):
                e=(r-1)*(s+ell)
                red=[r,e,d]
                ##################################################
                #
                # The following part is modified on 2021-12-08
                #
                ##################################################
                #
                #if not(is_Bp(p,red)) and not(red in C1nonB) and not(red in C2nonB) and not(red in C3nonB):
                #    C4nonB.append(red)
                #
                if not(is_Bp(p,red)):
                    AList.append(red)
    #
    AList.sort()
    BList=C1nonB+C2nonB+C3nonB
    BList.sort()
    AMinusB=[]
    lenA=len(AList)
    lenB=len(BList)
    apos=0
    bpos=0
    #
    while apos<lenA and bpos<lenB:
        ared=AList[apos]
        bred=BList[bpos]
        if ared<bred:
            AMinusB.append(ared)
            apos+=1
        elif bred<ared:
            bpos+=1
        else:
            apos+=1
            bpos+=1
    #
    while apos<lenA:
        ared=AList[apos]
        AMinusB.append(ared)
        apos+=1
    #
    #C4nonB.sort()
    #if AMinusB==C4nonB:
    #    print("p =",p,"AMinusB = C4nonB ----- OK -----")
    #else:
    #    print("p =",p,"AMinusB = C4nonB ===== XXXXX ERROR XXXXX =====")
    #
    C4nonB=AMinusB
    ##################################################
    #
    # The above part is modified on 2021-12-08
    #
    ##################################################
    C4nonB.sort()
    #
    #
    print("-----( CinonB (",len(C1nonB),len(C2nonB),len(C3nonB),len(C4nonB),"))-----")
    sys.stdout.flush()
    #
    C1234nonB=[C1nonB,C2nonB,C3nonB,C4nonB]
    #
    print("-----( x^r - 1 )",end="")
    #
    countloc=0
    for CinonB in C1234nonB:
        for red in CinonB:
            red.append(ratioxrm1(p,red))
            countloc+=1
            if countloc%10000==0:
                print("+",end="")
                sys.stdout.flush()
            elif countloc%1000==0:
                print("-",end="")
                sys.stdout.flush()
    #if countloc>=1000:
    #    print()
    #    sys.stdout.flush()
    print()
    sys.stdout.flush()
    #
    ####################
    #
    # test by x^r - x
    #
    ####################
    Surv1=[]
    #
    print("-----( x^r - x )",end="")
    #
    i=1
    countloc=0
    for CinonB in C1234nonB:
        for red in CinonB:
            r=red[0]
            e=red[1]
            d=red[2]
            g=(r*e*d-(p-1)*(d*(d+1)/2))/(r*(r-1)/2)
            EMP=e-p
            #
            if i==1:
                s=(p-1)/r
                ell=(e-s)/(r-1)
                detM=F(-1)^(r*(g/2)) * F(binomial(EMP,s-ell))
            elif i==2:
                t=(p-1)/(r*(r-1))
                ell=e/(r-1)
                detM=F(-1)^(r*(g/2)+(d*(d-1)/2)) * prod(F(binomial(EMP,r*t*i-ell)) for i in range(1,d+1))
            elif i==3:
                s=(p-1)/r
                t=(p+1)/(r-1)
                ell=(e+d+1)/(r-1)
                detM=F(-1)^(r*(g/2)) * prod(F(binomial(EMP,t*i-ell)) for i in range(1,d+1))
            elif i==4:
                s=(p-1)/r
                ell=e/(r-1)-s
                fact1=F(-1)^(r*(g/2))
                fact2=F(xjacobi_symbol(-p,r-1))
                fact3=prod(F(binomial(EMP,ceil((i*p-d)/(r-1))-s-ell)) for i in range(1,d+1))
                detM=fact1*fact2*fact3
            #
            Delta=F(-1)^((r+1)*(r+2)/2) * F(r-1)^(r-1)
            DeltaPow=Delta^(g/2)
            #
            rat=detM/DeltaPow
            #
            if red[3]==rat:
                Surv1.append(red)
            #
            countloc+=1
            if countloc%10000==0:
                print("+",end="")
                sys.stdout.flush()
            elif countloc%1000==0:
                print("-",end="")
                sys.stdout.flush()
            #
        i+=1
    #
    #if countloc>=1000:
    #    print()
    #    sys.stdout.flush()
    print()
    sys.stdout.flush()
    #
    Surv1.sort()
    #
    #print("survived1",Surv1)
    #
    R=PolynomialRing(F,'x')
    xe=R.gens()
    x=xe[0]
    #
    ####################
    #
    # test by x^r + x^k + 1 (r > k > 0)
    #
    ####################
    Surv2=[]
    for rede in Surv1:
        r=rede[0]
        e=rede[1]
        d=rede[2]
        ra=rede[3]
        #
        survived=True
        k=1
        #
        while(survived==True and k<r):
            print("-----( T2",r,">",k,"> 0 )-----( r =",r,"e =",e,"d =",d,")-----")
            sys.stdout.flush()
            fx=x^r+x^k+1
            resul=does_survive(p,rede,fx)
            if resul:
                k+=1
            else:
                survived=False
        #
        if survived:
            Surv2.append(rede)
    #
    #print("survived2",Surv2)
    ####################
    #
    # test by x^r + x^k + x (r > k > 1)
    #
    ####################
    Surv3=[]
    for rede in Surv2:
        r=rede[0]
        e=rede[1]
        d=rede[2]
        ra=rede[3]
        #
        survived=True
        k=2
        #
        while(survived==True and k<r):
            print("-----( T3",r,">",k,"> 1 )-----( r =",r,"e =",e,"d =",d,")-----")
            sys.stdout.flush()
            fx=x^r+x^k+x
            resul=does_survive(p,rede,fx)
            if resul:
                k+=1
            else:
                survived=False
        #
        if survived:
            Surv3.append(rede)
    #
    #print("survived3",Surv3)
    ###################
    #
    # test by x^r + a x + b
    #
    ###################
    Surv4=[]
    for rede in Surv3:
        r=rede[0]
        e=rede[1]
        d=rede[2]
        ra=rede[3]
        #
        survived=True
        ##################################
        # 1 <= a <= bound, 1 <= b <= bound
        ##################################
        bound=10
        a=1
        b=1
        #
        while(survived==True and a<=bound):
            print("-----( T4 r =",r,"a =",a,"b =",b,")-----( r =",r,"e =",e,"d =",d,")-----")
            sys.stdout.flush()
            fx=x^r+F(a)*x+F(b)
            resul=does_survive(p,rede,fx)
            if resul:
                if b<bound:
                    b+=1
                else:
                    a+=1
                    b=1
            else:
                survived=False
        #
        if survived:
            Surv4.append(rede)
    #
    #print("survived4",Surv4)
    #
    print(p," ",len(C1nonB),len(C2nonB),len(C3nonB),len(C4nonB)," ",len(Surv1),len(Surv2),len(Surv3),len(Surv4))
    sys.stdout.flush()
    #
    return True
#



#
# check whether or not red survives the test by fx
#



###
def does_survive(p,rede,fx):
    F=GF(p)
    #
    r=rede[0]
    e=rede[1]
    d=rede[2]
    ra=rede[3]
    #
    # the original one
    #
    #fxe=fx^e
    #TheCoefficientList=fxe.coefficients(sparse=False)
    #M=matrix(d,d,lambda i,j: TheCoefficientList[p*i+j+p-d] if p*i+j+p-d<=r*e else F(0))
    #detM=M.determinant()
    #
    # the original one
    #
    #
    # 2022-01-08
    # compute fx^e mod x^(dp)
    #
    # p=149057
    # r=9316
    # e=149056
    # d=1
    #
    R=PolynomialRing(F,'x')
    xe=R.gens()
    x=xe[0]
    #
    I=R.ideal(x^(d*p))
    RI=QuotientRing(R,I)
    xeI=RI.gens()
    xI=xeI[0]
    #
    fxI=RI(fx)
    # this is fancy
    e=ZZ(e)
    fxIe=fxI^e
    TheCoefficientListI=fxIe.list()
    lenCI=len(TheCoefficientListI)
    MI=matrix(d,d,lambda i,j: TheCoefficientListI[p*i+j+p-d] if p*i+j+p-d<lenCI else F(0))
    detMI=MI.determinant()
    #
    #if M!=MI:
    #    print("========== ========== XXXXXXXXXX XXXXXXXXXX ERROR XXXXXXXXXX XXXXXXXXXX ========== ==========")
    #
    detM=detMI
    #
    # 2022-01-08
    # compute fx^e mod x^(dp)
    #
    Delta=fx.discriminant()
    #
    if detM==F(0):
        if Delta==F(0):
            ans=True
        else:
            ans=False
    else:
        if Delta==F(0):
            ans=False
        else:
            g=(r*e*d-(p-1)*(d*(d+1)/2))/(r*(r-1)/2)
            DeltaPow=Delta^(g/2)
            rat=detM/DeltaPow
            if not(rat in F):
                ans=False
            else:
                if ra==rat:
                    ans=True
                else:
                    ans=False
    #
    return ans
#



##################################################
#
# kappaAndMore(s,ell)
#
##################################################



#
# create Table 2
#
# 1 <= ell <= s
#



###
def kappaAndMore(s,ell):
    #
    fact1=(-1/(s+1))^ell
    fact2=prod(ell+i*s for i in range(0,ell))
    fact3=prod(s-i for i in range(0,ell))
    kappa=fact1*fact2/fact3
    #
    print("kappa =",kappa)
    print()
    K=kappa^s-1
    N=K.numerator()
    absN=abs(N)
    absNfac=absN.factor()
    faclen=len(absNfac)
    for i in range(0,faclen):
        p=absNfac[i][0]
        if (p-1)%s==0:
            r=(p-1)/s
            if r>=2:
                KK=kappa-fact1^r
                NN=KK.numerator()
                if NN%p==0:
                    e=s+(r-1)*ell
                    d=1
                    red=[r,e,d]
                    if is_B0p(p,red):
                        where="B0"
                    elif is_BPlusp(p,red):
                        where="B+"
                    elif is_BMinusp(p,red):
                        where="B-"
                    else:
                        where="nonB"
                    print("p =",p,"red =",red,where)
#



####################################################################################################
#
#
# ( the duality concerning Delta in characteristic p )
#
#
# p prime
#
#
# E(p) is the set of (r,e,d) such that
#
# r >= 2, 0 <= e <= p-1, 0 <= d <= r-1
#
# d <= p, r-1-d <= p
#
# d(p-1) <= re <= (d+1)(p-1)
#
#
# (r,e,d) in E(p) ===> r <= 2p+1
#
#
# ehat = (p-1) - e
#
# dhat = (r-1) - d
#
#
# Then,
#
#           E(p)  ------>  E(p) 
#
#         (r,e,d) |-----> (r,ehat,dhat)
#
# is an involutive bijection
# 
# d(p-1) <= re <= (d+1)(p-1)  <=====> dhat(p-1) <= r ehat <= (dhat+1)(p-1)
#
#
# f(x) = s0 x^r + s1 x^(r-1) + ... + sr
#
# Md( f(x)^e ) = ( f(x)^e [ x^(ip+j+p-d) ] )
#                                            0 <= i, j <= d-1
#
# Here [x^n] means the coefficient of x^n
#
# Delta(f(x)) is the discriminant of f(x)
#
# Then, the duality concerning Delta
#
#
#                   det Md( f(x)^e )
# -------------------------------------------------- = epsilon_pred det Mdhat( f(x)^ehat )
#  s0^( d(p-1)-(r-1)e ) Delta( f(x) )^( e-(p-1)/2 )
#
#
# epsilon_pred = (-1)^( r(r+1)/2 (1+e) + (r+1) d ) ( (d+1)(p-1) - re )! e!^r
#
#
# We have
#
# { e - (p-1)/2 } + { ehat - (p-1)/2 } = 0
#
# { d(p-1)-(r-1)e } + { dhat(p-1)-(r-1)ehat } = 0
#
# epsilon_p r e d * epsilon_p r ehat dhat =1
#
#
# For the degree such that deg(si) = i (non-homogeneous degree)
#
# { red - d(d+1)/2 (p-1) } - r(r-1)( e - (p-1)/2 ) = r ehat dhat - dhat(dhat+1)/2 (p-1)
#
#
# For the degree such that deg(si) = 1 (homogeneous degree)
#
# ed - 2(r-1)(e-(p-1)/2) -{ d (p-1) - (r-1) e } = ehat dhat
#
#
# { red in E(p | e-(p-1)/2 > 0 ) = D(p) \ D0(p)
#
#
# when e-(p-1)/2 > 0,
#
# the divisibility of detMd(f(x)^e) by Delta(f(x))^(e-(p-1)/2) is proved
#
# when d(p-1)-(r-1)e > 0,
#
# the divisibility of detMd(f(x)^e) by s0^(d(p-1)-(r-1)e) is proved
#
# when e = (p-1)/2, the equality can be proved
#
#
####################################################################################################



#
# E(p)
#
# r >= 2, 0 <= e <= p-1, 0 <= d <= r-1
#
# d <= p, r-1-d <= p
#
# d(p-1) <= re <= (d+1)(p-1)
#
#
# hence, r <= 2p + 1
#



###
def Ep(p):
    lis=[]
    #
    for r in range(2,2*p+1+1):
        for e in range(0,p):
            for d in range(0,r):
                if d<=p and r-1-d<=p and d*(p-1)<=r*e<=(d+1)*(p-1):
                    lis.append([r,e,d])
                #
            #
        #
    #
    return lis
#



###
def is_Ep(p,red):
    r=red[0]
    e=red[1]
    d=red[2]
    #
    cond1=(r>=2) and (0<=e<=p-1) and (0<=d<=r-1)
    cond2=(d<=p) and (r-1-d<=p)
    cond3=(d*(p-1)<=r*e<=(d+1)*(p-1))
    return (cond1 and cond2 and cond3)
#



#
# we assume (r,e,d) in E(p)
#



###
def CheckDeltaDirect(p,red):
    r=red[0]
    e=red[1]
    d=red[2]
    #
    ehat=(p-1)-e
    dhat=(r-1)-d
    #
    F=GF(p)
    #
    R=PolynomialRing(F,["s%s"%i for i in range(0,r+1)])
    s=R.gens()
    #
    S=PolynomialRing(R,["x"])
    ex=S.gens()
    x=ex[0]
    #
    fx=sum(s[i]*x^(r-i) for i in range(0,r+1))
    #
    fxe=fx^e
    Md=matrix(R,d,d,lambda i,j:fxe.coefficient(i*p+j+p-d))
    detMd=Md.determinant()
    #
    fxehat=fx^ehat
    Mdhat=matrix(R,dhat,dhat,lambda i,j:fxehat.coefficient(i*p+j+p-dhat))
    detMdhat=Mdhat.determinant()
    #
    LHS=detMd
    RHS=detMdhat
    #
    Delta=fx.discriminant()
    if p==2:
        delta=sqrt(Delta)
    #
    #
    if e-(p-1)/2 > 0:
        if p==2:
            LHS=LHS/delta^(2*e-(p-1))
        else:
            LHS=LHS/Delta^(e-(p-1)/2)
    elif ehat-(p-1)/2 > 0:
        if p==2:
            RHS=RHS/delta^(2*ehat-(p-1))
        else:
            RHS=RHS/Delta^(ehat-(p-1)/2)
    #
    if (LHS in R) and (RHS in R):
        1==1
    else:
        print("========== ERROR ==========")
    #
    #
    if d*(p-1)-(r-1)*e > 0:
        LHS=LHS/s[0]^(d*(p-1)-(r-1)*e)
    elif dhat*(p-1)-(r-1)*ehat > 0:
        RHS=RHS/s[0]^(dhat*(p-1)-(r-1)*ehat)
    #
    if (LHS in R) and (RHS in R):
        1==1
    else:
        print("========== ERROR ==========")
    #
    epsilon1=(-1)^((r*(r+1)/2)*(1+e)+(r+1)*d)
    epsilon2=factorial((d+1)*(p-1)-r*e) * factorial(e)^r
    epsilon=F(epsilon1*epsilon2)
    #
    RHS=epsilon*RHS
    #
    Result=(LHS==RHS)
    return Result
#
    


###
def CheckDeltaRandom(p,red,Fdeg,HMT):
    r=red[0]
    e=red[1]
    d=red[2]
    #
    ehat=(p-1)-e
    dhat=(r-1)-d
    #
    Fp=GF(p)
    FpList=Fp.list()
    #
    if Fdeg==1:
        F=Fp
    else:
        F=GF(p^Fdeg)
    ez=F.gens()
    z=ez[0]
    #FList=F.list()
    #
    S=PolynomialRing(F,["x"])
    ex=S.gens()
    x=ex[0]
    #
    ResultForAll=True
    #
    for k in range(0,HMT):
        #
        while 1==1:
            #sList=[choice(FList) for i in range(0,r+1)]
            sList=[sum(choice(FpList)*z^iFdeg for iFdeg in range(0,Fdeg)) for i in range(0,r+1)]
            s0=sList[0]
            if s0!=F(0):
                fx=sum(sList[i]*x^(r-i) for i in range(0,r+1))
                Delta=fx.discriminant()
                if Delta!=F(0):
                    break
        #
        fxe=fx^e
        Md=matrix(F,d,d,lambda i,j:fxe.coefficient(i*p+j+p-d))
        detMd=Md.determinant()
        #
        fxehat=fx^ehat
        Mdhat=matrix(F,dhat,dhat,lambda i,j:fxehat.coefficient(i*p+j+p-dhat))
        detMdhat=Mdhat.determinant()
        #
        LHS=detMd
        RHS=detMdhat
        #
        if p==2:
            delta=sqrt(Delta)
        #
        if e-(p-1)/2 > 0:
            if p==2:
                LHS=LHS/delta^(2*e-(p-1))
            else:
                LHS=LHS/Delta^(e-(p-1)/2)
        elif ehat-(p-1)/2 > 0:
            if p==2:
                RHS=RHS/delta^(2*ehat-(p-1))
            else:
                RHS=RHS/Delta^(ehat-(p-1)/2)
        #
        if (LHS in F) and (RHS in F):
            1==1
        else:
            print("========== ERROR 1 ==========")
        #
        #
        if d*(p-1)-(r-1)*e > 0:
            LHS=LHS/s0^(d*(p-1)-(r-1)*e)
        elif dhat*(p-1)-(r-1)*ehat > 0:
            RHS=RHS/s0^(dhat*(p-1)-(r-1)*ehat)
        #
        if (LHS in F) and (RHS in F):
            1==1
        else:
            print("========== ERROR 2 ==========")
        #
        epsilon1=(-1)^((r*(r+1)/2)*(1+e)+(r+1)*d)
        epsilon2=factorial((d+1)*(p-1)-r*e) * factorial(e)^r
        epsilon=F(epsilon1*epsilon2)
        #
        RHS=epsilon*RHS
        #
        Result=(LHS==RHS)
        if Result==False:
            print("========== ERROR 3 ==========")
        ResultForAll=ResultForAll and Result
    #
    return ResultForAll
#



###
def CheckDeltaRandomLinearEquation(p,red,FdegBound,failCountBound,eListLenBound):
    #
    t0=time()
    #
    Denied=False        # random data LHS != RHS found
    Undetermined=False  # Fdeg > FdegBound occured
    Approved=False      # Equality approved
    #
    r=red[0]
    e=red[1]
    d=red[2]
    #
    ehat=(p-1)-e
    dhat=(r-1)-d
    rehatdhat=[r,ehat,dhat]
    #
    print("========== ========== ========== ==========")
    print("p =",p,"red =",red,"rehatdhat =",rehatdhat)
    print(strftime("%Y-%m-%d %H:%M:%S local time",localtime()))
    sys.stdout.flush()
    #
    epsilonQ=(-1)^((r*(r+1)/2)*(1+e)+(r+1)*d) * factorial((d+1)*(p-1)-r*e) * factorial(e)^r 
    #
    # degree such that deg(si)=i
    #
    # call it a non-homogeneous degree
    #
    LHS_NH=r*e*d-(d*(d+1)/2)*(p-1)
    RHS_NH=r*ehat*dhat-(dhat*(dhat+1)/2)*(p-1)
    #
    if e-(p-1)/2>0:
        LHS_NH=LHS_NH-r*(r-1)*(e-(p-1)/2)
    elif ehat-(p-1)/2>0:
        RHS_NH=RHS_NH-r*(r-1)*(ehat-(p-1)/2)
    #
    if LHS_NH!=RHS_NH:
        print()
        print("========== ERROR 1 ==========")
        print()
    #
    # degree such that deg(si)=1
    #
    # call it homogeneous degree
    #
    LHS_H=e*d
    RHS_H=ehat*dhat
    #
    if e-(p-1)/2>0:
        LHS_H=LHS_H-2*(r-1)*(e-(p-1)/2)
    elif ehat-(p-1)/2>0:
        RHS_H=RHS_H-2*(r-1)*(ehat-(p-1)/2)
    #
    if d*(p-1)-(r-1)*e>0:
        LHS_H=LHS_H-( d*(p-1)-(r-1)*e )
    elif dhat*(p-1)-(r-1)*ehat>0:
        RHS_H=RHS_H-( dhat*(p-1)-(r-1)*ehat )
    #
    if LHS_H!=RHS_H:
        print()
        print("========== ERROR 2 ==========")
        print()
    #
    #
    # 0 e0 + 1 e1 + ... + r er = NH
    #
    #   e0 +   e1 + ... +   er = H
    #
    #
    eList=WeightedSumSum(r,LHS_NH,LHS_H)
    eListLen=len(eList)
    #
    print("eListLen =",eListLen)
    sys.stdout.flush()
    if eListLen > eListLenBound:
        Undetermined=True
        t1=time()
        print("========== ========== ========== ==========> Undetermined","eListLen =",eListLen)
        print(strftime("%Y-%m-%d %H:%M:%S local time",localtime()))
        print(t1-t0,"seconds")
        sys.stdout.flush()
        return False
    #
    #
    # loop for Fdeg
    #
    Fdeg=1
    while 1==1:
        if Denied==True:
            break
        if Approved==True:
            break
        if Fdeg > FdegBound:
            Undetermined=True
            break
        #
        # set F, MAT = 0, VEC = 0, Rank = 0, F[x]
        #
        Fp=GF(p)
        FpList=Fp.list()
        #
        if Fdeg==1:
            F=Fp
        else:
            F=GF(p^Fdeg)
        ez=F.gens()
        z=ez[0]
        #FList=F.list()
        #
        R=PolynomialRing(F,['x'])
        ex=R.gens()
        x=ex[0]
        #
        MAT=matrix(F,eListLen,eListLen,lambda i,j:F(0))
        VEC=vector([F(0) for i in range(0,eListLen)])
        Rank=0
        #
        epsilonF=F(epsilonQ)
        #
        # loop for failCount
        #
        print("Fdeg =",Fdeg)
        failCount=0
        dotCount=0
        while 1==1:
            if Denied==True:
                break
            if Approved==True:
                break
            if failCount > failCountBound:
                Fdeg+=1
                break
            #
            # get random s0, s1, ... , sr such that so and Delta(f(x)) are non zero
            #
            while 1==1:
                #
                while 1==1:
                    #RandomSList=[choice(FList) for i in range(0,r+1)]
                    RandomSList=[sum(choice(FpList)*z^iFdeg for iFdeg in range(0,Fdeg)) for i in range(0,r+1)]
                    if RandomSList[0]!=F(0):
                        break
                #
                fx=sum(RandomSList[i]*x^(r-i) for i in range(0,r+1))
                Delta=fx.discriminant()
                if Delta!=F(0):
                    break
            #
            #
            # LHS
            #
            fxe=fx^e
            Md=matrix(F,d,d,lambda i,j:fxe.coefficient(i*p+j+p-d))
            detMd=Md.determinant()
            LHS=detMd
            #
            if e-(p-1)/2>0:
                if p!=2:
                    DeltaPow=Delta^(e-(p-1)/2)
                else:
                    delta=sqrt(Delta)
                    DeltaPow=delta^(2*e-(p-1))
                #
                LHS=LHS/DeltaPow
            #
            if d*(p-1)-(r-1)*e>0:
                LHS=LHS/RandomSList[0]^(d*(p-1)-(r-1)*e)
            #
            # RHS
            #
            fxehat=fx^ehat
            Mdhat=matrix(F,dhat,dhat,lambda i,j:fxehat.coefficient(i*p+j+p-dhat))
            detMdhat=Mdhat.determinant()
            RHS=detMdhat
            #
            if ehat-(p-1)/2>0:
                if p!=2:
                    DeltaPow=Delta^(ehat-(p-1)/2)
                else:
                    delta=sqrt(Delta)
                    DeltaPow=delta^(2*ehat-(p-1))
                #
                RHS=RHS/DeltaPow
            #
            if dhat*(p-1)-(r-1)*ehat>0:
                RHS=RHS/RandomSList[0]^(dhat*(p-1)-(r-1)*ehat)
            #
            RHS=epsilonF*RHS
            #
            # when LHS != RHS
            #
            if LHS!=RHS:
                print()
                print("========== ERROR 3 ==========")
                print()
                #
                # Hypothesis Denied
                #
                Denied=True
                break
            #
            # add one more row for MAT and VEC
            #
            for j in range(eListLen):
                expo=eList[j]
                compo=prod(RandomSList[k]^expo[k] for k in range(0,r+1))
                MAT[Rank,j]=compo
            #
            VEC[Rank]=LHS
            #
            # Does Rank increase?
            #
            if MAT.rank()==Rank+1:
                Rank+=1
                #print("p =",p,"red =",red,"rehatdhat =",rehatdhat,end=" ")
                #print("Fdeg =",Fdeg,"failCount =",failCount,"Rank =",Rank,"/",eListLen)
                #
                dotCount+=1
                if dotCount%1000==0:
                    print("T",end="")
                    sys.stdout.flush()
                elif dotCount%100==0:
                    print("*",end="")
                    sys.stdout.flush()
                else:
                    print(".",end="")
                    sys.stdout.flush()
                #
                if Rank==eListLen:
                    Approved=True
                    #
                    # get the exact form of det Md(f(x)^e) / Delta(f(x))^(e-(p-1)/2)
                    #
                    # and compare it with det Mdd(f(x)^ee) for generic f(x)
                    #
                    if True:
                        coeffList=MAT.inverse() * VEC
                        #
                        S=PolynomialRing(F,['s%s'%i for i in range(0,r+1)])
                        es=S.gens()
                        #
                        Form=sum(coeffList[k]*prod(es[i]^eList[k][i] for i in range(0,r+1)) for k in range(0,eListLen))
                        #
                        print()
                        fact=factor(Form)
                        factList=list(fact)
                        print("unit =",fact.unit())
                        for i in range(0,len(factList)):
                            TheLength=len(list(factList[i][0]))
                            if TheLength<100:
                                print("irred factor[",i,"] =",factList[i][0])
                            else:
                                print("irred factor[",i,"] =",TheLength,"terms")
                            print("multiplicity[",i,"] =",factList[i][1])
                    #
            else:
                failCount+=1
                print()
                print("failCount =",failCount)
                sys.stdout.flush()
            #
        #
    #
    if Denied:
        print("xxxxxxxxxx xxxxxxx xx xxxxxxxxxx xxxxxxxxxx> Denied","Fdeg =",Fdeg,"failCount =",failCount)
    if Approved:
        print("---------- ---------- ---------- ----------> Approved","Fdeg =",Fdeg,"failCount =",failCount)
    if Undetermined:
        print("========== ========== ========== ==========> Undetermined","Fdeg =",Fdeg,"failCount =",failCount)
    #
    t1=time()
    print(strftime("%Y-%m-%d %H:%M:%S local time",localtime()))
    print(t1-t0,"seconds")
#



#
# r >= 1
#
# NH >= 0, H >= 0
#
# 0 e0 + 1 e1 + ... + r er = NH
#
#   e0 +   e1 + ... +   er = H
#
# ei >= 0
#
# return the list of [e0, e1, ..., er]
#


###
def WeightedSumSum(r,NH,H):
    if r==1:
        e1=NH
        e0=H-NH
        if e0>=0:
            return [[e0,e1]]
        else:
            return []
    else:
        ans=[]
        for er in range(0,H+1):
            if NH-r*er>=0:
                recur=WeightedSumSum(r-1,NH-r*er,H-er)
                for k in recur:
                    kcopy=k
                    kcopy.append(er)
                    ans.append(kcopy)
            else:
                1==1
        #
        ans.sort()
        return ans
#



####################################################################################################
#
# ( the duality concerning a theorem of Glynn )
#
# p prime
#
# r >= 1
#
# 0 <= e <= p-1, 0 <= ehat <= p-1, e + ehat = p-1
#
#
# A = (aij) 0 <= i, j <= r-1
#
# definition
#
# Ge(A) =   product       ( sum             aij Xj )^e [ prod            Xj^e ] 
#           0 <= i <= r-1   0 <= j <= r-1                0 <= j <= r-1
#
# Ahat is the adjoint (adjugate) matrix of A, i.e., A Ahat = det(A)
#
# The target equality is
#
#
# Ge(A) = det(A)^( p - 1 - r ehat ) Gehat(Ahat)
#
# i.e.
#
# Ge(A) = det(A)^(p-1) Gehat(A^(-1))
#
#
# Moreover,
#
# Ge(A) / det(A)^(p-1-r*ehat)          when p-1-r*ehat >= 0
#
# Gehat(Ahat) / det(A)^(-(p-1-r*ehat)) when p-1-r*ehat <= 0
#
# might be such that
#
# each irreducible factor has multiplicity one 
# 
# no det(A) factor
#
# det(A) is always irreducible ( it is of degree 1 for each component, ... , by the induction on r, ... )
#
####################################################################################################



###
def CheckGlynnDirect(p,r):
    #
    F=GF(p)
    #
    if r>10:
        R=PolynomialRing(F,["a_%s_%s"%(i,j) for i in range(0,r) for j in range(0,r)])
    else:
        R=PolynomialRing(F,["a%s%s"%(i,j) for i in range(0,r) for j in range(0,r)])
    a=R.gens()
    #
    # a_(i,j) = a[ i*r + j ]
    #
    S=PolynomialRing(R,["x%s"%i for i in range(0,r)])
    x=S.gens()
    #
    # x_i = x[ i ]
    #
    A=matrix(R, r, r, lambda i,j:a[i*r+j])
    detA=A.determinant()
    #
    #Ahat=A.adjoint()
    #
    Ahat=A.adjugate()
    #
    formA=prod(sum(A[i,j]*x[j] for j in range(0,r)) for i in range(0,r))
    formAhat=prod(sum(Ahat[i,j]*x[j] for j in range(0,r)) for i in range(0,r))
    #
    for ehat in range(0,p):
        e=p-1-ehat
        theExponent=p-1-r*ehat
        print("========== ========== ========== ========== ========== ==========")
        print("p =",p,"r =",r,"e =",e,"ehat =",ehat,"degree --->",r*e,"= (",r*(p-1-r*ehat),") +",r*(r-1)*ehat)
        sys.stdout.flush()
        #
        if 1==1:
            #
            formAe=formA^e
            if r>=2:
                GeA=formAe.coefficient({x[i]:e for i in range(0,r)})
            else:
                GeA=formAe.coefficient(e)                
            #
            formAhatehat=formAhat^ehat
            if r>=2:
                GehatAhat=formAhatehat.coefficient({x[i]:ehat for i in range(0,r)})
            else:
                GehatAhat=formAhatehat.coefficient(ehat)
            #
            if theExponent>=0:
                LHSnodet=GeA/detA^theExponent
                RHSnodet=GehatAhat
            else:
                LHSnodet=GeA
                RHSnodet=GehatAhat/detA^(-theExponent)
            #
            if (LHSnodet in R) and (RHSnodet in R):
                1==1
            else:
                print()
                print()
                print("======== xxxxxxxx xxxxxxxx <<<    ERROR not divisible by det(M)   >>> xxxxxxxx xxxxxxxx ========")
                print()
                print()
                sys.stdout.flush()
                return False
            #
            # this is a mysterious action, effective for factor
            # 
            LHSnodet=R(LHSnodet)
            RHSnodet=R(RHSnodet)
            #
            # this is a mysterious action, effective for factor
            #
            if LHSnodet==RHSnodet:
                1==1
            else:
                print()
                print()
                print("======== xxxxxxxx xxxxxxxx <<<    ERROR not equal   >>> xxxxxxxx xxxxxxxx ========")
                print()
                print()
                sys.stdout.flush()
                return False
            #
            factor1=factor(LHSnodet)
            unit1=factor1.unit()
            list1=list(factor1)
            lenlist1=len(list1)
            #
            if lenlist1>=2:
                print()
                print()
                print("======== xxxxxxxx xxxxxxxx <<<    WARNING reducible   >>> xxxxxxxx xxxxxxxx ========")
                print()
                print()
                sys.stdout.flush()
            #
            print("(no determinant part)")
            print("unit =",unit1)
            for i in range(0,lenlist1):
                TheLength=len(list(list1[i][0]))
                if TheLength > 100:
                    print("irreducible factor [",i,"] =",TheLength,"terms")
                else:
                    print("irreducible factor [",i,"] =",list1[i][0])
                print("          exponent [",i,"] =",list1[i][1])
                sys.stdout.flush()
                #
                if list1[i][1]>=2:
                    print()
                    print()
                    print("======== xxxxxxxx xxxxxxxx <<<    WARNING multiplicity   >>> xxxxxxxx xxxxxxxx ========")
                    print()
                    print()
                    sys.stdout.flush()
                #
                if list1[i][0]/detA in R:
                    print()
                    print()
                    print("======== xxxxxxxx xxxxxxxx <<<    WARNING divisible by det(M)   >>> xxxxxxxx xxxxxxxx ========")
                    print()
                    print()
                    sys.stdout.flush()
                #
            #
        #
    #
#


#
# check the equality for randomly chosen aij in F(p^Fdeg) HMT (how many times) times
#


###
def CheckGlynnRandom(p,r,Fdeg,HMT):
    #
    Fp=GF(p)
    FpList=Fp.list()
    #
    if Fdeg==1:
        F=Fp
    else:
        F=GF(p^Fdeg)
    ez=F.gens()
    z=ez[0]
    #FList=F.list()
    #
    R=PolynomialRing(F,["x%s"%i for i in range(0,r)])
    x=R.gens()
    #
    Resulte=True
    for ehat in range(0,p):
        #
        e=p-1-ehat
        theExponent=p-1-r*ehat
        #
        Resultk=True
        for k in range(0,HMT):
            #
            #A=matrix(F,r,r,lambda i,j:choice(FList))
            A=matrix(F,r,r,lambda i,j:sum(choice(FpList)*z^iFdeg for iFdeg in range(0,Fdeg)))
            #
            detA=A.determinant()
            #
            #Ahat=A.adjoint()
            #
            Ahat=A.adjugate()
            #
            formA=prod(sum(A[i,j]*x[j] for j in range(0,r)) for i in range(0,r))
            formAe=formA^e
            if r>=2:
                GeA=formAe.coefficient({x[i]:e for i in range(0,r)})
            else:
                GeA=formAe.coefficient(e)
            #   
            formAhat=prod(sum(Ahat[i,j]*x[j] for j in range(0,r)) for i in range(0,r))
            formAhatehat=formAhat^ehat
            if r>=2:
                GehatAhat=formAhatehat.coefficient({x[i]:ehat for i in range(0,r)})
            else:
                GehatAhat=formAhatehat.coefficient(ehat)
            #
            if theExponent>=0:
                LHS=GeA
                RHS=GehatAhat*detA^theExponent
            else:
                LHS=GeA*detA^(-theExponent)
                RHS=GehatAhat
            #
            Result=(LHS==RHS)
            #
            #print("p =",p,"r =",r,"e =",e,"ehat =",ehat,"k =",k,"Result =",Result)
            if Result==False:
                print()
                print()
                print("======== xxxxxxxx xxxxxxxx <<<    ERROR not equal   >>> xxxxxxxx xxxxxxxx ========")
                print()
                print()
                sys.stdout.flush()
            #
            Resultk=Resultk and Result
            #
        #
        Resulte=Resulte and Resultk
        #
    #
    print("p =",p,"r =",r,end=" ")
    if Resulte:
        print("Check OK")
    else:
        print("Check ERROR")
    #
    return Resulte
#


# end of file
