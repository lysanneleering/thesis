#!/usr/bin/env python3
"""
Certified finite-depth renderer for collinear connectedness loci.

This reference implementation follows the canonical-trap / canonical-enclosure
inverse search described in Espigule--Juher, "Finite capture and the closure of
roots of restricted polynomials", Algorithm 4.1.  It certifies pixel boxes using
interval arithmetic:

  I = all parameters in the pixel box are Interior (one inverse branch maps the
      whole pixel box into the canonical trap),
  E = all parameters in the pixel box are Exterior (all branches are exhausted
      by the canonical enclosure by the chosen depth),
  U = unresolved at the chosen depth/precision.

The script is intentionally small and conservative; it is a CPU reference version
of the renderer rather than the WebGL implementation used by complextrees.com.
"""
from __future__ import annotations

import argparse, csv, math, hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

import mpmath as mp
from PIL import Image

mp.iv.dps = 50

@dataclass(frozen=True)
class Box:
    x0: float
    x1: float
    y0: float
    y1: float

ComplexBox = Tuple[mp.iv.mpf, mp.iv.mpf]


def iv(a: float, b: float) -> mp.iv.mpf:
    return mp.iv.mpf([a, b])


def endpoints(a: mp.iv.mpf) -> Tuple[float, float]:
    return float(a.a), float(a.b)


def max_abs(a: mp.iv.mpf) -> float:
    lo, hi = endpoints(a)
    return max(abs(lo), abs(hi))


def min_abs(a: mp.iv.mpf) -> float:
    lo, hi = endpoints(a)
    if lo <= 0 <= hi:
        return 0.0
    return min(abs(lo), abs(hi))


def c_add(z: ComplexBox, w: ComplexBox) -> ComplexBox:
    return z[0] + w[0], z[1] + w[1]


def c_sub_real(z: ComplexBox, t: int) -> ComplexBox:
    return z[0] - t, z[1]


def c_mul(z: ComplexBox, w: ComplexBox) -> ComplexBox:
    x, y = z
    u, v = w
    return x*u - y*v, x*v + y*u


def c_inv(z: ComplexBox) -> ComplexBox:
    x, y = z
    den = x*x + y*y
    return x/den, -y/den


def c_abs_range(z: ComplexBox) -> mp.iv.mpf:
    x, y = z
    return mp.iv.sqrt(x*x + y*y)


def c_scale_real(z: ComplexBox, a: float) -> ComplexBox:
    return z[0]*a, z[1]*a


def in_lens(c: ComplexBox, n: int) -> bool:
    # Sufficient interval test that the whole box lies in the upper-half lens.
    x, y = c
    if endpoints(y)[0] <= 0:
        return False
    one = mp.iv.mpf([1,1])
    n2 = 2*n
    left = (x-one)*(x-one) + y*y
    right = (x+one)*(x+one) + y*y
    return endpoints(left)[1] < n2 and endpoints(right)[1] < n2 and endpoints(x*x+y*y)[0] > 1


def trap_bounds(c: ComplexBox, n: int) -> Tuple[float, float]:
    # Returns lower bounds for V and Ny over the parameter box.
    N = 2*n - 1
    x, y = c
    rho2 = x*x + y*y
    V = ((N - 2*x)*y)/rho2
    Vlo, _ = endpoints(V)
    ylo, _ = endpoints(y)
    return max(0.0, Vlo), N*ylo


def enclosure_bounds(c: ComplexBox, n: int, R: int = 60) -> Tuple[float, float]:
    # Conservative upper bounds for V_E and |c| S_E over the parameter box.
    N = 2*n - 1
    x, y = c
    z = c
    invc = c_inv(c)
    p = invc
    s = 0.0
    for _ in range(1, R+1):
        s += max_abs(p[1])
        p = c_mul(p, invc)
    rho = c_abs_range(c)
    rho_lo, rho_hi = endpoints(rho)
    if rho_lo <= 1:
        tail = float('inf')
    else:
        tail = rho_lo**(-(R+1))/(1 - 1/rho_lo)
    VE = (N-1)*(s + tail)
    y_hi = endpoints(y)[1]
    SE = (N-1)*y_hi/rho_lo + VE/rho_lo
    return VE, rho_hi*SE


def inside_trap(z: ComplexBox, c: ComplexBox, n: int) -> bool:
    Vlo, Slo = trap_bounds(c, n)
    cz = c_mul(c, z)
    return max_abs(z[1]) < Vlo and max_abs(cz[1]) < Slo


def definitely_outside_enclosure(z: ComplexBox, c: ComplexBox, n: int) -> bool:
    VE, SEc = enclosure_bounds(c, n)
    cz = c_mul(c, z)
    return min_abs(z[1]) > VE or min_abs(cz[1]) > SEc


def certify_pixel(box: Box, n: int, depth: int, node_cap: int) -> str:
    c = (iv(box.x0, box.x1), iv(box.y0, box.y1))
    if not in_lens(c, n):
        return 'U'
    z0 = c_scale_real(c, 2.0)
    if inside_trap(z0, c, n):
        return 'I'
    if definitely_outside_enclosure(z0, c, n):
        return 'E'
    digits = list(range(-(2*n-2), 2*n-1, 2))  # A_N with N=2n-1
    nodes: List[ComplexBox] = [z0]
    for _ in range(depth):
        nxt: List[ComplexBox] = []
        for z in nodes:
            for t in digits:
                child = c_mul(c, c_sub_real(z, t))
                if inside_trap(child, c, n):
                    return 'I'
                if not definitely_outside_enclosure(child, c, n):
                    nxt.append(child)
                    if len(nxt) > node_cap:
                        return 'U'
        if not nxt:
            return 'E'
        nodes = nxt
    return 'U'


def render(n: int, center: complex, span: float, width: int, height: int, depth: int, node_cap: int, out: Path, csv_out: Path | None) -> None:
    aspect = height/width
    x0 = center.real - span/2
    x1 = center.real + span/2
    y0 = center.imag - span*aspect/2
    y1 = center.imag + span*aspect/2
    img = Image.new('RGB', (width, height))
    rows=[]
    colors = {'I': (245,245,245), 'E': (20,20,20), 'U': (128,128,128)}
    for j in range(height):
        yy0 = y1 - (j+1)*(y1-y0)/height
        yy1 = y1 - j*(y1-y0)/height
        for i in range(width):
            xx0 = x0 + i*(x1-x0)/width
            xx1 = x0 + (i+1)*(x1-x0)/width
            status = certify_pixel(Box(xx0, xx1, yy0, yy1), n, depth, node_cap)
            img.putpixel((i,j), colors[status])
            if csv_out is not None:
                rows.append((i,j,status,xx0,xx1,yy0,yy1))
    img.save(out)
    if csv_out is not None:
        with open(csv_out,'w',newline='') as f:
            w=csv.writer(f)
            w.writerow(['i','j','status','x0','x1','y0','y1'])
            w.writerows(rows)
    print('image', out)
    print('sha256', hashlib.sha256(out.read_bytes()).hexdigest())
    if csv_out is not None:
        print('certificates', csv_out)
        print('certificates_sha256', hashlib.sha256(csv_out.read_bytes()).hexdigest())


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=3)
    ap.add_argument('--center', type=str, default='0.36+1.78j')
    ap.add_argument('--span', type=float, default=0.18)
    ap.add_argument('--width', type=int, default=120)
    ap.add_argument('--height', type=int, default=90)
    ap.add_argument('--depth', type=int, default=12)
    ap.add_argument('--node-cap', type=int, default=5000)
    ap.add_argument('--out', type=Path, default=Path('certified_render.png'))
    ap.add_argument('--csv', type=Path, default=None)
    args=ap.parse_args()
    render(args.n, complex(args.center.replace('i','j')), args.span, args.width, args.height, args.depth, args.node_cap, args.out, args.csv)

if __name__=='__main__':
    main()
