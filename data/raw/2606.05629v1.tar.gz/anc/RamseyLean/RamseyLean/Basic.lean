import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Combinatorics.SimpleGraph.StronglyRegular
import Mathlib.Combinatorics.SimpleGraph.Copy

/-!
This file is a mathlib-backed first formalization pass for the proof in
`RamseyProof/main.tex`.

It uses mathlib's `SimpleGraph`, `edgeFinset`, `degree`,
`commonNeighbors`, `IsRegularOfDegree`, and `IsSRGWith` structures.  The two
large standard ingredients that are not developed here from first principles
are kept as explicit certificate interfaces:

* the Goodman/book-counting identities through equation `(quadraticineq)`;
* the standard spectral multiplicity consequence for an SRG with parameters
  `(37,18,7,10)`.

The arithmetic steps of the paper are proved below: the Goodman/book-counting
certificate implies equation `(quadraticineq)`, that inequality forces
`18`-regularity, and the spectral multiplicity equations are inconsistent.

Roadmap relative to `RamseyProof/main.tex`:

* `bookGraph` and `ContainsBook` formalize the definition of `B_t` and
  "contains a copy of `B_t`" from the introduction.
* `B8B10UpperBoundStatement` is the literal Lean statement of the upper-bound
  claim used in Theorem 1: every graph on 37 vertices contains `B_8` or its
  complement contains `B_10`.
* `b8b10_upper_bound_formalized` is the main theorem actually proved in this
  file.  It is the certificate-level counterpart of the contradiction argument
  in Section 2: no 37-vertex graph can satisfy the no-`B_8`, no-complement-
  `B_10`, Goodman-counting, and SRG-spectral certificates simultaneously.
* The known lower bound `R(B_8,B_10) >= 37`, cited in the LaTeX introduction,
  is not formalized here.
-/

open scoped BigOperators
open Finset

namespace RamseyLean

abbrev Vertex := Fin 37

/-- The book graph `B_n`, with spine vertices `0` and `1`. -/
def bookGraph (n : Nat) : SimpleGraph (Fin (n + 2)) where
  Adj x y :=
    x ≠ y ∧ (x.val ≤ 1 ∨ y.val ≤ 1)
  symm := by
    intro x y h
    exact ⟨h.1.symm, h.2.symm⟩
  loopless := by
    constructor
    intro x h
    exact h.1 rfl

/-- "G contains a copy of `B_n`", matching the introduction's use of book subgraphs. -/
def ContainsBook (n : Nat) (G : SimpleGraph Vertex) : Prop :=
  Nonempty (SimpleGraph.Copy (bookGraph n) G)

/--
The literal Ramsey upper-bound statement corresponding to the sentence in
Section 2 of the LaTeX proof:

"it is enough to prove that every graph on 37 vertices contains `B_8` or its
complement contains `B_10`."

The current file proves the certificate version below
(`b8b10_upper_bound_formalized`), not this statement directly from the absence
of embeddings.
-/
def B8B10UpperBoundStatement : Prop :=
  ∀ (G : SimpleGraph Vertex) [DecidableRel G.Adj],
    ContainsBook 8 G ∨ ContainsBook 10 Gᶜ

/-- Lean counterpart of `c_G(u,v) = |N_G(u) ∩ N_G(v)|` in Section 2. -/
def commonNeighborCount (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (u v : Vertex) : Nat :=
  Fintype.card (G.commonNeighbors u v)

/--
Lean counterpart of the LaTeX implication
"because `G` contains no `B_8`, every edge `uv` satisfies `c_G(u,v) <= 7`."
-/
def edgeBookCapB8 (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Prop :=
  ∀ u v, G.Adj u v -> commonNeighborCount G u v <= 7

/--
Lean counterpart of the complement book cap:
every complement edge has at most `9` common neighbors in the complement.
-/
def complementBookCapB10 (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Prop :=
  ∀ u v, Gᶜ.Adj u v -> commonNeighborCount Gᶜ u v <= 9

/--
Package the mathlib degree `G.degree v` as an element of `Fin 37`.
This uses `SimpleGraph.degree_lt_card_verts` and corresponds to the paper's
implicit fact that each degree is an integer between `0` and `36`.
-/
def degreeFin (G : SimpleGraph Vertex) [DecidableRel G.Adj] (v : Vertex) :
    Fin 37 := by
  refine ⟨G.degree v, ?_⟩
  simpa [Vertex] using G.degree_lt_card_verts v

/-- The quadratic `f(d) = 106d - 3d^2` from equation `(quadraticineq)`. -/
def localQuadratic (d : Fin 37) : Nat :=
  106 * d.val - 3 * d.val * d.val

/-- The summand `f(d(x))` in equation `(quadraticineq)`. -/
def degreeQuadraticTerm (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (v : Vertex) : Nat :=
  localQuadratic (degreeFin G v)

/-- The left-hand side `sum_x (106d(x) - 3d(x)^2)` of `(quadraticineq)`. -/
def degreeQuadraticSum (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Nat :=
  ∑ v : Vertex, degreeQuadraticTerm G v

/-!
The next structure is the finite-counting interface corresponding to the
middle of the paper:

* `edge_total`: `e + ebar = binom(37,2) = 666`, stated with mathlib's
  `edgeFinset`;
* `goodman_twice`: Goodman's identity, multiplied by `2`;
* `edge_triangle_cap` and `complement_triangle_cap`: the two book caps;
* `quadratic_relation`: the algebraic relation between
  `sum_x d(x)(36-d(x))`, mathlib's degree sum, and equation `(quadraticineq)`.

Thus this structure is the direct Lean counterpart of the LaTeX passage from
the triangle-cap estimates and Goodman's identity up to, but not including, the
final inequality `(quadraticineq)`.
-/
structure CountingCertificate (G : SimpleGraph Vertex) [DecidableRel G.Adj] where
  /-- `T = t(G)` in the LaTeX proof. -/
  triangleCount : Nat
  /-- `Tbar = t(Gbar)` in the LaTeX proof. -/
  complementTriangleCount : Nat
  /-- `sum_x d(x)(36-d(x))`, the degree-product sum in Goodman's identity. -/
  degreeProductSum : Nat
  /-- `e + ebar = binom(37,2) = 666`. -/
  edge_total : #G.edgeFinset + #Gᶜ.edgeFinset = 666
  /-- Equation `(goodman)`, multiplied by `2`: `2(T + Tbar) + S = 15540`. -/
  goodman_twice :
    2 * (triangleCount + complementTriangleCount) + degreeProductSum = 15540
  /-- First half of equation `(trianglecaps)`: `3T <= 7e`. -/
  edge_triangle_cap : 3 * triangleCount <= 7 * #G.edgeFinset
  /-- Second half of equation `(trianglecaps)`: `3Tbar <= 9 ebar`. -/
  complement_triangle_cap :
    3 * complementTriangleCount <= 9 * #Gᶜ.edgeFinset
  /--
  Algebraic rewrite connecting the Goodman degree-product sum to
  `sum_x (106d(x)-3d(x)^2)`.
  -/
  quadratic_relation :
    degreeQuadraticSum G + 2 * (∑ v : Vertex, G.degree v) =
      3 * degreeProductSum

/--
Direct Lean counterpart of the derivation of equation `(quadraticineq)`:

`sum_x (106 d(x) - 3 d(x)^2) >= 34632`.
-/
theorem quadratic_ineq_of_counting (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (counting : CountingCertificate G) :
    34632 <= degreeQuadraticSum G := by
  have hedge := counting.edge_total
  have hdeg := G.sum_degrees_eq_twice_card_edges
  have hgood := counting.goodman_twice
  have hcap_edge := counting.edge_triangle_cap
  have hcap_complement := counting.complement_triangle_cap
  have hquad_relation := counting.quadratic_relation
  have hcap :
      3 * (counting.triangleCount + counting.complementTriangleCount) +
          2 * #G.edgeFinset <= 5994 := by
    omega
  have hcap_twice :
      6 * (counting.triangleCount + counting.complementTriangleCount) +
          4 * #G.edgeFinset <= 11988 := by
    omega
  have hgood3 :
      6 * (counting.triangleCount + counting.complementTriangleCount) +
          3 * counting.degreeProductSum = 46620 := by
    omega
  have hproduct :
      34632 + 4 * #G.edgeFinset <= 3 * counting.degreeProductSum := by
    omega
  have hquad :
      degreeQuadraticSum G + 4 * #G.edgeFinset =
        3 * counting.degreeProductSum := by
    omega
  omega

/--
Direct Lean counterpart of the paper's observation that
`f(d) = 106d - 3d^2` is at most `936` for every possible integer degree.
-/
theorem localQuadratic_le_936 (d : Fin 37) : localQuadratic d <= 936 := by
  decide +revert

/-- Direct Lean counterpart of "the unique integer maximum is attained at `d = 18`." -/
theorem localQuadratic_eq_936_iff (d : Fin 37) :
    localQuadratic d = 936 <-> d.val = 18 := by
  decide +revert

/--
Direct Lean counterpart of
`sum_x f(d(x)) <= 37 * 936 = 34632`.
-/
theorem degreeQuadraticSum_le (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    degreeQuadraticSum G <= 34632 := by
  unfold degreeQuadraticSum
  calc
    (∑ v : Vertex, degreeQuadraticTerm G v) <= ∑ _v : Vertex, 936 := by
      exact Finset.sum_le_sum fun v _hv =>
        localQuadratic_le_936 (degreeFin G v)
    _ = 34632 := by
      simp [Vertex, Fintype.card_fin]

/--
Direct Lean counterpart of the paragraph after `(quadraticineq)`:
the lower bound from `quadratic_ineq_of_counting` and the upper bound from
`degreeQuadraticSum_le` force equality term-by-term, hence `G` is
`18`-regular.
-/
theorem regular_of_quadratic_ineq (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hquad : 34632 <= degreeQuadraticSum G) :
    G.IsRegularOfDegree 18 := by
  intro v
  have hle_terms :
      ∀ x ∈ (Finset.univ : Finset Vertex), degreeQuadraticTerm G x <= 936 := by
    intro x _hx
    exact localQuadratic_le_936 (degreeFin G x)
  have hsum_le : degreeQuadraticSum G <= ∑ _x : Vertex, 936 := by
    unfold degreeQuadraticSum
    exact Finset.sum_le_sum hle_terms
  have hconst : (∑ _x : Vertex, 936) = 34632 := by
    simp [Vertex, Fintype.card_fin]
  have hsum_eq : degreeQuadraticSum G = ∑ _x : Vertex, 936 := by
    omega
  have hall :
      ∀ x ∈ (Finset.univ : Finset Vertex), degreeQuadraticTerm G x = 936 := by
    exact (Finset.sum_eq_sum_iff_of_le hle_terms).mp hsum_eq
  have hterm : degreeQuadraticTerm G v = 936 :=
    hall v (Finset.mem_univ v)
  have hval : (degreeFin G v).val = 18 :=
    (localQuadratic_eq_936_iff (degreeFin G v)).mp hterm
  simpa [degreeFin] using hval

/-!
For the SRG parameters `(37,18,7,10)`, the nontrivial eigenvalues satisfy
`x^2 + 3*x - 8 = 0`, i.e. they are conjugates with sum `-3`.
The integer characteristic polynomial forces equal multiplicities.  If that
common multiplicity is `m`, then the `36`-dimensional nontrivial eigenspace
gives `2*m = 36`, while the zero-trace condition gives `18 - 3*m = 0`.
These two integer equations are inconsistent.

This is the arithmetic end of the spectral contradiction in Section 2.
-/
theorem no_spectral_multiplicity (m : Nat)
    (hdim : 2 * m = 36)
    (htrace : (18 : Int) - 3 * (m : Int) = 0) : False := by
  omega

/--
Certificate for the LaTeX passage:

1. equality propagation gives an SRG with parameters `(37,18,7,10)`;
2. the standard spectral analysis of that SRG gives the two multiplicity
   equations used in `no_spectral_multiplicity`.
-/
structure SpectralSRGCertificate (G : SimpleGraph Vertex) [DecidableRel G.Adj] where
  /-- Direct counterpart of "a strongly regular graph with parameters `(37,18,7,10)`". -/
  srg : G.IsSRGWith 37 18 7 10
  /-- The common multiplicity of the two irrational conjugate eigenvalues. -/
  multiplicity : Nat
  /-- The nontrivial eigenspace has dimension `36`, split equally. -/
  dimension_eq : 2 * multiplicity = 36
  /-- The trace condition for the adjacency matrix. -/
  trace_eq : (18 : Int) - 3 * (multiplicity : Int) = 0

/-- Direct Lean counterpart of the final spectral contradiction. -/
theorem no_srg37_18_7_10_with_spectral_certificate
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (cert : SpectralSRGCertificate G) : False :=
  no_spectral_multiplicity cert.multiplicity cert.dimension_eq cert.trace_eq

/--
Certificate-level version of the hypothetical counterexample assumed at the
start of Section 2.

The fields `no_B8_in_G` and `no_B10_in_complement` record the book-cap
consequences of the missing embeddings.  The current first-pass formalization
does not yet prove those caps from `¬ ContainsBook 8 G` and
`¬ ContainsBook 10 Gᶜ`; they are certificate inputs.
-/
structure B8B10CounterexampleCertificate
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] where
  /-- Counterpart of "G contains no copy of `B_8`", in edge-codegree cap form. -/
  no_B8_in_G : edgeBookCapB8 G
  /-- Counterpart of "the complement contains no copy of `B_10`", in cap form. -/
  no_B10_in_complement : complementBookCapB10 G

  -- Formal version of the book-cap and Goodman counting argument through
  -- equation `(quadraticineq)`.
  counting : CountingCertificate G

  -- Formal version of the equality-propagation and spectral step:
  -- once the quadratic inequality forces 18-regularity, the paper obtains
  -- an SRG(37,18,7,10), hence the spectral multiplicity data below.
  spectral_after_regular :
    G.IsRegularOfDegree 18 -> SpectralSRGCertificate G

/--
The core contradiction theorem in this file.

This is the direct Lean counterpart of the Section 2 conclusion
"This contradiction shows that no such 37-vertex graph exists", but at the
certificate level described in `B8B10CounterexampleCertificate`.
-/
theorem no_B8B10_counterexample_certificate
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (cert : B8B10CounterexampleCertificate G) : False := by
  have hregular : G.IsRegularOfDegree 18 :=
    regular_of_quadratic_ineq G (quadratic_ineq_of_counting G cert.counting)
  exact no_srg37_18_7_10_with_spectral_certificate G
    (cert.spectral_after_regular hregular)

/--
Main theorem shape proved by this file.

Read this as the formalized certificate version of the LaTeX upper-bound
argument for `R(B_8,B_10) <= 37`: every mathlib `SimpleGraph` on `Fin 37`
equipped with the no-book, Goodman-counting, and SRG-spectral certificates is
contradictory.

The literal graph-theoretic statement is `B8B10UpperBoundStatement` above.
-/
def B8B10UpperBoundFormalized : Prop :=
  ∀ (G : SimpleGraph Vertex) [DecidableRel G.Adj],
    B8B10CounterexampleCertificate G -> False

/--
MAIN THEOREM OF THIS LEAN FILE.

This is the theorem to cite for the current formalized proof artifact.  It is
the certificate-level counterpart of the LaTeX proof's upper-bound theorem:
under the certified translations of the no-book hypotheses, Goodman counting,
and the SRG spectral step, there is no counterexample on 37 vertices.
-/
theorem b8b10_upper_bound_formalized : B8B10UpperBoundFormalized :=
  no_B8B10_counterexample_certificate

end RamseyLean
