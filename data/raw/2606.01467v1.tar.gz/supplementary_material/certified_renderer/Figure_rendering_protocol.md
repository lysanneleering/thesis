Certified figure-rendering protocol
===================================

The parameter-space figures in the manuscript are certified finite-depth
renderings.  A pixel is a closed parameter rectangle.  It is colored only after
one of the following finite certificates is produced for the whole rectangle:

* finite capture into the canonical trap;
* finite exclusion by complete pruning against the canonical enclosure.

The CPU script `certified_collinear_renderer.py` demonstrates the same
certificate convention on small viewports and writes a CSV certificate label for
each pixel.  The WebGL implementation used for the production figures uses the
same inverse-IFS BFS and trap/enclosure tests, with higher resolution and panel
metadata.
