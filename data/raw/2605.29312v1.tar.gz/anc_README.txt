#
# anc_README.txt
#

(1) files for the paper

main_figure1.pdf  
main_figure2.pdf  
main.bbl  
main.tex  

(2) files for Table 1 for Theorem 3

anc_table.tex  
anc_table_data.tex  
anc_table.pdf  

(3) files for sagemath

We use these files with sagemath on emacs + MELPA sage-shell-mode.

anc_library.sage  
anc_session.sage  

(4) this file

anc_README.txt

