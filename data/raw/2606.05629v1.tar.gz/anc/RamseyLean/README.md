# RamseyLean

This is the Lean 4 project for the Ramsey `B_8`/`B_10` formalization.

The main direct theorem is:

```lean
RamseyLean.Actual.b8b10_upper_bound_actual
```

It proves `B8B10UpperBoundStatement`, defined in
`RamseyLean/RamseyLean/Basic.lean`.  See the repository-level
`../README.md` for the full file map and proof correspondence with
`RamseyProof/main.tex`.
