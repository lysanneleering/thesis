# RamseyB8B10

This repository contains a LaTeX proof and a Lean formalization for the
upper-bound part of the book Ramsey result for `B_8` and `B_10`.

The LaTeX paper proves `R(B_8, B_10) = 37` using an external lower bound
`R(B_8, B_10) >= 37` plus a new upper-bound argument.  The Lean development
formalizes the upper-bound argument: every graph on `37` vertices contains a
copy of `B_8`, or its complement contains a copy of `B_10`.

## Repository Structure

* `RamseyProof/main.tex`
  The human-readable LaTeX proof.  Section 2 is the proof formalized in Lean.

* `RamseyLean/`
  The Lean 4 project.

* `RamseyLean/RamseyLean/Basic.lean`
  Shared definitions and the original certificate-level formalization.
  Important definitions here include:
  `Vertex`, `bookGraph`, `ContainsBook`, and
  `B8B10UpperBoundStatement`.

* `RamseyLean/RamseyLean/Actual.lean`
  The direct formalization of the upper-bound proof from
  `RamseyProof/main.tex`.  This is the main file to read for the completed
  proof.

* `RamseyLean/RamseyLean.lean`
  The root Lean module.  It imports both `Basic` and `Actual`.

## Main Lean Theorem

The statement being proved is defined in
`RamseyLean/RamseyLean/Basic.lean`:

```lean
def B8B10UpperBoundStatement : Prop :=
  ∀ G : SimpleGraph Vertex, ∀ [DecidableRel G.Adj],
    ContainsBook 8 G ∨ ContainsBook 10 Gᶜ
```

The direct formalization proves this statement in
`RamseyLean/RamseyLean/Actual.lean`:

```lean
theorem b8b10_upper_bound_actual : B8B10UpperBoundStatement
```

This theorem is the Lean version of the LaTeX sentence:
"every graph on `37` vertices contains `B_8` or its complement contains
`B_10`."  It proves `R(B_8,B_10) <= 37` for graphs on the fixed vertex type
`Fin 37`.  The known lower bound cited by the paper is not formalized here.

## Proof Map

The comments in `RamseyLean/RamseyLean/Actual.lean` are written to track the
LaTeX proof.  The main milestones are:

1. No-book hypotheses imply edge codegree caps.
2. Ordered versions of the triangle-cap estimates and Goodman's identity imply
   the quadratic inequality.
3. The quadratic maximum forces `18`-regularity.
4. Equality in the caps propagates to exact common-neighbor counts.
5. A hypothetical counterexample is forced to be `SRG(37,18,7,10)`.
6. A mod-41 spectral/nilpotent-trace argument rules out that SRG.

## Building

From the repository root:

```bash
cd RamseyLean
lake build
```

The project uses the Lean version pinned in `RamseyLean/lean-toolchain`.
