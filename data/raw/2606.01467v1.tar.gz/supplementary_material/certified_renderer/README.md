# Certified rendering reference implementation

`certified_collinear_renderer.py` is a compact CPU reference implementation of the finite inverse-search renderer used for the certified figures.  It follows the canonical trap/enclosure mechanism of the finite-capture framework.

Each pixel is treated as a parameter box and receives one of three certificate labels:

- `I`: interior, certified by finite trap entry;
- `E`: exterior, certified by finite enclosure extinction;
- `U`: unresolved at the chosen depth or node cap.

Example command:

```bash
python certified_collinear_renderer.py --n 3 --center '0.36+1.78j' --span 0.25 \
  --width 24 --height 18 --depth 6 --node-cap 500 \
  --out certified_demo_n3.png --csv certified_demo_n3.csv
```

The included demo files were generated with that command.
