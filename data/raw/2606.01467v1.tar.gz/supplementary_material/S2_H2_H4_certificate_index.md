# H2--H4 certificate-family index

This file indexes the certificate families H2--H4 referred to in Appendix C and Appendix D of the manuscript.

## H2: local four-branch geometry

Certificate families:

1. auxiliary chart-side signs on the local boxes;
2. consecutive corner systems and Miranda rectangles;
3. Jacobian non-vanishing on the corner rectangles;
4. nonconsecutive-intersection exclusions;
5. single-arc and no-escape/no-reentry conditions for the four selected branches.

## H3: witness inclusion and no-return

Certificate families:

1. sign pattern at the witness root `c_{n,k}`;
2. no-return sign pattern on the later witness algebraic locus;
3. denominator-positivity and witness-locus isolation data.

## H4: inverse-tree extinction

Certificate families:

1. depth-9 prefix pruning;
2. base pruning intervals;
3. transported digit-set equivalence;
4. terminal extinction intervals.

The manuscript states the proof-facing certificate assertions in Appendix C and expands them into row-by-row tables in Appendix D.
