import RamseyLean.Basic
import Mathlib.Algebra.Field.ZMod
import Mathlib.Data.ZMod.Basic
import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
import Mathlib.RingTheory.ZMod
import Mathlib.Tactic.NoncommRing
import Mathlib.Tactic.Ring

/-!
This file is the direct, non-certificate formalization of the upper-bound
part of `RamseyProof/main.tex`.

The LaTeX theorem states `R(B_8,B_10) = 37`.  This Lean file proves the
upper-bound statement used in that theorem:

`b8b10_upper_bound_actual : B8B10UpperBoundStatement`

In words: every graph on the fixed vertex type `Fin 37` contains a copy of
`B_8`, or its complement contains a copy of `B_10`.  The already-known lower
bound cited in the LaTeX introduction is external to this formalization.

Roadmap from the LaTeX proof to this file:

* LaTeX: "Because `G` contains no `B_8`, every edge has `c_G(u,v) <= 7`."
  Lean: `containsBook_of_le_commonNeighborCount`,
  `edgeBookCapB8_of_not_containsBook`, and
  `complementBookCapB10_of_not_containsBook_compl`.

* LaTeX equations `(trianglecaps)`, `(goodman)`, and `(quadraticineq)`.
  Lean: the unordered triangle counts are replaced by ordered counts to avoid
  divisions.  `orientedCommonNeighborSum G` is `6T`, the same expression for
  `G^c` is `6 Tbar`, and `actualDegreeProductSum G` is
  `sum_x d(x)(36-d(x))`.  The ordered Goodman identity is
  `goodman_actual`, and the final inequality is
  `quadratic_ineq_of_actual_caps`.

* LaTeX: the quadratic `f(d) = 106d - 3d^2` has unique integer maximum at
  `d = 18`, so the graph is `18`-regular.
  Lean: `localQuadraticInt_le_936`,
  `localQuadraticInt_eq_936_iff`, and `regular_of_actual_caps`.

* LaTeX: equality propagates through the triangle caps, giving
  `c_G(u,v)=7` on edges, `c_{G^c}(u,v)=9` on complement edges, and then
  `c_G(u,v)=10` on nonedges.  Hence a counterexample would be
  `SRG(37,18,7,10)`.
  Lean: `commonNeighborCount_eq_7_of_actual_caps`,
  `commonNeighborCount_compl_eq_9_of_actual_caps`,
  `commonNeighborCount_eq_10_of_not_adj_of_compl_eq_9`, and
  `isSRGWith37_18_7_10_of_actual_caps`.

* LaTeX: the spectral contradiction uses irrational conjugate eigenvalues
  `(-3 +- sqrt(41))/2`.
  Lean: `no_isSRGWith37_18_7_10` proves an equivalent obstruction over
  `ZMod 41`.  Reducing modulo the discriminant turns the nontrivial
  eigenvalue polynomial into a repeated-root/nilpotent condition; the trace of
  the resulting nilpotent matrix is forced to be both zero and nonzero.
-/

open scoped BigOperators
open Finset

namespace RamseyLean

namespace Actual

/-!
## Ordered counting objects

The paper writes `T` and `Tbar` for ordinary triangle counts.  Lean instead
counts ordered triples of distinct vertices.  This makes Goodman's identity
integer-valued throughout:

* one triangle contributes `6` ordered monochromatic triples;
* the mixed term `actualDegreeProductSum` is already naturally ordered by a
  chosen first vertex, a neighbor, and a nonneighbor.
-/

abbrev Triple := Vertex × Vertex × Vertex

def first (t : Triple) : Vertex := t.1
def second (t : Triple) : Vertex := t.2.1
def third (t : Triple) : Vertex := t.2.2

def PairwiseDistinct (t : Triple) : Prop :=
  first t ≠ second t ∧ first t ≠ third t ∧ second t ≠ third t

instance instDecidablePairwiseDistinct (t : Triple) : Decidable (PairwiseDistinct t) := by
  unfold PairwiseDistinct
  infer_instance

def orderedTriples : Finset Triple :=
  (Finset.univ : Finset Triple).filter PairwiseDistinct

theorem orderedTriples_card : #orderedTriples = 46620 := by
  native_decide

def adjInt (G : SimpleGraph Vertex) [DecidableRel G.Adj] (u v : Vertex) : Int :=
  if G.Adj u v then 1 else 0

def orderedTriangleIndicator (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (t : Triple) : Int :=
  if G.Adj (first t) (second t) ∧
      G.Adj (first t) (third t) ∧
      G.Adj (second t) (third t) then
    1
  else
    0

def orderedMixedIndicator (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (t : Triple) : Int :=
  if G.Adj (first t) (second t) ∧ Gᶜ.Adj (first t) (third t) then
    1
  else
    0

def orderedTriangleCount (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Int :=
  orderedTriples.sum fun t => orderedTriangleIndicator G t

def orderedMixedCount (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Int :=
  orderedTriples.sum fun t => orderedMixedIndicator G t

def orientedCommonNeighborSum (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Nat :=
  ∑ u : Vertex, (G.neighborFinset u).sum fun v => commonNeighborCount G u v

def triangleTripleCount (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Nat :=
  ∑ u : Vertex, ∑ v : Vertex, ∑ w : Vertex,
    if G.Adj u v ∧ G.Adj u w ∧ G.Adj v w then 1 else 0

def mixedTripleCount (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Nat :=
  ∑ u : Vertex, ∑ v : Vertex, ∑ w : Vertex,
    if G.Adj u v ∧ Gᶜ.Adj u w then 1 else 0

def actualDegreeProductSum (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Nat :=
  ∑ u : Vertex, G.degree u * Gᶜ.degree u

def localQuadraticInt (d : Fin 37) : Int :=
  106 * (d.val : Int) - 3 * (d.val : Int) * (d.val : Int)

def degreeQuadraticTermInt (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (v : Vertex) : Int :=
  localQuadraticInt (degreeFin G v)

def degreeQuadraticSumInt (G : SimpleGraph Vertex) [DecidableRel G.Adj] : Int :=
  ∑ v : Vertex, degreeQuadraticTermInt G v

/-!
## The quadratic maximum

This block formalizes the paragraph after LaTeX equation `(quadraticineq)`.
The type `Fin 37` packages the fact that every degree is one of the integers
`0, ..., 36`; `decide +revert` checks the finite arithmetic statement that
`106d - 3d^2 <= 936`, with equality exactly at `d = 18`.
-/

theorem localQuadraticInt_le_936 (d : Fin 37) : localQuadraticInt d ≤ 936 := by
  decide +revert

theorem localQuadraticInt_eq_936_iff (d : Fin 37) :
    localQuadraticInt d = 936 ↔ d.val = 18 := by
  decide +revert

theorem degreeQuadraticSumInt_le
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    degreeQuadraticSumInt G ≤ 34632 := by
  unfold degreeQuadraticSumInt degreeQuadraticTermInt
  calc
    (∑ v : Vertex, localQuadraticInt (degreeFin G v)) ≤ ∑ _v : Vertex, (936 : Int) := by
      exact Finset.sum_le_sum fun v _hv => localQuadraticInt_le_936 (degreeFin G v)
    _ = 34632 := by
      simp [Vertex, Fintype.card_fin]

theorem regular_of_quadratic_ineq_int
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hquad : (34632 : Int) ≤ degreeQuadraticSumInt G) :
    G.IsRegularOfDegree 18 := by
  intro v
  have hle_terms :
      ∀ x ∈ (Finset.univ : Finset Vertex), degreeQuadraticTermInt G x ≤ 936 := by
    intro x _hx
    exact localQuadraticInt_le_936 (degreeFin G x)
  have hsum_le : degreeQuadraticSumInt G ≤ ∑ _x : Vertex, (936 : Int) := by
    unfold degreeQuadraticSumInt
    exact Finset.sum_le_sum hle_terms
  have hconst : (∑ _x : Vertex, (936 : Int)) = 34632 := by
    simp [Vertex, Fintype.card_fin]
  have hsum_eq : degreeQuadraticSumInt G = ∑ _x : Vertex, (936 : Int) := by
    omega
  have hall :
      ∀ x ∈ (Finset.univ : Finset Vertex), degreeQuadraticTermInt G x = 936 := by
    exact (Finset.sum_eq_sum_iff_of_le hle_terms).mp hsum_eq
  have hterm : degreeQuadraticTermInt G v = 936 :=
    hall v (Finset.mem_univ v)
  have hval : (degreeFin G v).val = 18 :=
    (localQuadraticInt_eq_936_iff (degreeFin G v)).mp hterm
  simpa [degreeFin] using hval

theorem commonNeighborCount_eq_filter_card
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] (u v : Vertex) :
    commonNeighborCount G u v =
      #({w | G.Adj u w ∧ G.Adj v w} : Finset Vertex) := by
  unfold commonNeighborCount
  change Fintype.card {w : Vertex // w ∈ G.commonNeighbors u v} =
    #({w | G.Adj u w ∧ G.Adj v w} : Finset Vertex)
  rw [Fintype.card_subtype]
  rfl

/--
LaTeX correspondence: the sentence "if an edge `uv` has at least `n` common
neighbors, then those common neighbors together with `uv` form a copy of
`B_n`."

The proof constructs an explicit `SimpleGraph.Copy` of `bookGraph n`:
vertices `0` and `1` of the book are sent to the spine edge `u,v`, and the
remaining book vertices are injected into the common-neighbor set.
-/
theorem containsBook_of_le_commonNeighborCount
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] {n : Nat} {u v : Vertex}
    (huv : G.Adj u v) (hle : n ≤ commonNeighborCount G u v) :
    ContainsBook n G := by
  classical
  have hle' : Fintype.card (Fin n) ≤
      #({w | G.Adj u w ∧ G.Adj v w} : Finset Vertex) := by
    simpa [Fintype.card_fin, commonNeighborCount_eq_filter_card G u v] using hle
  obtain ⟨pages, hpages_subset⟩ :=
    Function.Embedding.exists_of_card_le_finset (α := Fin n)
      (s := ({w | G.Adj u w ∧ G.Adj v w} : Finset Vertex)) hle'
  let spine0 : Fin (n + 2) := ⟨0, by omega⟩
  let spine1 : Fin (n + 2) := ⟨1, by omega⟩
  let pageIndex (i : Fin (n + 2)) (h0 : i ≠ spine0) (h1 : i ≠ spine1) : Fin n :=
    ⟨i.val - 2, by
      have hi0 : i.val ≠ 0 := by
        intro h
        exact h0 (Fin.ext h)
      have hi1 : i.val ≠ 1 := by
        intro h
        exact h1 (Fin.ext h)
      omega⟩
  let φ : Fin (n + 2) → Vertex := fun i =>
    if _h0 : i = spine0 then
      u
    else if _h1 : i = spine1 then
      v
    else
      pages ⟨i.val - 2, by
        have hi0 : i.val ≠ 0 := by
          intro h
          exact _h0 (Fin.ext h)
        have hi1 : i.val ≠ 1 := by
          intro h
          exact _h1 (Fin.ext h)
        omega⟩
  have hpages_adj : ∀ i : Fin n, G.Adj u (pages i) ∧ G.Adj v (pages i) := by
    intro i
    have hi : pages i ∈ ({w | G.Adj u w ∧ G.Adj v w} : Finset Vertex) :=
      hpages_subset (Set.mem_range_self i)
    simpa using hi
  have hspine1_ne_spine0 : spine1 ≠ spine0 := by
    intro h
    have hval := congrArg Fin.val h
    simp [spine0, spine1] at hval
  have hφ0 : φ spine0 = u := by
    simp [φ, spine0]
  have hφ1 : φ spine1 = v := by
    simp [φ, hspine1_ne_spine0]
  have hφ_page
      (i : Fin (n + 2)) (h0 : i ≠ spine0) (h1 : i ≠ spine1) :
      φ i = pages (pageIndex i h0 h1) := by
    simp [φ, pageIndex, h0, h1]
  have hφ_injective : Function.Injective φ := by
    intro a b hab
    by_cases ha0 : a = spine0
    · by_cases hb0 : b = spine0
      · exact ha0.trans hb0.symm
      · by_cases hb1 : b = spine1
        · have hφa : φ a = u := by rw [ha0]; exact hφ0
          have hφb : φ b = v := by rw [hb1]; exact hφ1
          have huv_eq : u = v := by simpa [hφa, hφb] using hab
          exact (huv.ne huv_eq).elim
        · have hφa : φ a = u := by rw [ha0]; exact hφ0
          have hφb : φ b = pages (pageIndex b hb0 hb1) := hφ_page b hb0 hb1
          have hpage_eq : pages (pageIndex b hb0 hb1) = u := by
            simpa [hφa, hφb] using hab.symm
          have hloop : G.Adj u u := by
            simpa [hpage_eq] using (hpages_adj (pageIndex b hb0 hb1)).1
          exact (G.loopless.irrefl u hloop).elim
    · by_cases ha1 : a = spine1
      · by_cases hb0 : b = spine0
        · have hφa : φ a = v := by rw [ha1]; exact hφ1
          have hφb : φ b = u := by rw [hb0]; exact hφ0
          have hvu_eq : v = u := by simpa [hφa, hφb] using hab
          exact (huv.ne hvu_eq.symm).elim
        · by_cases hb1 : b = spine1
          · exact ha1.trans hb1.symm
          · have hφa : φ a = v := by rw [ha1]; exact hφ1
            have hφb : φ b = pages (pageIndex b hb0 hb1) := hφ_page b hb0 hb1
            have hpage_eq : pages (pageIndex b hb0 hb1) = v := by
              simpa [hφa, hφb] using hab.symm
            have hloop : G.Adj v v := by
              simpa [hpage_eq] using (hpages_adj (pageIndex b hb0 hb1)).2
            exact (G.loopless.irrefl v hloop).elim
      · by_cases hb0 : b = spine0
        · have hφa : φ a = pages (pageIndex a ha0 ha1) := hφ_page a ha0 ha1
          have hφb : φ b = u := by rw [hb0]; exact hφ0
          have hpage_eq : pages (pageIndex a ha0 ha1) = u := by
            simpa [hφa, hφb] using hab
          have hloop : G.Adj u u := by
            simpa [hpage_eq] using (hpages_adj (pageIndex a ha0 ha1)).1
          exact (G.loopless.irrefl u hloop).elim
        · by_cases hb1 : b = spine1
          · have hφa : φ a = pages (pageIndex a ha0 ha1) := hφ_page a ha0 ha1
            have hφb : φ b = v := by rw [hb1]; exact hφ1
            have hpage_eq : pages (pageIndex a ha0 ha1) = v := by
              simpa [hφa, hφb] using hab
            have hloop : G.Adj v v := by
              simpa [hpage_eq] using (hpages_adj (pageIndex a ha0 ha1)).2
            exact (G.loopless.irrefl v hloop).elim
          · have hφa : φ a = pages (pageIndex a ha0 ha1) := hφ_page a ha0 ha1
            have hφb : φ b = pages (pageIndex b hb0 hb1) := hφ_page b hb0 hb1
            have hidx : pageIndex a ha0 ha1 = pageIndex b hb0 hb1 :=
              pages.injective (by simpa [hφa, hφb] using hab)
            exact Fin.ext (by
              have hval := congrArg Fin.val hidx
              simp [pageIndex] at hval
              have ha0v : a.val ≠ 0 := by
                intro h
                exact ha0 (Fin.ext h)
              have ha1v : a.val ≠ 1 := by
                intro h
                exact ha1 (Fin.ext h)
              have hb0v : b.val ≠ 0 := by
                intro h
                exact hb0 (Fin.ext h)
              have hb1v : b.val ≠ 1 := by
                intro h
                exact hb1 (Fin.ext h)
              omega)
  let ψ : bookGraph n →g G := {
    toFun := φ
    map_rel' := by
      intro x y hxy
      rcases hxy with ⟨hxy_ne, hspine⟩
      by_cases hx0 : x = spine0
      · by_cases hy0 : y = spine0
        · exact (hxy_ne (hx0.trans hy0.symm)).elim
        · by_cases hy1 : y = spine1
          · have hφx : φ x = u := by rw [hx0]; exact hφ0
            have hφy : φ y = v := by rw [hy1]; exact hφ1
            simpa [hφx, hφy] using huv
          · have hφx : φ x = u := by rw [hx0]; exact hφ0
            have hφy : φ y = pages (pageIndex y hy0 hy1) := hφ_page y hy0 hy1
            simpa [hφx, hφy] using (hpages_adj (pageIndex y hy0 hy1)).1
      · by_cases hx1 : x = spine1
        · by_cases hy0 : y = spine0
          · have hφx : φ x = v := by rw [hx1]; exact hφ1
            have hφy : φ y = u := by rw [hy0]; exact hφ0
            simpa [hφx, hφy] using huv.symm
          · by_cases hy1 : y = spine1
            · exact (hxy_ne (hx1.trans hy1.symm)).elim
            · have hφx : φ x = v := by rw [hx1]; exact hφ1
              have hφy : φ y = pages (pageIndex y hy0 hy1) := hφ_page y hy0 hy1
              simpa [hφx, hφy] using (hpages_adj (pageIndex y hy0 hy1)).2
        · have hx0v : x.val ≠ 0 := by
            intro h
            exact hx0 (Fin.ext h)
          have hx1v : x.val ≠ 1 := by
            intro h
            exact hx1 (Fin.ext h)
          have hy_le : y.val ≤ 1 := by
            rcases hspine with hx_le | hy_le
            · omega
            · exact hy_le
          have hy_eq : y = spine0 ∨ y = spine1 := by
            have hy_val : y.val = 0 ∨ y.val = 1 := by omega
            rcases hy_val with hy_val | hy_val
            · exact Or.inl (Fin.ext hy_val)
            · exact Or.inr (Fin.ext hy_val)
          rcases hy_eq with hy0 | hy1
          · have hφx : φ x = pages (pageIndex x hx0 hx1) := hφ_page x hx0 hx1
            have hφy : φ y = u := by rw [hy0]; exact hφ0
            simpa [hφx, hφy] using (hpages_adj (pageIndex x hx0 hx1)).1.symm
          · have hφx : φ x = pages (pageIndex x hx0 hx1) := hφ_page x hx0 hx1
            have hφy : φ y = v := by rw [hy1]; exact hφ1
            simpa [hφx, hφy] using (hpages_adj (pageIndex x hx0 hx1)).2.symm
  }
  exact ⟨ψ, by
    change Function.Injective φ
    exact hφ_injective⟩

/--
LaTeX correspondence: "Because `G` contains no `B_8`, every edge satisfies
`c_G(u,v) <= 7`."
-/
theorem edgeBookCapB8_of_not_containsBook
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hno : ¬ ContainsBook 8 G) : edgeBookCapB8 G := by
  intro u v huv
  by_contra hle
  have hge : 8 ≤ commonNeighborCount G u v := by omega
  exact hno (containsBook_of_le_commonNeighborCount G huv hge)

/--
LaTeX correspondence: "Because `Gbar` contains no `B_10`, every edge of
`Gbar` has at most `9` common neighbors in `Gbar`."
-/
theorem complementBookCapB10_of_not_containsBook_compl
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hno : ¬ ContainsBook 10 Gᶜ) : complementBookCapB10 G := by
  intro u v huv
  by_contra hle
  have hge : 10 ≤ commonNeighborCount Gᶜ u v := by omega
  exact hno (containsBook_of_le_commonNeighborCount Gᶜ huv hge)

/-!
## Translating triangle and mixed counts

The next two theorems identify the algebraic objects used later:

* `orientedCommonNeighborSum_eq_triangleTripleCount` says that summing
  common-neighbor counts over oriented edges is the ordered triangle count.
  This is the Lean version of `3T = sum_{uv in E(G)} c_G(u,v)`, multiplied by
  `2` because ordered edges are used.
* `actualDegreeProductSum_eq_mixedTripleCount` says
  `sum_x d(x)d_{G^c}(x)` counts ordered mixed triples.  This is the degree
  product in Goodman's identity.
-/

set_option maxHeartbeats 400000 in
theorem orientedCommonNeighborSum_eq_triangleTripleCount
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orientedCommonNeighborSum G = triangleTripleCount G := by
  classical
  unfold orientedCommonNeighborSum triangleTripleCount
  simp_rw [commonNeighborCount_eq_filter_card, SimpleGraph.neighborFinset_eq_filter]
  simp_rw [Finset.card_eq_sum_ones]
  simp [Finset.sum_filter]
  refine Finset.sum_congr rfl ?_
  intro u _hu
  refine Finset.sum_congr rfl ?_
  intro v _hv
  by_cases huv : G.Adj u v
  · simp [huv]
  · simp [huv]

theorem actualDegreeProductSum_eq_mixedTripleCount
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    actualDegreeProductSum G = mixedTripleCount G := by
  classical
  unfold actualDegreeProductSum mixedTripleCount
  simp_rw [SimpleGraph.degree, SimpleGraph.neighborFinset_eq_filter]
  simp
  refine Finset.sum_congr rfl ?_
  intro u _hu
  let N : Finset Vertex := {w | G.Adj u w}
  let C : Finset Vertex := {w | ¬u = w ∧ ¬G.Adj u w}
  change #N * #C = ∑ x : Vertex, #({x_1 | G.Adj u x ∧ ¬u = x_1 ∧ ¬G.Adj u x_1} : Finset Vertex)
  calc
    #N * #C = N.sum fun _ => #C := by
      simp [N]
    _ = ∑ x : Vertex, if G.Adj u x then #C else 0 := by
      rw [← Finset.sum_filter (s := (Finset.univ : Finset Vertex))
        (p := fun x => G.Adj u x) (f := fun _ => #C)]
    _ = ∑ x : Vertex, #({x_1 | G.Adj u x ∧ ¬u = x_1 ∧ ¬G.Adj u x_1} : Finset Vertex) := by
      refine Finset.sum_congr rfl ?_
      intro x _hx
      by_cases hux : G.Adj u x
      · simp [hux, C]
      · simp [hux]

private theorem orderedTriangleIndicator_eq_zero_of_not_pairwise
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] (t : Triple)
    (h : ¬ PairwiseDistinct t) :
    orderedTriangleIndicator G t = 0 := by
  unfold orderedTriangleIndicator
  by_cases h₁₂ : first t = second t
  · simp [h₁₂]
  by_cases h₁₃ : first t = third t
  · simp [h₁₃]
  by_cases h₂₃ : second t = third t
  · simp [h₂₃]
  · exact (h ⟨h₁₂, h₁₃, h₂₃⟩).elim

private theorem orderedMixedIndicator_eq_zero_of_not_pairwise
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] (t : Triple)
    (h : ¬ PairwiseDistinct t) :
    orderedMixedIndicator G t = 0 := by
  unfold orderedMixedIndicator
  by_cases h₁₂ : first t = second t
  · simp [h₁₂]
  by_cases h₁₃ : first t = third t
  · simp [h₁₃]
  by_cases h₂₃ : second t = third t
  · by_cases hAdj : G.Adj (first t) (third t) <;>
      simp [h₂₃, SimpleGraph.compl_adj, h₁₃, hAdj]
  · exact (h ⟨h₁₂, h₁₃, h₂₃⟩).elim

theorem orderedTriangleCount_eq_univ_sum
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriangleCount G = ∑ t : Triple, orderedTriangleIndicator G t := by
  classical
  unfold orderedTriangleCount orderedTriples
  rw [Finset.sum_filter]
  refine Finset.sum_congr rfl ?_
  intro t _ht
  by_cases h : PairwiseDistinct t
  · simp [h]
  · simp [h, orderedTriangleIndicator_eq_zero_of_not_pairwise G t h]

theorem orderedMixedCount_eq_univ_sum
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedMixedCount G = ∑ t : Triple, orderedMixedIndicator G t := by
  classical
  unfold orderedMixedCount orderedTriples
  rw [Finset.sum_filter]
  refine Finset.sum_congr rfl ?_
  intro t _ht
  by_cases h : PairwiseDistinct t
  · simp [h]
  · simp [h, orderedMixedIndicator_eq_zero_of_not_pairwise G t h]

theorem orderedTriangleCount_eq_triangleTripleCount
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriangleCount G = (triangleTripleCount G : Int) := by
  classical
  rw [orderedTriangleCount_eq_univ_sum]
  unfold triangleTripleCount orderedTriangleIndicator first second third
  simp only [Fintype.sum_prod_type, Nat.cast_sum, Nat.cast_ite, Nat.cast_one, Nat.cast_zero]

theorem orderedMixedCount_eq_mixedTripleCount
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedMixedCount G = (mixedTripleCount G : Int) := by
  classical
  rw [orderedMixedCount_eq_univ_sum]
  unfold mixedTripleCount orderedMixedIndicator first second third
  simp only [Fintype.sum_prod_type, Nat.cast_sum, Nat.cast_ite, Nat.cast_one, Nat.cast_zero]

theorem orderedMixedCount_eq_actualDegreeProductSum
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedMixedCount G = (actualDegreeProductSum G : Int) := by
  rw [orderedMixedCount_eq_mixedTripleCount,
    actualDegreeProductSum_eq_mixedTripleCount]

theorem orderedTriangleCount_eq_orientedCommonNeighborSum
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriangleCount G = (orientedCommonNeighborSum G : Int) := by
  rw [orderedTriangleCount_eq_triangleTripleCount,
    orientedCommonNeighborSum_eq_triangleTripleCount]

/--
LaTeX correspondence: the first half of equation `(trianglecaps)`, written in
ordered form.  The right side is `7 * sum_x d(x) = 14e`, which is twice
LaTeX's `7e` bound because each edge is counted in both orientations.
-/
theorem orientedCommonNeighborSum_le_of_edgeBookCapB8
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hcap : edgeBookCapB8 G) :
    orientedCommonNeighborSum G ≤ 7 * ∑ u : Vertex, G.degree u := by
  unfold orientedCommonNeighborSum
  calc
    (∑ u : Vertex, (G.neighborFinset u).sum fun v => commonNeighborCount G u v)
        ≤ ∑ u : Vertex, (G.neighborFinset u).sum fun _v => 7 := by
      exact Finset.sum_le_sum fun u _hu =>
        Finset.sum_le_sum fun v hv => hcap u v (by simpa using hv)
    _ = 7 * ∑ u : Vertex, G.degree u := by
      simp [SimpleGraph.card_neighborFinset_eq_degree, Finset.mul_sum, mul_comm]

/--
LaTeX correspondence: the complement half of equation `(trianglecaps)`,
again in ordered form: `6 Tbar <= 9 * sum_x d_{G^c}(x)`.
-/
theorem orientedCommonNeighborSum_compl_le_of_complementBookCapB10
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hcap : complementBookCapB10 G) :
    orientedCommonNeighborSum Gᶜ ≤ 9 * ∑ u : Vertex, Gᶜ.degree u := by
  unfold orientedCommonNeighborSum
  calc
    (∑ u : Vertex, (Gᶜ.neighborFinset u).sum fun v => commonNeighborCount Gᶜ u v)
        ≤ ∑ u : Vertex, (Gᶜ.neighborFinset u).sum fun _v => 9 := by
      exact Finset.sum_le_sum fun u _hu =>
        Finset.sum_le_sum fun v hv => hcap u v (by simpa using hv)
    _ = 9 * ∑ u : Vertex, Gᶜ.degree u := by
      simp [SimpleGraph.card_neighborFinset_eq_degree, Finset.mul_sum, mul_comm]

private def swapSecondThird : Triple ≃ Triple where
  toFun t := (first t, third t, second t)
  invFun t := (first t, third t, second t)
  left_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl
  right_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl

private def cycleLeft : Triple ≃ Triple where
  toFun t := (second t, third t, first t)
  invFun t := (third t, first t, second t)
  left_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl
  right_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl

private def swapFirstSecond : Triple ≃ Triple where
  toFun t := (second t, first t, third t)
  invFun t := (second t, first t, third t)
  left_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl
  right_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl

private def rotateRight : Triple ≃ Triple where
  toFun t := (third t, first t, second t)
  invFun t := (second t, third t, first t)
  left_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl
  right_inv := by
    intro t
    rcases t with ⟨a, b, c⟩
    rfl

/-!
The following permutations of ordered triples are bookkeeping for Goodman.
They justify the symmetry cancellations that are implicit in the LaTeX phrase
"Goodman's identity gives ...".  After expanding the indicator functions into
`0`/`1` adjacency variables, these bijections show that the sums of the
linear and quadratic error terms match and cancel.
-/

private theorem map_orderedTriples_swapSecondThird :
    orderedTriples.map swapSecondThird.toEmbedding = orderedTriples := by
  ext t
  rcases t with ⟨a, b, c⟩
  simp [orderedTriples, PairwiseDistinct, swapSecondThird, first, second, third]
  aesop

private theorem map_orderedTriples_cycleLeft :
    orderedTriples.map cycleLeft.toEmbedding = orderedTriples := by
  ext t
  rcases t with ⟨a, b, c⟩
  simp [orderedTriples, PairwiseDistinct, cycleLeft, first, second, third]
  aesop

private theorem map_orderedTriples_swapFirstSecond :
    orderedTriples.map swapFirstSecond.toEmbedding = orderedTriples := by
  ext t
  rcases t with ⟨a, b, c⟩
  simp [orderedTriples, PairwiseDistinct, swapFirstSecond, first, second, third]
  aesop

private theorem map_orderedTriples_rotateRight :
    orderedTriples.map rotateRight.toEmbedding = orderedTriples := by
  ext t
  rcases t with ⟨a, b, c⟩
  simp [orderedTriples, PairwiseDistinct, rotateRight, first, second, third]
  aesop

private theorem sum_comp_equiv {β : Type*} [AddCommMonoid β]
    (e : Triple ≃ Triple) (hmap : orderedTriples.map e.toEmbedding = orderedTriples)
    (f : Triple → β) :
    orderedTriples.sum (fun t => f (e t)) = orderedTriples.sum f := by
  calc
    orderedTriples.sum (fun t => f (e t)) =
        (orderedTriples.map e.toEmbedding).sum f := by
      exact (Finset.sum_map orderedTriples e.toEmbedding f).symm
    _ = orderedTriples.sum f := by
      rw [hmap]

private theorem sum_adj_ac_eq_sum_adj_ab (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriples.sum (fun t => adjInt G (first t) (third t)) =
      orderedTriples.sum (fun t => adjInt G (first t) (second t)) := by
  simpa [swapSecondThird, first, second, third] using
    (sum_comp_equiv swapSecondThird map_orderedTriples_swapSecondThird
      (fun t => adjInt G (first t) (second t)))

private theorem sum_adj_bc_eq_sum_adj_ab (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriples.sum (fun t => adjInt G (second t) (third t)) =
      orderedTriples.sum (fun t => adjInt G (first t) (second t)) := by
  simpa [cycleLeft, first, second, third] using
    (sum_comp_equiv cycleLeft map_orderedTriples_cycleLeft
      (fun t => adjInt G (first t) (second t)))

private theorem sum_adj_ab_adj_bc_eq_sum_adj_ab_adj_ac
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriples.sum
        (fun t => adjInt G (first t) (second t) * adjInt G (second t) (third t)) =
      orderedTriples.sum
        (fun t => adjInt G (first t) (second t) * adjInt G (first t) (third t)) := by
  simpa [swapFirstSecond, first, second, third, adjInt, SimpleGraph.adj_comm, mul_comm,
    mul_left_comm, mul_assoc] using
    (sum_comp_equiv swapFirstSecond map_orderedTriples_swapFirstSecond
      (fun t => adjInt G (first t) (second t) * adjInt G (first t) (third t)))

private theorem sum_adj_ac_adj_bc_eq_sum_adj_ab_adj_ac
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriples.sum
        (fun t => adjInt G (first t) (third t) * adjInt G (second t) (third t)) =
      orderedTriples.sum
        (fun t => adjInt G (first t) (second t) * adjInt G (first t) (third t)) := by
  simpa [rotateRight, first, second, third, adjInt, SimpleGraph.adj_comm, mul_comm,
    mul_left_comm, mul_assoc] using
    (sum_comp_equiv rotateRight map_orderedTriples_rotateRight
      (fun t => adjInt G (first t) (second t) * adjInt G (first t) (third t)))

private theorem orderedTriangleIndicator_eq
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] (t : Triple) :
    orderedTriangleIndicator G t =
      adjInt G (first t) (second t) *
      adjInt G (first t) (third t) *
      adjInt G (second t) (third t) := by
  unfold orderedTriangleIndicator adjInt
  by_cases h₁ : G.Adj (first t) (second t) <;>
    by_cases h₂ : G.Adj (first t) (third t) <;>
    by_cases h₃ : G.Adj (second t) (third t) <;>
    simp [h₁, h₂, h₃]

private theorem orderedMixedIndicator_eq
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] (t : Triple)
    (ht : t ∈ orderedTriples) :
    orderedMixedIndicator G t =
      adjInt G (first t) (second t) *
      (1 - adjInt G (first t) (third t)) := by
  have hdist : PairwiseDistinct t := by
    simpa [orderedTriples] using ht
  rcases hdist with ⟨_h₁₂, h₁₃, _h₂₃⟩
  unfold orderedMixedIndicator adjInt
  by_cases h₁ : G.Adj (first t) (second t) <;>
    by_cases h₂ : G.Adj (first t) (third t) <;>
    simp [SimpleGraph.compl_adj, h₁₃, h₁, h₂]

private theorem adjInt_compl_eq
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] {u v : Vertex}
    (h : u ≠ v) :
    adjInt Gᶜ u v = 1 - adjInt G u v := by
  unfold adjInt
  by_cases huv : G.Adj u v <;> simp [SimpleGraph.compl_adj, h, huv]

private theorem orderedTriangleIndicator_compl_eq
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] (t : Triple)
    (ht : t ∈ orderedTriples) :
    orderedTriangleIndicator Gᶜ t =
      (1 - adjInt G (first t) (second t)) *
      (1 - adjInt G (first t) (third t)) *
      (1 - adjInt G (second t) (third t)) := by
  have hdist : PairwiseDistinct t := by
    simpa [orderedTriples] using ht
  unfold orderedTriangleIndicator adjInt
  rcases hdist with ⟨h₁₂, h₁₃, h₂₃⟩
  by_cases h₁ : G.Adj (first t) (second t) <;>
    by_cases h₂ : G.Adj (first t) (third t) <;>
    by_cases h₃ : G.Adj (second t) (third t) <;>
    simp [SimpleGraph.compl_adj, h₁₂, h₁₃, h₂₃, h₁, h₂, h₃]

private theorem orderedTriangleAdjInt_compl_sum_eq
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriples.sum
        (fun t =>
          adjInt Gᶜ (first t) (second t) *
          adjInt Gᶜ (first t) (third t) *
          adjInt Gᶜ (second t) (third t)) =
      orderedTriples.sum
        (fun t =>
          (1 - adjInt G (first t) (second t)) *
          (1 - adjInt G (first t) (third t)) *
          (1 - adjInt G (second t) (third t))) := by
  refine Finset.sum_congr rfl ?_
  intro t ht
  have hdist : PairwiseDistinct t := by
    simpa [orderedTriples] using ht
  rcases hdist with ⟨h₁₂, h₁₃, h₂₃⟩
  rw [adjInt_compl_eq G h₁₂, adjInt_compl_eq G h₁₃, adjInt_compl_eq G h₂₃]

/--
LaTeX correspondence: equation `(goodman)`, multiplied by `6`.

In paper notation this theorem is

`6T + 6 Tbar + 3 * sum_x d(x)(36-d(x)) = 6 * binom(37,3)`.

The right side is `46620`.  The mixed term has coefficient `3` because each
unordered triple with exactly one or two edges contributes three ordered
choices of the distinguished vertex.
-/
theorem goodman_ordered
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    orderedTriangleCount G + orderedTriangleCount Gᶜ + 3 * orderedMixedCount G = 46620 := by
  classical
  simp only [orderedTriangleCount, orderedMixedCount]
  simp_rw [orderedTriangleIndicator_eq]
  rw [orderedTriangleAdjInt_compl_sum_eq G]
  have hmixed :
      orderedTriples.sum (fun t => orderedMixedIndicator G t) =
        orderedTriples.sum
          (fun t => adjInt G (first t) (second t) *
            (1 - adjInt G (first t) (third t))) := by
    exact Finset.sum_congr rfl fun t ht => orderedMixedIndicator_eq G t ht
  rw [hmixed]
  let A : Triple → Int := fun t => adjInt G (first t) (second t)
  let B : Triple → Int := fun t => adjInt G (first t) (third t)
  let C : Triple → Int := fun t => adjInt G (second t) (third t)
  have hB : orderedTriples.sum B = orderedTriples.sum A := by
    simpa [A, B] using sum_adj_ac_eq_sum_adj_ab G
  have hC : orderedTriples.sum C = orderedTriples.sum A := by
    simpa [A, C] using sum_adj_bc_eq_sum_adj_ab G
  have hAC : orderedTriples.sum (fun t => A t * C t) =
      orderedTriples.sum (fun t => A t * B t) := by
    simpa [A, B, C] using sum_adj_ab_adj_bc_eq_sum_adj_ab_adj_ac G
  have hBC : orderedTriples.sum (fun t => B t * C t) =
      orderedTriples.sum (fun t => A t * B t) := by
    simpa [A, B, C, mul_comm, mul_left_comm, mul_assoc] using
      sum_adj_ac_adj_bc_eq_sum_adj_ab_adj_ac G
  calc
    orderedTriples.sum (fun t => A t * B t * C t) +
        orderedTriples.sum (fun t => (1 - A t) * (1 - B t) * (1 - C t)) +
        3 * orderedTriples.sum (fun t => A t * (1 - B t))
        =
          orderedTriples.sum
            (fun t =>
              A t * B t * C t +
                (1 - A t) * (1 - B t) * (1 - C t) +
                3 * (A t * (1 - B t))) := by
          rw [mul_sum]
          rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
    _ =
          orderedTriples.sum
            (fun t =>
              (1 : Int) + (2 * A t - B t - C t) +
                (A t * C t + B t * C t - 2 * (A t * B t))) := by
          refine Finset.sum_congr rfl ?_
          intro t _ht
          ring
    _ = orderedTriples.sum fun _t => (1 : Int) := by
          simp_rw [Finset.sum_add_distrib, Finset.sum_sub_distrib]
          rw [Finset.sum_add_distrib]
          repeat rw [← mul_sum]
          rw [hB, hC, hAC, hBC]
          ring
    _ = 46620 := by
      simp [orderedTriples_card]

theorem goodman_actual
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    (orientedCommonNeighborSum G : Int) +
        (orientedCommonNeighborSum Gᶜ : Int) +
        3 * (actualDegreeProductSum G : Int) = 46620 := by
  have h := goodman_ordered G
  rw [orderedTriangleCount_eq_orientedCommonNeighborSum G,
    orderedTriangleCount_eq_orientedCommonNeighborSum Gᶜ,
    orderedMixedCount_eq_actualDegreeProductSum G] at h
  exact h

/--
Algebraic bridge to LaTeX equation `(quadraticineq)`.

For each vertex degree `d`,

`106d - 3d^2 + 2d = 3*d*(36-d)`.

After summing over vertices, this rewrites the Goodman degree-product term
into the quadratic expression used in the LaTeX proof.
-/
theorem actual_quadratic_relation_int
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    degreeQuadraticSumInt G + 2 * (∑ v : Vertex, (G.degree v : Int)) =
      3 * (actualDegreeProductSum G : Int) := by
  unfold degreeQuadraticSumInt actualDegreeProductSum degreeQuadraticTermInt
  rw [mul_sum, Nat.cast_sum, mul_sum, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl ?_
  intro v _hv
  have hdc : Gᶜ.degree v = 36 - G.degree v := by
    simpa [Vertex, Nat.sub_sub] using (SimpleGraph.degree_compl (G := G) (v := v))
  have hdeg_le : G.degree v ≤ 36 := by
    have hlt : G.degree v < 37 := by
      simpa [Vertex] using G.degree_lt_card_verts v
    omega
  have hcast_sub : ((36 - G.degree v : Nat) : Int) = 36 - (G.degree v : Int) :=
    Nat.cast_sub hdeg_le
  have hlocal (d : Fin 37) :
      localQuadraticInt d + 2 * (d.val : Int) =
        3 * ((d.val : Int) * (36 - (d.val : Int))) := by
    decide +revert
  simpa [localQuadraticInt, degreeFin, hdc, Nat.cast_mul, Nat.cast_sub,
    hcast_sub, Nat.cast_ofNat] using hlocal (degreeFin G v)

theorem sum_degrees_compl_add_sum_degrees
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    (∑ v : Vertex, Gᶜ.degree v) + (∑ v : Vertex, G.degree v) = 1332 := by
  rw [← Finset.sum_add_distrib]
  calc
    (∑ v : Vertex, (Gᶜ.degree v + G.degree v)) = ∑ _v : Vertex, 36 := by
      refine Finset.sum_congr rfl ?_
      intro v _hv
      have hdc : Gᶜ.degree v = 36 - G.degree v := by
        simpa [Vertex, Nat.sub_sub] using (SimpleGraph.degree_compl (G := G) (v := v))
      have hdeg_le : G.degree v ≤ 36 := by
        have hlt : G.degree v < 37 := by
          simpa [Vertex] using G.degree_lt_card_verts v
        omega
      omega
    _ = 1332 := by
      simp [Vertex, Fintype.card_fin]

/--
LaTeX correspondence: combine `(trianglecaps)`, `(goodman)`,
`ebar = binom(37,2)-e`, and `2e = sum_x d(x)` to obtain
equation `(quadraticineq)`.

In Lean this is done in ordered form.  The hypotheses `hB8` and `hB10` are the
two book caps; `goodman_actual` is the ordered Goodman identity; and
`actual_quadratic_relation_int` performs the final algebraic rewrite.
-/
theorem quadratic_ineq_of_actual_caps
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hB8 : edgeBookCapB8 G)
    (hB10 : complementBookCapB10 G) :
    (34632 : Int) ≤ degreeQuadraticSumInt G := by
  have hgood := goodman_actual G
  have hcapG_nat := orientedCommonNeighborSum_le_of_edgeBookCapB8 G hB8
  have hcapC_nat := orientedCommonNeighborSum_compl_le_of_complementBookCapB10 G hB10
  have hcapG :
      (orientedCommonNeighborSum G : Int) ≤
        7 * (∑ v : Vertex, (G.degree v : Int)) := by
    exact_mod_cast hcapG_nat
  have hcapC :
      (orientedCommonNeighborSum Gᶜ : Int) ≤
        9 * (∑ v : Vertex, (Gᶜ.degree v : Int)) := by
    exact_mod_cast hcapC_nat
  have hsumC_nat := sum_degrees_compl_add_sum_degrees G
  have hsumC :
      (∑ v : Vertex, (Gᶜ.degree v : Int)) +
        (∑ v : Vertex, (G.degree v : Int)) = 1332 := by
    exact_mod_cast hsumC_nat
  have hquadrel := actual_quadratic_relation_int G
  omega

theorem regular_of_actual_caps
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hB8 : edgeBookCapB8 G)
    (hB10 : complementBookCapB10 G) :
    G.IsRegularOfDegree 18 :=
  regular_of_quadratic_ineq_int G (quadratic_ineq_of_actual_caps G hB8 hB10)

/-!
## Equality propagation after regularity

This section formalizes the part of the LaTeX proof beginning with
"Thus `G` is `18`-regular" and ending with the forced
`SRG(37,18,7,10)`.

Once all degrees are `18`, the two sides of Goodman's identity and the two
book-cap inequalities have the same total value.  Since every summand is
bounded above by the appropriate cap, equality of the sums forces equality
term by term:

* each edge has exactly `7` common neighbors;
* each complement edge has exactly `9` complement-common-neighbors;
* each nonedge of `G` then has exactly `10` common neighbors in `G`.
-/

theorem sum_degrees_eq_of_regular_18
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18) :
    (∑ v : Vertex, G.degree v) = 666 := by
  calc
    (∑ v : Vertex, G.degree v) = ∑ _v : Vertex, 18 := by
      exact Finset.sum_congr rfl fun v _hv => hreg v
    _ = 666 := by
      simp [Vertex, Fintype.card_fin]

theorem compl_regular_of_regular_18
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18) :
    Gᶜ.IsRegularOfDegree 18 := by
  intro v
  have hdc : Gᶜ.degree v = 36 - G.degree v := by
    simpa [Vertex, Nat.sub_sub] using (SimpleGraph.degree_compl (G := G) (v := v))
  rw [hreg v] at hdc
  simpa using hdc

theorem actualDegreeProductSum_eq_of_regular_18
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18) :
    actualDegreeProductSum G = 11988 := by
  have hregC := compl_regular_of_regular_18 G hreg
  unfold actualDegreeProductSum
  calc
    (∑ v : Vertex, G.degree v * Gᶜ.degree v) =
        ∑ _v : Vertex, 18 * 18 := by
      exact Finset.sum_congr rfl fun v _hv => by rw [hreg v, hregC v]
    _ = 11988 := by
      simp [Vertex, Fintype.card_fin]

/--
LaTeX correspondence: after substituting the `18`-regular degree sequence,
Goodman's identity and the cap estimates both evaluate to equality.

In ordered form the exact totals are `4662` for `G` and `5994` for `G^c`;
these are `6T = 6*777` and `6Tbar = 6*999`.
-/
theorem orientedCommonNeighborSum_eq_of_actual_caps
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18)
    (hB8 : edgeBookCapB8 G)
    (hB10 : complementBookCapB10 G) :
    orientedCommonNeighborSum G = 4662 ∧ orientedCommonNeighborSum Gᶜ = 5994 := by
  have hsumD := sum_degrees_eq_of_regular_18 G hreg
  have hsumDC : (∑ v : Vertex, Gᶜ.degree v) = 666 := by
    have hsum := sum_degrees_compl_add_sum_degrees G
    omega
  have hprod := actualDegreeProductSum_eq_of_regular_18 G hreg
  have hgood := goodman_actual G
  have hcapG := orientedCommonNeighborSum_le_of_edgeBookCapB8 G hB8
  have hcapC := orientedCommonNeighborSum_compl_le_of_complementBookCapB10 G hB10
  constructor <;> omega

/--
LaTeX correspondence: equation `(lambda)`, `c_G(u,v)=7` for every edge.

The proof uses a common Lean pattern for "sum of bounded terms reaches the
sum of the bounds": first force equality in the outer sum over vertices, then
force equality in the inner sum over neighbors.
-/
theorem commonNeighborCount_eq_7_of_actual_caps
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18)
    (hB8 : edgeBookCapB8 G)
    (hB10 : complementBookCapB10 G)
    {u v : Vertex} (huv : G.Adj u v) :
    commonNeighborCount G u v = 7 := by
  have hO := (orientedCommonNeighborSum_eq_of_actual_caps G hreg hB8 hB10).1
  have hsumD := sum_degrees_eq_of_regular_18 G hreg
  have hconst :
      (∑ x : Vertex, (G.neighborFinset x).sum fun _y => 7) = 4662 := by
    calc
      (∑ x : Vertex, (G.neighborFinset x).sum fun _y => 7)
          = 7 * ∑ x : Vertex, G.degree x := by
            simp [SimpleGraph.card_neighborFinset_eq_degree, Finset.mul_sum, mul_comm]
      _ = 4662 := by omega
  have hsum_eq :
      (∑ x : Vertex, (G.neighborFinset x).sum fun y => commonNeighborCount G x y) =
        ∑ x : Vertex, (G.neighborFinset x).sum fun _y => 7 := by
    simpa [orientedCommonNeighborSum] using hO.trans hconst.symm
  have houter_le :
      ∀ x ∈ (Finset.univ : Finset Vertex),
        (G.neighborFinset x).sum (fun y => commonNeighborCount G x y) ≤
          (G.neighborFinset x).sum fun _y => 7 := by
    intro x _hx
    exact Finset.sum_le_sum fun y hy => hB8 x y (by simpa using hy)
  have houter_eq :
      ∀ x ∈ (Finset.univ : Finset Vertex),
        (G.neighborFinset x).sum (fun y => commonNeighborCount G x y) =
          (G.neighborFinset x).sum fun _y => 7 := by
    exact (Finset.sum_eq_sum_iff_of_le houter_le).mp hsum_eq
  have hu_eq := houter_eq u (Finset.mem_univ u)
  have hinner_le :
      ∀ y ∈ G.neighborFinset u, commonNeighborCount G u y ≤ 7 := by
    intro y hy
    exact hB8 u y (by simpa using hy)
  have hinner_eq :
      ∀ y ∈ G.neighborFinset u, commonNeighborCount G u y = 7 := by
    exact (Finset.sum_eq_sum_iff_of_le hinner_le).mp hu_eq
  exact hinner_eq v (by simpa using huv)

/--
LaTeX correspondence: equation `(cn)`, `c_{Gbar}(u,v)=9` for every complement
edge.  This is the same equality-in-a-sum argument as the previous theorem,
applied to `G^c`.
-/
theorem commonNeighborCount_compl_eq_9_of_actual_caps
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18)
    (hB8 : edgeBookCapB8 G)
    (hB10 : complementBookCapB10 G)
    {u v : Vertex} (huv : Gᶜ.Adj u v) :
    commonNeighborCount Gᶜ u v = 9 := by
  have hO := (orientedCommonNeighborSum_eq_of_actual_caps G hreg hB8 hB10).2
  have hregC := compl_regular_of_regular_18 G hreg
  have hsumD := sum_degrees_eq_of_regular_18 Gᶜ hregC
  have hconst :
      (∑ x : Vertex, (Gᶜ.neighborFinset x).sum fun _y => 9) = 5994 := by
    calc
      (∑ x : Vertex, (Gᶜ.neighborFinset x).sum fun _y => 9)
          = 9 * ∑ x : Vertex, Gᶜ.degree x := by
            simp [SimpleGraph.card_neighborFinset_eq_degree, Finset.mul_sum, mul_comm]
      _ = 5994 := by omega
  have hsum_eq :
      (∑ x : Vertex, (Gᶜ.neighborFinset x).sum fun y => commonNeighborCount Gᶜ x y) =
        ∑ x : Vertex, (Gᶜ.neighborFinset x).sum fun _y => 9 := by
    simpa [orientedCommonNeighborSum] using hO.trans hconst.symm
  have houter_le :
      ∀ x ∈ (Finset.univ : Finset Vertex),
        (Gᶜ.neighborFinset x).sum (fun y => commonNeighborCount Gᶜ x y) ≤
          (Gᶜ.neighborFinset x).sum fun _y => 9 := by
    intro x _hx
    exact Finset.sum_le_sum fun y hy => hB10 x y (by simpa using hy)
  have houter_eq :
      ∀ x ∈ (Finset.univ : Finset Vertex),
        (Gᶜ.neighborFinset x).sum (fun y => commonNeighborCount Gᶜ x y) =
          (Gᶜ.neighborFinset x).sum fun _y => 9 := by
    exact (Finset.sum_eq_sum_iff_of_le houter_le).mp hsum_eq
  have hu_eq := houter_eq u (Finset.mem_univ u)
  have hinner_le :
      ∀ y ∈ Gᶜ.neighborFinset u, commonNeighborCount Gᶜ u y ≤ 9 := by
    intro y hy
    exact hB10 u y (by simpa using hy)
  have hinner_eq :
      ∀ y ∈ Gᶜ.neighborFinset u, commonNeighborCount Gᶜ u y = 9 := by
    exact (Finset.sum_eq_sum_iff_of_le hinner_le).mp hu_eq
  exact hinner_eq v (by simpa using huv)

/--
LaTeX correspondence: for nonadjacent `u,v`, the paper writes
`|N(u) union N(v)| = 18 + 18 - c = 36 - c`.
-/
theorem card_neighborFinset_union_eq_of_regular_18
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18) (u v : Vertex) :
    #(G.neighborFinset u ∪ G.neighborFinset v) =
      36 - commonNeighborCount G u v := by
  unfold commonNeighborCount
  apply Nat.add_right_cancel (m := Fintype.card (G.commonNeighbors u v))
  rw [Nat.sub_add_cancel, ← Set.toFinset_card]
  · simp [SimpleGraph.commonNeighbors, ← SimpleGraph.neighborFinset_def,
      Finset.card_union_add_card_inter]
    rw [hreg u, hreg v]
  · apply le_trans (G.card_commonNeighbors_le_degree_left u v)
    rw [hreg u]
    omega

/--
LaTeX correspondence: among the remaining `35` vertices, the vertices
adjacent to neither `u` nor `v` are exactly the complement-common-neighbors.
This gives the formula used just before equation `(mu)`.
-/
theorem commonNeighborCount_compl_eq_card_compl_union_sub_two
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] {u v : Vertex}
    (hne : u ≠ v) (hna : ¬G.Adj u v) :
    commonNeighborCount Gᶜ u v =
      37 - #(G.neighborFinset u ∪ G.neighborFinset v) - 2 := by
  classical
  unfold commonNeighborCount
  simp only [← Set.toFinset_card, SimpleGraph.commonNeighbors, Set.toFinset_inter,
    SimpleGraph.neighborSet_compl, Set.toFinset_diff, Set.toFinset_singleton,
    Set.toFinset_compl, ← SimpleGraph.neighborFinset_def]
  simp_rw [SimpleGraph.compl_neighborFinset_sdiff_inter_eq]
  rw [Finset.card_sdiff_of_subset, ← Finset.insert_eq,
    Finset.card_insert_of_notMem, Finset.card_singleton, ← Finset.compl_union]
  · rw [Finset.card_compl]
    simp [Vertex, Fintype.card_fin]
  · simp [hne.symm]
  · intro x
    simp only [Finset.mem_union, Finset.mem_compl, SimpleGraph.mem_neighborFinset, Finset.mem_inter,
      Finset.mem_singleton]
    rintro (rfl | rfl) <;> simpa [SimpleGraph.adj_comm] using hna

/--
LaTeX correspondence: equation `(mu)`, `c_G(u,v)=10` for every nonedge.

The hypotheses say `u,v` are a nonedge in `G` and have `9` common neighbors
in `G^c`; the preceding two counting formulas reduce this to arithmetic.
-/
theorem commonNeighborCount_eq_10_of_not_adj_of_compl_eq_9
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hreg : G.IsRegularOfDegree 18) {u v : Vertex}
    (hne : u ≠ v) (hna : ¬G.Adj u v)
    (hcompl : commonNeighborCount Gᶜ u v = 9) :
    commonNeighborCount G u v = 10 := by
  have hunion := card_neighborFinset_union_eq_of_regular_18 G hreg u v
  have hcomp := commonNeighborCount_compl_eq_card_compl_union_sub_two G hne hna
  omega

/--
LaTeX correspondence: "Therefore any hypothetical witness would have to be a
strongly regular graph with parameters `(37,18,7,10)`."
-/
theorem isSRGWith37_18_7_10_of_actual_caps
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hB8 : edgeBookCapB8 G)
    (hB10 : complementBookCapB10 G) :
    G.IsSRGWith 37 18 7 10 := by
  have hreg := regular_of_actual_caps G hB8 hB10
  refine
    { card := by simp [Vertex, Fintype.card_fin]
      regular := hreg
      of_adj := ?_
      of_not_adj := ?_ }
  · intro u v huv
    simpa [commonNeighborCount] using
      commonNeighborCount_eq_7_of_actual_caps G hreg hB8 hB10 huv
  · intro u v hne hna
    have hcomp_adj : Gᶜ.Adj u v := by
      simp [SimpleGraph.compl_adj, hne, hna]
    have hcomp :
        commonNeighborCount Gᶜ u v = 9 :=
      commonNeighborCount_compl_eq_9_of_actual_caps G hreg hB8 hB10 hcomp_adj
    simpa [commonNeighborCount] using
      commonNeighborCount_eq_10_of_not_adj_of_compl_eq_9 G hreg hne hna hcomp

private theorem zmod41_81_eq_40 : (81 : ZMod 41) = 40 := by
  native_decide

private theorem zmod41_14719_eq_zero : (14719 : ZMod 41) = 0 := by
  native_decide

private theorem zmod41_neg666_eq_31 : (-666 : ZMod 41) = 31 := by
  native_decide

private theorem zmod41_31_ne_zero : (31 : ZMod 41) ≠ 0 := by
  native_decide

/--
LaTeX correspondence: the final spectral contradiction excluding
`SRG(37,18,7,10)`.

The paper diagonalizes over a quadratic extension and observes that the two
nontrivial eigenvalues `(-3 +- sqrt(41))/2` must occur with equal
multiplicity, which contradicts the trace.

Lean proves the same obstruction by reducing modulo the discriminant `41`.
For an `SRG(37,18,7,10)` with adjacency matrix `A`, the SRG relation is

`A^2 = 8I - 3A + 10J`.

Put `B = 2A + 3I`.  Over `ZMod 41`, the relation gives `B^2 = -J`.
Because the graph is `18`-regular, `B` acts on the all-ones direction as
`39`, and the rank-one correction `N = B - 21J` satisfies `N^2 = 0`.
Thus `N` is nilpotent, so mathlib's nilpotent-trace theorem gives
`trace N = 0`.

But a direct trace computation gives `trace N = 31` in `ZMod 41`, and
`31 != 0`.  This is the finite-field version of the irrational-eigenvalue
trace contradiction in the LaTeX proof.
-/
theorem no_isSRGWith37_18_7_10
    (G : SimpleGraph Vertex) [DecidableRel G.Adj] :
    ¬G.IsSRGWith 37 18 7 10 := by
  classical
  intro hsrg
  let R := ZMod 41
  have hprime41 : Nat.Prime 41 := by decide
  haveI : Fact (Nat.Prime 41) := ⟨hprime41⟩
  haveI : Fact (Squarefree 41) := ⟨hprime41.squarefree⟩
  haveI : IsReduced R := by
    dsimp [R]
    infer_instance
  let A : Matrix Vertex Vertex R := G.adjMatrix R
  let J : Matrix Vertex Vertex R := Matrix.of fun _ _ => (1 : R)
  let B : Matrix Vertex Vertex R := (2 : R) • A + (3 : R) • (1 : Matrix Vertex Vertex R)
  let N : Matrix Vertex Vertex R := B - (21 : R) • J
  -- Complement adjacency matrix: `A(G^c) = J - I - A(G)`.
  have hC : Gᶜ.adjMatrix R = J - (1 : Matrix Vertex Vertex R) - A := by
    ext i j
    by_cases hij : i = j
    · subst j
      simp [A, J]
    · by_cases hadj : G.Adj i j
      · simp [A, J, SimpleGraph.compl_adj, hij, hadj]
      · simp [A, J, SimpleGraph.compl_adj, hij, hadj]
  -- The mathlib SRG matrix identity specializes to the paper's
  -- `A^2 = 18I + 7A + 10(J-I-A) = 8I - 3A + 10J`.
  have hA2 : A ^ 2 = (8 : R) • (1 : Matrix Vertex Vertex R) -
      (3 : R) • A + (10 : R) • J := by
    have hraw0 := hsrg.matrix_eq (α := R)
    rw [← Nat.cast_smul_eq_nsmul R 18 (1 : Matrix Vertex Vertex R),
      ← Nat.cast_smul_eq_nsmul R 7 (G.adjMatrix R),
      ← Nat.cast_smul_eq_nsmul R 10 (Gᶜ.adjMatrix R)] at hraw0
    have hraw : A ^ 2 = (18 : R) • (1 : Matrix Vertex Vertex R) +
        (7 : R) • A + (10 : R) • Gᶜ.adjMatrix R := by
      simpa [A] using hraw0
    rw [hraw, hC]
    ext i j
    by_cases hij : i = j
    · subst j
      simp [A, J]
      norm_num
    · by_cases hadj : G.Adj i j
      · simp [A, J, hij, hadj]
        norm_num
      · simp [A, J, hij, hadj]

  -- Completing the square: with `B = 2A+3I`, the discriminant term `41I`
  -- vanishes modulo `41`, leaving `B^2 = 40J = -J`.
  have hB2 : B ^ 2 = (40 : R) • J := by
    change ((2 : R) • A + (3 : R) • (1 : Matrix Vertex Vertex R)) ^ 2 = (40 : R) • J
    calc
      ((2 : R) • A + (3 : R) • (1 : Matrix Vertex Vertex R)) ^ 2 =
          (4 : R) • (A ^ 2) + (12 : R) • A +
            (9 : R) • (1 : Matrix Vertex Vertex R) := by
        ext i j
        simp [pow_two, Matrix.mul_add, Matrix.add_mul]
        ring
      _ = (40 : R) • J := by
        rw [hA2]
        ext i j
        by_cases hij : i = j
        · subst j
          simp [A, J]
          show (81 : ZMod 41) = 40
          exact zmod41_81_eq_40
        · by_cases hadj : G.Adj i j
          · simp [A, J, hij, hadj]
            norm_num
          · simp [A, J, hij, hadj]
            norm_num
  -- Regularity of the SRG says the all-ones matrix is an eigenmatrix for
  -- left and right multiplication by `A`: `AJ = JA = 18J`.
  have hAJ : A * J = (18 : R) • J := by
    ext i j
    calc
      (A * J) i j = ∑ u ∈ G.neighborFinset i, J u j := by
        change (G.adjMatrix R * J) i j = ∑ u ∈ G.neighborFinset i, J u j
        rw [SimpleGraph.adjMatrix_mul_apply]
      _ = ∑ _u ∈ G.neighborFinset i, (1 : R) := by
        simp [J]
      _ = (G.degree i : R) := by
        simp [SimpleGraph.card_neighborFinset_eq_degree]
      _ = 18 := by
        rw [hsrg.regular i]
        norm_num
  have hJA : J * A = (18 : R) • J := by
    ext i j
    calc
      (J * A) i j = ∑ u ∈ G.neighborFinset j, J i u := by
        change (J * G.adjMatrix R) i j = ∑ u ∈ G.neighborFinset j, J i u
        rw [SimpleGraph.mul_adjMatrix_apply]
      _ = ∑ _u ∈ G.neighborFinset j, (1 : R) := by
        simp [J]
      _ = (G.degree j : R) := by
        simp [SimpleGraph.card_neighborFinset_eq_degree]
      _ = 18 := by
        rw [hsrg.regular j]
        norm_num
  -- Therefore `B = 2A+3I` satisfies `BJ = JB = 39J` over `ZMod 41`.
  have hBJ : B * J = (39 : R) • J := by
    change ((2 : R) • A + (3 : R) • (1 : Matrix Vertex Vertex R)) * J = (39 : R) • J
    calc
      ((2 : R) • A + (3 : R) • (1 : Matrix Vertex Vertex R)) * J =
          (2 : R) • (A * J) + (3 : R) • J := by
        ext i j
        simp [Matrix.add_mul]
      _ = (39 : R) • J := by
        rw [hAJ]
        ext i j
        simp [J]
        ring
  have hJB : J * B = (39 : R) • J := by
    change J * ((2 : R) • A + (3 : R) • (1 : Matrix Vertex Vertex R)) = (39 : R) • J
    calc
      J * ((2 : R) • A + (3 : R) • (1 : Matrix Vertex Vertex R)) =
          (2 : R) • (J * A) + (3 : R) • J := by
        ext i j
        simp [Matrix.mul_add]
      _ = (39 : R) • J := by
        rw [hJA]
        ext i j
        simp [J]
        ring
  have hJ2 : J ^ 2 = (37 : R) • J := by
    ext i j
    simp [pow_two, Matrix.mul_apply, J, Vertex, Fintype.card_fin]
  -- The correction `21J` kills the all-ones component and turns `B` into a
  -- nilpotent matrix.  This is the mod-41 replacement for splitting the
  -- nontrivial eigenspace into the two conjugate irrational eigenvalues.
  have hN2 : N ^ 2 = 0 := by
    change (B - (21 : R) • J) ^ 2 = 0
    calc
      (B - (21 : R) • J) ^ 2 =
          B ^ 2 - (21 : R) • (B * J) - (21 : R) • (J * B) +
            ((21 : R) * (21 : R)) • (J ^ 2) := by
        ext i j
        simp [pow_two, Matrix.mul_add, Matrix.add_mul, sub_eq_add_neg]
        ring
      _ = 0 := by
        rw [hB2, hBJ, hJB, hJ2]
        ext i j
        simp [J]
        show (14719 : ZMod 41) = 0
        exact zmod41_14719_eq_zero
  have hnil : IsNilpotent N := ⟨2, by simpa [pow_two] using hN2⟩
  have htrace_zero : Matrix.trace N = 0 :=
    (Matrix.isNilpotent_trace_of_isNilpotent hnil).eq_zero
  -- Direct trace computation: `trace(2A+3I-21J) = 0 + 3*37 - 21*37`,
  -- which is `31` modulo `41`.
  have htrace : Matrix.trace N = (31 : R) := by
    simp [N, B, A, J, Matrix.trace, Vertex, Fintype.card_fin]
    show (-666 : ZMod 41) = 31
    exact zmod41_neg666_eq_31
  have hbad : (31 : R) = 0 := htrace.symm.trans htrace_zero
  have h31 : (31 : R) ≠ 0 := by
    show (31 : ZMod 41) ≠ 0
    exact zmod41_31_ne_zero
  exact h31 hbad

/--
LaTeX correspondence: the contradiction assumption at the start of Section 2.
If `G` has no `B_8` and `G^c` has no `B_10`, the book-cap lemmas give the
two cap hypotheses, equality propagation gives `SRG(37,18,7,10)`, and the
spectral theorem above contradicts that SRG.
-/
theorem no_counterexample_of_actual_formalization
    (G : SimpleGraph Vertex) [DecidableRel G.Adj]
    (hnoB8 : ¬ ContainsBook 8 G)
    (hnoB10 : ¬ ContainsBook 10 Gᶜ) : False := by
  have hB8 := edgeBookCapB8_of_not_containsBook G hnoB8
  have hB10 := complementBookCapB10_of_not_containsBook_compl G hnoB10
  exact no_isSRGWith37_18_7_10 G
    (isSRGWith37_18_7_10_of_actual_caps G hB8 hB10)

/--
Main theorem of this file.

This is the Lean statement of the LaTeX sentence:
"it is enough to prove that every graph on `37` vertices contains `B_8` or
its complement contains `B_10`."

The theorem proves the upper bound `R(B_8,B_10) <= 37` for the fixed
mathlib vertex type `Fin 37`.  The cited lower bound
`R(B_8,B_10) >= 37` is not part of this Lean development.
-/
theorem b8b10_upper_bound_actual : B8B10UpperBoundStatement := by
  intro G hG
  by_cases hB8 : ContainsBook 8 G
  · exact Or.inl hB8
  · right
    by_contra hB10
    exact no_counterexample_of_actual_formalization G hB8 hB10

end Actual

end RamseyLean
