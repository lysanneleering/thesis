#!/usr/bin/env python3
"""Reproduce the numerical bounds in the lollipop two-graph note."""
from __future__ import annotations
from itertools import product


def turan_edges(n: int, r: int) -> int:
    sizes = [n // r + (1 if i < n % r else 0) for i in range(r)]
    return (n * n - sum(s * s for s in sizes)) // 2


def lower_crossings(n: int) -> tuple[int, tuple[int, int, int, int]]:
    if n == 0:
        return 0, (0, 0, 0, 0)
    if n < 4:
        # Exact crossing values for n=1,2,3.
        exact = {1: 0, 2: 7, 3: 21}
        return exact[n], (1,) * n + (0,) * (4 - n)
    best = -1
    best_m = (0, 0, 0, 0)
    for m1 in range(1, n + 1):
        for m2 in range(1, n - m1 + 1):
            for m3 in range(1, n - m1 - m2 + 1):
                m4 = n - m1 - m2 - m3
                if m4 < 1:
                    continue
                ms = (m1, m2, m3, m4)
                cross = (
                    5 * m1 * m2
                    + 7 * (m1 * m3 + m1 * m4 + m2 * m3 + m2 * m4 + m3 * m4)
                    + 4 * sum(m * (m - 1) // 2 for m in ms)
                )
                if cross > best:
                    best = cross
                    best_m = ms
    return best, best_m


def paulsen_crossing_upper(n: int) -> int:
    return 4 * (n * (n - 1) // 2) + 2 * turan_edges(n, 3) + turan_edges(n, 4)


# Improvements in crossings proved in the note, beyond Paulsen's upper bound.
REFINEMENT = {
    0: 0,
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
    6: 0,
    7: 0,
    8: 1,
    9: 1,
    10: 0,
    11: 1,
    12: 2,
    13: 1,
    14: 2,
    15: 3,
    16: 2,
    17: 3,
    18: 3,
    19: 3,
    20: 3,
}


def main() -> None:
    print(" n | multiplicities | lower regions | refined upper | Paulsen upper")
    print("---+----------------+---------------+---------------+--------------")
    for n in range(0, 21):
        lower_c, ms = lower_crossings(n)
        lower_r = lower_c + n + 1
        if n <= 4:
            refined_r = lower_r
            paulsen_r = lower_r
        else:
            paulsen_c = paulsen_crossing_upper(n)
            refined_c = paulsen_c - REFINEMENT.get(n, 0)
            paulsen_r = paulsen_c + n + 1
            refined_r = refined_c + n + 1
        print(f"{n:2d} | {str(ms):14s} | {lower_r:13d} | {refined_r:13d} | {paulsen_r:12d}")


if __name__ == "__main__":
    main()
