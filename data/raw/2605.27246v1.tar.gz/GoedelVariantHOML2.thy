theory GoedelVariantHOML2 imports HOMLinHOL ModalFilter ChurchTTinHOML 
begin 
  consts PositiveProperty::"(e\<Rightarrow>\<sigma>)\<Rightarrow>\<sigma>" ("P") 
  axiomatization where                                                                  Ax1: "\<lfloor>P \<phi> \<^bold>\<and> P \<psi> \<^bold>\<supset> P (\<phi> \<^bold>. \<psi>)\<rfloor>"
  axiomatization where                                                                Ax2a: "\<lfloor>P \<phi> \<^bold>\<or>\<^sup>e P \<^bold>~\<phi>\<rfloor>" 
  definition God ("G") where                                                                   "G x \<equiv> \<^bold>\<forall>\<phi>. P \<phi> \<^bold>\<supset> \<phi> x"
  abbreviation PropertyInclusion ("_\<^bold>\<supset>\<^sub>N_") where                                 "\<phi> \<^bold>\<supset>\<^sub>N \<psi>  \<equiv>  \<^bold>\<box>(\<^bold>\<forall>\<^sup>Ey.  \<phi> y \<^bold>\<supset> \<psi> y)" 
  definition Essence ("_Ess._") where                                                     "\<phi> Ess. x \<equiv> \<phi> x \<^bold>\<and> (\<^bold>\<forall>\<psi>. \<psi> x \<^bold>\<supset> (\<phi> \<^bold>\<supset>\<^sub>N \<psi>))"
  axiomatization where                                                                Ax2b: "\<lfloor>P \<phi> \<^bold>\<supset> \<^bold>\<box> P \<phi>\<rfloor>" 
  lemma                      Ax2b': "\<lfloor>\<^bold>\<not>P \<phi> \<^bold>\<supset> \<^bold>\<box>(\<^bold>\<not>P \<phi>)\<rfloor>"              using Ax2a Ax2b by blast
  theorem                  Th1: "\<lfloor>G x \<^bold>\<supset> G Ess. x\<rfloor>"                     using Ax2a Ax2b Essence_def God_def by (smt (verit))
  definition NecExist ("E") where                                                            "E x  \<equiv> \<^bold>\<forall>\<phi>. \<phi> Ess. x \<^bold>\<supset> \<^bold>\<box>(\<^bold>\<exists>\<^sup>Ex. \<phi> x)"
  axiomatization where                                                                  Ax3: "\<lfloor>P E\<rfloor>" 
  theorem                  Th2: "\<lfloor>G x \<^bold>\<supset> \<^bold>\<box>(\<^bold>\<exists>\<^sup>Ey. G y)\<rfloor>"               using Ax3 Th1 God_def NecExist_def by smt
  theorem                  Th3: "\<lfloor>\<^bold>\<diamond>(\<^bold>\<exists>\<^sup>Ex. G x) \<^bold>\<supset> \<^bold>\<box>(\<^bold>\<exists>\<^sup>Ey. G y)\<rfloor>"  by (metis Th2 Rsymm)
  axiomatization where                                                                  Ax4: "\<lfloor>P \<phi> \<^bold>\<and> (\<phi> \<^bold>\<supset>\<^sub>N \<psi>) \<^bold>\<supset> P \<psi>\<rfloor>"
  lemma True nitpick[satisfy,card=1,eval="\<lfloor>P (\<lambda>x.\<^bold>\<bottom>)\<rfloor>"] oops  \<comment>\<open>One model found of cardinality one\<close>
  abbreviation          "CollOfPosProps \<Phi> \<equiv> \<^bold>\<forall>\<phi>. \<Phi> \<phi> \<^bold>\<supset> P \<phi>"
  abbreviation           "ConjOfPropsFrom \<phi> \<Phi> \<equiv> \<^bold>\<box>(\<^bold>\<forall>\<^sup>Ez. \<phi> z \<^bold>\<leftrightarrow> (\<^bold>\<forall>\<psi>. \<Phi> \<psi> \<^bold>\<supset> \<psi> z))"
  axiomatization where                                                         Ax1Gen: "\<lfloor>(CollOfPosProps \<Phi> \<^bold>\<and> ConjOfPropsFrom \<phi> \<Phi>) \<^bold>\<supset> P \<phi>\<rfloor>" 
  lemma                         L: "\<lfloor>P G\<rfloor>"                                       using Ax1Gen God_def by (smt (verit))
  theorem                  Th4: "\<lfloor>\<^bold>\<diamond>(\<^bold>\<exists>\<^sup>Ex. G x)\<rfloor>"                         using Ax2a Ax4 L by blast
  theorem                  Th5: "\<lfloor>\<^bold>\<box>(\<^bold>\<exists>\<^sup>Ex. G x)\<rfloor>"                         using Th3 Th4 by blast
  lemma                      MC: "\<lfloor>\<phi> \<^bold>\<supset> \<^bold>\<box>\<phi>\<rfloor>"  \<comment>\<open>Proof found with sledgehammer\<close>  
      proof - {fix w fix Q
       have 1: "\<forall>x.(G x w \<longrightarrow> (\<^bold>\<forall>Z. Z x \<^bold>\<supset> \<^bold>\<box>(\<^bold>\<forall>\<^sup>Ez. G z \<^bold>\<supset> Z z)) w)" using Ax2a Ax2b God_def by smt
       have 2: "(\<exists>x. G x w)\<longrightarrow>((Q \<^bold>\<supset> \<^bold>\<box>(\<^bold>\<forall>\<^sup>Ez. G z \<^bold>\<supset> Q)) w)" using 1 by force
       have 3: "(Q \<^bold>\<supset> \<^bold>\<box>Q) w" using 2 Th5 Rsymm by blast} 
       thus ?thesis by auto qed
  lemma            PosProps: "\<lfloor>P (\<lambda>x.\<^bold>\<top>) \<^bold>\<and>  P (\<lambda>x. x \<^bold>= x)\<rfloor>"    using Ax2a Ax4 by blast
  lemma           NegProps: "\<lfloor>\<^bold>\<not>P(\<lambda>x.\<^bold>\<bottom>) \<^bold>\<and> \<^bold>\<not>P(\<lambda>x. x \<^bold>\<noteq> x)\<rfloor>"  using Ax2a Ax4 by blast
  lemma        UniqueEss1: "\<lfloor>\<phi> Ess. x \<^bold>\<and> \<psi> Ess. x \<^bold>\<supset>  \<^bold>\<box>(\<^bold>\<forall>\<^sup>Ey. \<phi> y \<^bold>\<leftrightarrow> \<psi> y)\<rfloor>"         using Essence_def by smt
  lemma        UniqueEss2: "\<lfloor>\<phi> Ess. x \<^bold>\<and> \<psi> Ess. x \<^bold>\<supset>  \<^bold>\<box>(\<phi> \<^bold>\<equiv> \<psi>)\<rfloor>"            nitpick[card i=1] oops  \<comment>\<open>Countermodel found\<close>
  lemma       Monotheism: "\<lfloor>G x \<^bold>\<and> G y \<^bold>\<supset>  x \<^bold>\<equiv> y\<rfloor>"              using Ax2a God_def by smt
  lemma                  Filter: "\<lfloor>Filter P\<rfloor>"                                  using Ax1 Ax4 MC NegProps PosProps Rsymm by smt
  lemma          UltraFilter: "\<lfloor>UFilter P\<rfloor>"                                using Ax2a Filter by smt 
  lemma True nitpick[satisfy,user_axioms,card=1,eval="\<lfloor>P (\<lambda>x.\<^bold>\<bottom>)\<rfloor>"] oops  \<comment>\<open>One model found of cardinality one\<close>
\<comment>\<open>Assuming 2 different entities leads to 2 different positive properties, assuming 3 leads to 4, etc.\<close>
  lemma H: "\<lfloor>P (\<lambda>e.\<^bold>\<top>) \<^bold>\<and> (P (\<lambda>e. e\<^bold>=a) \<^bold>\<or> P (\<lambda>e. e\<^bold>\<noteq>a))\<rfloor>" using PosProps Ax2a by auto 
  lemma PP2: assumes "\<lfloor>\<^bold>\<exists>(a::e) b. a \<^bold>\<noteq> b\<rfloor>" shows "\<lfloor>\<^bold>\<exists>p q. p\<^bold>\<noteq>q \<^bold>\<and> P p \<^bold>\<and> P q\<rfloor>" by (smt (verit, del_insts) H assms)
  lemma PP4: assumes "\<lfloor>\<^bold>\<exists>(a::e) b c. a \<^bold>\<noteq> b \<^bold>\<and> a \<^bold>\<noteq> c \<^bold>\<and> b \<^bold>\<noteq> c\<rfloor>" 
      shows "\<lfloor>\<^bold>\<exists>p q r s. p\<^bold>\<noteq>q \<^bold>\<and> p\<^bold>\<noteq>r \<^bold>\<and> p\<^bold>\<noteq>s \<^bold>\<and> q\<^bold>\<noteq>r \<^bold>\<and> q\<^bold>\<noteq>s \<^bold>\<and> r\<^bold>\<noteq>s \<^bold>\<and> P p \<^bold>\<and> P q \<^bold>\<and> P r \<^bold>\<and> P s\<rfloor>" by (smt (verit, del_insts) H assms)
\<comment>\<open>Assuming infinitely many different entities leads to at least 2, 4, etc., many different positive properties\<close>
  lemma PP2': assumes "\<lfloor>Inf0\<rfloor>" shows "\<lfloor>\<^bold>\<exists>p q. ((p\<^bold>\<noteq>q) \<^bold>\<and> P p \<^bold>\<and> P q)\<rfloor>" by (metis (lifting) Ax2a Inf0_def PosProps assms) 
  lemma PP4': assumes "\<lfloor>Inf0\<rfloor>" shows "\<lfloor>\<^bold>\<exists>p q r s. p\<^bold>\<noteq>q\<^bold>\<and>p\<^bold>\<noteq>r\<^bold>\<and>p\<^bold>\<noteq>s\<^bold>\<and>q\<^bold>\<noteq>r\<^bold>\<and>q\<^bold>\<noteq>s\<^bold>\<and>r\<^bold>\<noteq>s\<^bold>\<and>P p\<^bold>\<and>P q\<^bold>\<and>P r\<^bold>\<and>P s\<rfloor>"
    proof -  have "\<lfloor>Inf0\<rfloor> \<Longrightarrow> \<lfloor>\<^bold>\<exists>p::e. \<^bold>\<exists>q::e. \<^bold>\<exists>r::e. p\<^bold>\<noteq>q \<^bold>\<and> p\<^bold>\<noteq>r \<^bold>\<and> q\<^bold>\<noteq>r\<rfloor>" unfolding Inf0_def apply simp by metis
        thus ?thesis using PP4 assms by blast qed 
\<comment>\<open>Theorem MetaInf: infinitely many different entities lead to infinitely many positive properties: proof at meta-level.\<close>
    \<comment>\<open>Various definitions and automatically proved lemmata are not shown here.\<close>                                (*{{{  *)
    definition "Chain r \<equiv> rec_nat (SOME x::e. True) (\<lambda>n x. SOME y. r x y)"
  definition "InjRel f (x::e) y (w::e) \<equiv> (\<exists>n m. x = f n \<and> y = f m \<and> n < m) \<or> (\<exists>n::nat. x \<notin> range f \<and> y = f n)"
  lemma Chain1: "((\<forall>x. \<exists>y. r x y) \<and> (\<forall>x. \<not> r x x) \<and> (\<forall>x y z. r x y \<and> r y z \<longrightarrow> r x z)) \<Longrightarrow> r (Chain r n) (Chain r (Suc n))" 
    unfolding Chain_def by (metis Chain_def someI rec_nat_Suc_imp) 
  lemma Chain2: "(\<forall>x. \<exists>y. r x y) \<and> (\<forall>x. \<not>r x x) \<and> (\<forall>x y z. r x y \<and> r y z \<longrightarrow> r x z) \<Longrightarrow> (n<m \<Longrightarrow> r (Chain r n) (Chain r m))"
    apply (induction m) apply blast using Chain1 less_Suc_eq by blast
  lemma Chain3: "(\<forall>x. \<exists>y. r x y) \<and> (\<forall>x. \<not> r x x) \<and> (\<forall>x y z. r x y \<and> r y z \<longrightarrow> r x z) \<Longrightarrow> (inj (Chain r))"
    by (metis (mono_tags, lifting) Chain2 injI nat_neq_iff)
  lemma Chain4: "Inf0 w \<Longrightarrow> (\<exists>r. inj (Chain r))" unfolding Inf0_def using Chain3 by fast   (*}}}*)
  lemma MetaInf: "\<lfloor>Inf0\<rfloor> \<Longrightarrow> infinite (UNIV::e set)"                                                                                  (*{{{  *)
    by (metis Chain4 finite_imageD finite_subset infinite_UNIV_nat top.extremum) 
  abbreviation PosSet ("\<P>") where "\<P> w \<equiv> {x . P x w}"
  abbreviation PickP where "PickP f w \<equiv> \<lambda>n. if P (\<lambda>x. x \<^bold>= f n) w then (\<lambda>x. x \<^bold>= f n) else (\<lambda>x. x \<^bold>\<noteq> f n)"
  lemma PickP_inj: "inj (f::nat\<Rightarrow>e) \<Longrightarrow> inj (PickP f w)" 
    by (smt (verit, best) finite_nat_set_iff_bounded_le infinite_UNIV_nat injD injI linorder_le_cases) 
  lemma PickP_pos: "range (PickP f w) \<subseteq> \<P> w" by (auto simp: image_def) (metis (lifting) Filter L Monotheism) (*}}}*)
  lemma InfPosSet_a: "infinite (UNIV::e set) \<Longrightarrow> infinite (\<P> w)"                                                                (*{{{  *)
        proof -
      assume "infinite (UNIV::e set)"
      then obtain f::"nat\<Rightarrow>e" where "inj f" using infinite_countable_subset by blast
      thus ?thesis by (smt (verit) Collect_mono subset_antisym PickP_inj PickP_pos infinite_UNIV_nat inj_on_finite)
    qed (*}}}*)
  lemma InfPosSet_b: "\<lfloor>Inf0\<rfloor> \<Longrightarrow> infinite (\<P> w)" using InfPosSet_a MetaInf by blast                             (*{{{  *)
    definition Qfin where "Qfin m \<equiv> \<lambda>w. \<forall>q::'a\<Rightarrow>\<sigma>. m q w \<longrightarrow> finite {x. q x w}"
  lemma fin_step: "(\<forall>q::'a\<Rightarrow>\<sigma>. m q w \<longrightarrow> finite {x. q x w}) \<Longrightarrow> (\<S> m) q w \<Longrightarrow> finite {x::'a. q x w}"
    unfolding Succ_def by (smt finite_insert finite_subset insert_iff mem_Collect_eq subsetI)
  lemma Qfin_zero: "Qfin \<zero> w" unfolding Qfin_def Zero_def by simp
  lemma Qfin_succ: "Qfin m w \<Longrightarrow> Qfin (\<S> m) w" unfolding Qfin_def using fin_step by metis
  lemma Nat_finite: "\<nat> n w \<and> n p w \<Longrightarrow> finite {x. p x w}" by (metis Qfin_zero Qfin_succ Naturals_def Qfin_def Qfin_def) (*}}}*)
  theorem  InfPosSet: assumes "\<lfloor>Inf0\<rfloor>" shows "\<lfloor>\<^bold>\<not>(\<F>\<i>\<n>\<i>\<t>\<e> P)\<rfloor>" by (metis Finite_def InfPosSet_b Nat_finite assms)
\<comment>\<open>CantorArgument: Assuming infinitely many different entities leads to uncountably many different positive properties.\<close>
  definition "S (f::nat\<Rightarrow>e) \<equiv> (\<lambda>x::e. if x \<in> range f then f (Suc (inv f x)) else x)"
  definition "Enc (f::nat\<Rightarrow>e) s \<equiv> (\<lambda>(B::e\<Rightarrow>bool) (x::e) (u::i). x = f 0 \<or> (\<exists>y. s y = x \<and> B y))"
  definition "D F (f::nat\<Rightarrow>e) s (w::i) \<equiv> (\<lambda>x::e. if F x (f 0) w then \<not> F x (s x) w else F x (s x) w)"
  lemma Inf_inj: "\<lfloor>Inf0\<rfloor> \<Longrightarrow> \<exists>f::nat\<Rightarrow>e. inj f" using MetaInf infinite_countable_subset by blast
  lemma Enc0: "Enc f s B (f 0) w" using Enc_def by simp
  lemma EncS: "inj f \<longrightarrow> (Enc f (S f) B (S f y) w \<longleftrightarrow> B y)" 
    by (smt Enc_def S_def inj_Suc inv_f_f inv_into_injective nat.distinct rangeI)
  lemma L1: "inj (f::nat\<Rightarrow>e) \<Longrightarrow> (\<^bold>\<not>(\<^bold>\<exists>F. \<^bold>\<forall>p. P p \<^bold>\<supset> (\<^bold>\<exists>e::e. F e \<^bold>= p))) w" by (smt Enc0 EncS Ax2a D_def)
  theorem CantorArgument: assumes "\<lfloor>Inf0\<rfloor>" shows "\<lfloor>\<^bold>\<not>(\<^bold>\<exists>F. \<^bold>\<forall>p. P p \<^bold>\<supset> (\<^bold>\<exists>e::e. F e \<^bold>= p))\<rfloor>" using assms Inf_inj L1 by metis
end

