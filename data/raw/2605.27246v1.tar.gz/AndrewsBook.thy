theory AndrewsBook imports ChurchTTinHOML
begin
\<comment>\<open>Further concepts: let's define provability as semantic evaluation\<close>
  abbreviation derivable1 :: "\<sigma>\<Rightarrow>bool" ("\<turnstile>_")  where "\<turnstile> A \<equiv>   \<lfloor>A\<rfloor>"
  abbreviation derivable2 :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>bool" ("_\<^bold>\<turnstile>_")  where "\<HH> \<^bold>\<turnstile> A \<equiv>  \<lfloor>\<HH>\<rfloor> \<longrightarrow>  \<lfloor>A\<rfloor>"
  abbreviation contained :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>bool" (infixr"\<^bold>\<in>"30)  where "A \<^bold>\<in> \<HH>  \<equiv>   \<lfloor>\<HH> \<^bold>\<supset> A\<rfloor>"
\<comment>\<open>Useful lemma\<close>
  lemma L1:  "OneWorld \<Longrightarrow> \<phi> = \<^bold>\<top> \<or> \<phi> = \<^bold>\<bottom>" by (metis (full_types))
\<comment>\<open>Andrews Book, p. 2013, Axioms for Q0\<close>
  named_theorems Q0
  lemma A1       [Q0]:   "OneWorld \<Longrightarrow> \<turnstile>  (g \<^bold>\<top> \<^bold>\<and> g \<^bold>\<bottom>) \<^bold>= (\<^bold>\<forall>x. g x)"       using L1 by (metis (full_types)) 
  lemma A2_\<alpha>   [Q0]:   "\<turnstile>  (x \<^bold>= y) \<^bold>\<supset> ((h x) \<^bold>= (h y))"                               by auto
  lemma A3_\<alpha>\<beta> [Q0]:   "\<turnstile> (f \<^bold>= g) \<^bold>\<supset> (\<^bold>\<forall>x. ((f x) \<^bold>= (g x)))"                         by auto
  lemma A4_1   [Q0]:   "\<turnstile> ((\<lambda>x. B) A) \<^bold>= B"                                                by auto
  lemma A4_2   [Q0]:   "\<turnstile> ((\<lambda>x. x) A) \<^bold>= A"                                                by auto
  lemma A4_3   [Q0]:   "\<turnstile> ((\<lambda>x. B C) A) \<^bold>= (((\<lambda>x. B) A) ((\<lambda>x. C) A))"         by auto
  lemma A4_4   [Q0]:   "\<turnstile> ((\<lambda>x. \<lambda>y. B) A) \<^bold>= (\<lambda>y. ((\<lambda>x. B) A))"                  by auto
  lemma A4_5   [Q0]:   "\<turnstile> ((\<lambda>x. (\<lambda>x. B)) A) \<^bold>= (\<lambda>x. B)"                              by auto
  \<comment>\<open>Description; todo\<close>
\<comment>\<open>Andrews Book p. 2013, RuleR\<close>
  named_theorems RuleR
  lemma R_1 [RuleR]:   "\<turnstile> A \<Longrightarrow> \<turnstile> A \<^bold>= B \<Longrightarrow>  \<turnstile> B"                                                      by auto
  lemma R_2 [RuleR]:   "\<turnstile> A \<^bold>= C \<Longrightarrow> \<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> B \<^bold>= C"                                        by auto
  lemma R_3 [RuleR]:   "\<turnstile> C \<^bold>= A \<Longrightarrow> \<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> C \<^bold>= B"                                        by auto
  lemma R_4 [RuleR]:   "\<turnstile> C A \<Longrightarrow>\<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> C B"                                                 by auto
  lemma R_5 [RuleR]:   "\<turnstile> C (A D) \<Longrightarrow> \<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> C (B D)"                                    by auto
  lemma R_6 [RuleR]:   "\<turnstile> (\<lambda>x. A x) C \<Longrightarrow> \<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> (\<lambda>x. B x) C"                         by auto
  lemma R_7 [RuleR]:   "\<turnstile> (\<lambda>x. (A (\<lambda>y. C))) \<Longrightarrow> \<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> (\<lambda>x. (B (\<lambda>y. C)))"        by auto
  lemma R_8 [RuleR]:   "\<turnstile> A \<^bold>\<and> C \<Longrightarrow> \<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> B \<^bold>\<and> C"                                         by auto
      (* etc *)
\<comment>\<open>Elementary Logic in Q0; Andrews Book p. 2015\<close>
  lemma X5200:                    "\<turnstile> A \<^bold>= A"                                                                                        by auto
  lemma X5200s:                  "\<turnstile> \<^bold>\<top>"                                                                                               by auto
  named_theorems X5201 \<comment>\<open>Equality Rules\<close>
  lemma X5201_1 [X5201]:   "\<HH> \<^bold>\<turnstile> A \<Longrightarrow> \<HH> \<^bold>\<turnstile> A \<^bold>\<equiv> B \<Longrightarrow> \<HH> \<^bold>\<turnstile> B"                                                by fastforce
  lemma X5201_2 [X5201]:   "\<HH> \<^bold>\<turnstile> A \<^bold>= B \<Longrightarrow> \<HH> \<^bold>\<turnstile> B \<^bold>= A"                                                          by auto 
  lemma X5201_3 [X5201]:   "\<HH> \<^bold>\<turnstile> A \<^bold>= B \<Longrightarrow> \<HH> \<^bold>\<turnstile> B \<^bold>= C \<Longrightarrow> \<HH> \<^bold>\<turnstile> A \<^bold>= C"                                 by auto
  lemma X5201_4 [X5201]:   "\<HH> \<^bold>\<turnstile> A \<^bold>= B \<Longrightarrow> \<HH> \<^bold>\<turnstile> C \<^bold>= D \<Longrightarrow> \<HH> \<^bold>\<turnstile> (A C) \<^bold>= (B D)"                     by auto
  lemma X5201_5 [X5201]:   "\<HH> \<^bold>\<turnstile> A \<^bold>= B \<Longrightarrow> \<HH> \<^bold>\<turnstile> (A C) \<^bold>= (B C)"                                              by auto 
  lemma X5201_6 [X5201]:   "\<HH> \<^bold>\<turnstile> C \<^bold>= D \<Longrightarrow> \<HH> \<^bold>\<turnstile> (A C) \<^bold>= (A D)"                                              by auto 
  lemma X5205: "\<turnstile> f \<^bold>= (\<lambda> y. f y)" by auto 
  lemma 5210:                     "\<turnstile> \<^bold>\<top> \<^bold>= (B \<^bold>= B)"                                                            by auto
  lemma 5211:                     "\<turnstile> \<^bold>\<top> \<^bold>= ( \<^bold>\<top> \<^bold>\<and> \<^bold>\<top>)"                                                          by auto
  lemma 5212:                     "\<turnstile> \<^bold>\<top> \<^bold>\<and> \<^bold>\<top>"                                                                      by auto
  lemma 5213:                     "\<turnstile> A \<^bold>= B \<Longrightarrow> \<turnstile> C \<^bold>= D \<Longrightarrow> \<turnstile> (A \<^bold>= B) \<^bold>\<and> (C \<^bold>= D)"         by auto
  lemma 5214:                     "\<turnstile> (\<^bold>\<top> \<^bold>\<and> \<^bold>\<bottom>) \<^bold>= \<^bold>\<bottom>"                                                           by auto
  lemma 5216:                     "\<turnstile> (\<^bold>\<top> \<^bold>\<and> A) \<^bold>= A"                                                             by auto
  lemma 5217:                     "\<turnstile> (\<^bold>\<top> \<^bold>= \<^bold>\<bottom>) \<^bold>= \<^bold>\<bottom>"                                                           by metis
  lemma 5218:                     "OneWorld \<Longrightarrow> \<turnstile> (\<^bold>\<top> \<^bold>= A) \<^bold>= A"                                    by (metis ext) \<comment>\<open>OneWorld needed\<close>
  lemma 5224:                     "\<HH> \<^bold>\<turnstile> A \<Longrightarrow> \<HH> \<^bold>\<turnstile> A \<^bold>\<supset> B \<Longrightarrow> \<HH> \<^bold>\<turnstile> B"                                by auto           \<comment>\<open>Modus Ponens\<close>
  lemma 5225:                     "\<turnstile> \<^bold>\<forall>f \<^bold>\<supset> f x"                                                                    by auto
  lemma 5227:                     "\<turnstile> \<^bold>\<bottom> \<^bold>\<supset> x"                                                                       by auto
  lemma 5228: "\<turnstile> (\<^bold>\<top> \<^bold>\<supset> \<^bold>\<top>) \<^bold>= \<^bold>\<top>" and "\<turnstile> (\<^bold>\<top> \<^bold>\<supset> \<^bold>\<bottom>) \<^bold>= \<^bold>\<bottom>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>\<supset> \<^bold>\<top>) \<^bold>= \<^bold>\<top>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>\<supset> \<^bold>\<bottom>) \<^bold>= \<^bold>\<top>"            by auto
  lemma 5229: "\<turnstile> (\<^bold>\<top> \<^bold>\<and> \<^bold>\<top>) \<^bold>= \<^bold>\<top>" and "\<turnstile> (\<^bold>\<top> \<^bold>\<and> \<^bold>\<bottom>) \<^bold>= \<^bold>\<bottom>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>\<and> \<^bold>\<top>) \<^bold>= \<^bold>\<bottom>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>\<and> \<^bold>\<bottom>) \<^bold>= \<^bold>\<bottom>"              by auto
  lemma 5230: "\<turnstile> (\<^bold>\<top> \<^bold>= \<^bold>\<top>) \<^bold>= \<^bold>\<top>" and "\<turnstile> (\<^bold>\<top> \<^bold>= \<^bold>\<bottom>) \<^bold>= \<^bold>\<bottom>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>= \<^bold>\<top>) \<^bold>= \<^bold>\<bottom>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>= \<^bold>\<bottom>) \<^bold>= \<^bold>\<top>"  
     apply auto apply metis by metis
  lemma 5231: "\<turnstile> \<^bold>\<not>(\<^bold>\<top> \<^bold>= \<^bold>\<bottom>)" and "\<turnstile> \<^bold>\<not>(\<^bold>\<bottom> \<^bold>= \<^bold>\<top>)"                                                                              apply metis by metis
  lemma 5232: "\<turnstile> (\<^bold>\<top> \<^bold>\<or> \<^bold>\<top>) \<^bold>= \<^bold>\<top>" and "\<turnstile> (\<^bold>\<top> \<^bold>\<or> \<^bold>\<bottom>) \<^bold>= \<^bold>\<top>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>\<or> \<^bold>\<top>) \<^bold>= \<^bold>\<top>" and "\<turnstile> (\<^bold>\<bottom> \<^bold>\<or> \<^bold>\<bottom>) \<^bold>= \<^bold>\<bottom>"              by auto
\<comment>\<open>To be continued\<close>
end


