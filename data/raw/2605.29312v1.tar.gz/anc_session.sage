#
# ExperimentalSession.sage ---> anc_session.sage
#
# Akira Kurihara
#



###
load("anc_library.sage")



################################################################################
#
# proveTheorem3(p)
#
################################################################################



# The following proves Theorem 3



###
if True:
    start_here=3
    end_here=1000
#
if False:
    start_here=193
    end_here=193+1
#
if False:
    start_here=6301
    end_here=6301+1
#
from time import time, gmtime, localtime, strftime
import socket
#
t1=time()
#print(version())
import sage.version
print("----- sage version",sage.version.version)
print("----- date",strftime("%Y-%m-%d %H:%M:%S local time",localtime()))
print("----- host",socket.gethostname())
sys.stdout.flush()
#
for p in range(start_here,end_here):
    if is_prime(p):
        proveTheorem3(p)
#
t2=time()
#print(version())
print("----- sage version",sage.version.version)
print("----- date",strftime("%Y-%m-%d %H:%M:%S local time",localtime()))
print("----- time",t2-t1,"seconds")
print("----- host",socket.gethostname())
sys.stdout.flush()
# 



# The following suggested Theorem 4



###
for p in range(3,1000):
    if is_prime(p) and is_prime(ZZ((p-1)/2)):
        proveTheorem3(p)
        


###
for p in range(3,100000):
    if is_prime(p) and is_prime(ZZ((p-1)/2)):
        proveTheorem3(p)
        


################################################################################
#
# kappaAndMore(s,ell)
#
################################################################################



#
# Theorem 4
#
# create Table 2
#



###
smax=6
print("===== Table2 kappa(s,ell) =====") 
for s in range(1,smax+1):
    for ell in range(1,s+1):
        print()
        print("----- s =",s,"ell =",ell,"-----")
        kappaAndMore(s,ell)
#



################################################################################
#
# CheckDeltaDirect(p,red)
#
################################################################################



# Check
#
#              det M_d ( f(x)^e )
# ----------------------------------------------- = epsilon_p,r,e,d det M_dhat( f(x)^ehat )
# s_0^( d(p-1)-(r-1)e ) Delta(f(x))^( e-(p-1)/2 )
#
# epsilon_p,r,e,d = (-1)^( r(r+1)/2 (1+e) + (r+1) d ) { (d+1)(p-1)-re }! e!^r
#
# directly, i.e., s_0, ... , s_r are variables
#



###
p=3
#
for red in Ep(p):
    r=red[0]
    e=red[1]
    d=red[2]
    ehat=p-1-e
    dhat=r-1-d
    if e-(p-1)/2>=0:
        Result=CheckDeltaDirect(p,red)
        print("p =",p, "(r, e, d) =",red,"(r, ehat, dhat) =",[r,ehat,dhat],Result)
        #
    #
#



###
p=5
#
for red in Ep(p):
    r=red[0]
    e=red[1]
    d=red[2]
    ehat=p-1-e
    dhat=r-1-d
    if e-(p-1)/2>0:
        Result=CheckDeltaDirect(p,red)
        print("p =",p, "(r, e, d) =",red,"(r, ehat, dhat) =",[r,ehat,dhat],Result)
        #
    #
#



################################################################################
#
# CheckDeltaRandom(p,red,Fdeg,HMT)
#
################################################################################



# Check
#
#              det M_d ( f(x)^e )
# ----------------------------------------------- = epsilon_p,r,e,d det M_dhat( f(x)^ehat )
# s_0^( d(p-1)-(r-1)e ) Delta(f(x))^( e-(p-1)/2 )
#
# epsilon_p,r,e,d = (-1)^( r(r+1)/2 (1+e) + (r+1) d ) { (d+1)(p-1)-re }! e!^r
#
# for randomly chosen s0, s1, ... , sr in GF(p^Fdeg) for HMT times
#
# HMT = how many times
#



###
p=17
#
Fdeg=2
HMT=10
#
for red in Ep(p):
    result=CheckDeltaRandom(p,red,Fdeg,HMT)
    print("p =",p,"red =",red,result)
#




###
for p in range(2,31+1):
    if is_prime(p):
        #
        Fdeg=2
        HMT=10
        #
        print("---------- p =",p,"----------")
        for red in Ep(p):
            result=CheckDeltaRandom(p,red,Fdeg,HMT)
            print("p =",p,"red =",red,result)
#



################################################################################
#
# CheckDeltaRandomLinearEquation(p,red,FdegBound,failCountBound,eListLenBound)
#
################################################################################



# Check
#
#              det M_d ( f(x)^e )
# ----------------------------------------------- = epsilon_p,r,e,d det M_dhat( f(x)^ehat )     .....    (*)
# s_0^( d(p-1)-(r-1)e ) Delta(f(x))^( e-(p-1)/2 )
#
# Suppose we have
#
# the above (*) = Sum C_{e0,e1, ... , er} s_0^e0 s_1^e1 ... s_r^er
#
#   e0 +   e1 + ... +   er = (some known value)
#
# 0 e0 + 1 e1 + ... + r er = (some known value)
#
# We try to find sufficiently many random s0, s1, ... , sr
#
# such that LHS of (*) = RHS of (*) for this s0, s1, ... , sr
#
# and they determine the coefficients C_{e0,e1, ... , er} uniquely 
# 
# This computation can be a proof of (*)
#



###
p=7
#
FdegBound=3
failCountBound=100
#
eListLenBound=1000
#
for red in Ep(p):
    r=red[0]
    e=red[1]
    d=red[2]
    if e-(p-1)/2>0:
        CheckDeltaRandomLinearEquation(p,red,FdegBound,failCountBound,eListLenBound)
#



################################################################################
#
# CheckGlynnDirect(p,r)
#
################################################################################


#
# This checks
#
# G^e (A) = det A^(p-1-r ehat) G^ehat (Ahat)
#
# assuming a_{i,j} are independent variables over the Galois field GF(p)
#



###
r=2
#
p0=2
p1=50
#
for p in range(p0,p1+1):
    if is_prime(p):
        CheckGlynnDirect(p,r)
#



###
r=3
#
p0=2
p1=11
#
# p1=13 ===> an hour
#
for p in range(p0,p1+1):
    if is_prime(p):
        CheckGlynnDirect(p,r)
#



###
r=4
#
p0=2
p1=3
#
for p in range(p0,p1+1):
    if is_prime(p):
        CheckGlynnDirect(p,r)
#



################################################################################
#
# CheckGlynnRandom(p,r,Fdeg,HMT)
#
################################################################################



#
# This checks
#
# G^e (A) = det A^(p-1-r ehat) G^ehat (Ahat)
#
# for random a_{i,j} in GF(p^Fdeg) HMT times
#



###
r=2
#
p0=2
p1=100
#
Fdeg=2
HMT=10
#
for p in range(p0,p1+1):
    if is_prime(p):
        CheckGlynnRandom(p,r,Fdeg,HMT)
#



###
r=3
#
p0=2
p1=31
#
Fdeg=2
HMT=10
#
for p in range(p0,p1+1):
    if is_prime(p):
        CheckGlynnRandom(p,r,Fdeg,HMT)
#



###
r=4
#
p0=2
p1=17
#
Fdeg=2
HMT=10
#
for p in range(p0,p1+1):
    if is_prime(p):
        CheckGlynnRandom(p,r,Fdeg,HMT)
#



###
r=5
#
p0=2
p1=7
#
Fdeg=2
HMT=10
#
for p in range(p0,p1+1):
    if is_prime(p):
        CheckGlynnRandom(p,r,Fdeg,HMT)
#



#
# end of file
#
