#!/usr/bin/env python3
"""Reference CPU implementation of the finite inverse-certification renderer.

This script implements the certification logic used for the parameter-plane
figures: the marked point z0=2c is pulled back by the inverse branches
    g_t(z)=c(z-t),  t in A_N={-N+1,-N+3,...,N-1}.
A finite trap hit certifies membership; complete exhaustion of the enclosure-
admissible tree certifies non-membership.  The formulas are those of the
canonical trap/enclosure in the manuscript and Algorithm 4.1 of the companion
finite-capture paper.

The image produced here is a small CPU reference rendering of the n=3,4,5
classification layer.  The WebGL rendering at complextrees.com/collinear uses
the same inverse-tree tests together with additional display palettes and chart
overlays.
"""
from __future__ import annotations
import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
from PIL import Image, ImageDraw


def base_words(n: int):
    a = 2 * (n - 1)
    b = 2 * (n - 2)
    d1 = [0,-a,-a,a,a,-a,-a,0,a,b,-a,-a,2,a,a,-a,-a,-a]
    d2 = [0,-a,-a,a,a,-a,-a,0,a,a,-a,0,a,0,-a,-a,a,0]
    d3 = [0,-a,-a,a,a,-a,-a,0,a,a,-a,0,a,0,-a,-b,a,a]
    d4 = [0,-a,-a,a,a,-a,-a,0,a,b,-a,-a,2,a,a,-b,-a,0]
    w1 = [(x + z) // 2 for x, z in zip(d1, d3)]
    return d1, d2, d3, d4, w1


def witness_root(n: int) -> complex:
    """Return the unique root of W_{w_1} in the witness box B_n."""
    *_, w1 = base_words(n)
    coeff = [2] + [-x for x in w1]
    roots = np.roots(coeff)
    y0 = math.sqrt(n)
    candidates = [z for z in roots if 0.25 < z.real < 0.5 and y0 < z.imag < y0 + 0.125]
    if len(candidates) != 1:
        raise RuntimeError(f"expected one witness-box root for n={n}, found {len(candidates)}")
    return complex(candidates[0])


def enclosure_vertical_bound(c: complex, N: int, terms: int = 80) -> float:
    """Certified upper bound for V_E(c,N) from a finite sum plus a geometric tail."""
    r = abs(c)
    q = 1.0 / r
    z = 1.0 / c
    p = z
    total = 0.0
    for _ in range(terms):
        total += abs(p.imag)
        p *= z
    tail = q ** (terms + 1) / (1.0 - q)
    return (N - 1) * (total + tail)


@dataclass
class Verdict:
    code: int       # 0 unresolved, 1 interior, 2 exterior
    depth: int
    nodes: int


def classify_center(c: complex, n: int, max_depth: int = 22, max_nodes: int = 200000) -> Verdict:
    """Finite inverse-tree certification at a pixel centre."""
    if abs(c) <= 1 or c.imag <= 0:
        return Verdict(2, 0, 0)
    N = 2 * n - 1
    a = N - 1
    digits = range(-a, a + 1, 2)
    x, y = c.real, c.imag
    rho2 = abs(c) ** 2
    Vtrap = (N - 2 * x) * y / rho2
    Strap = N * y

    def in_trap(z: complex) -> bool:
        return abs(z.imag) < Vtrap and abs((c * z).imag) < Strap

    VE = enclosure_vertical_bound(c, N)
    SE = (N - 1) * y / abs(c) + VE / abs(c)
    enc_slanted = abs(c) * SE

    def in_enclosure(z: complex) -> bool:
        return abs(z.imag) <= VE and abs((c * z).imag) <= enc_slanted

    z0 = 2 * c
    if not in_enclosure(z0):
        return Verdict(2, 0, 0)
    if in_trap(z0):
        return Verdict(1, 0, 1)

    nodes = [z0]
    for depth in range(1, max_depth + 1):
        nxt: List[complex] = []
        for z in nodes:
            # The production renderer uses the vertical digit window from Prop. 4.13.
            # Enumerating all digits gives the same mathematical verdict and is simpler
            # for this reference implementation.
            for t in digits:
                zz = c * (z - t)
                if in_trap(zz):
                    return Verdict(1, depth, len(nodes))
                if in_enclosure(zz):
                    nxt.append(zz)
                    if len(nxt) > max_nodes:
                        return Verdict(0, depth, len(nxt))
        if not nxt:
            return Verdict(2, depth, 0)
        nodes = nxt
    return Verdict(0, max_depth, len(nodes))


def render_panel(n: int, width: int, height: int, scale: float, max_depth: int):
    c0 = witness_root(n)
    centre = c0
    view_w = scale
    view_h = scale * height / width
    pixels = np.zeros((height, width, 3), dtype=np.uint8) + 150
    counts: Dict[str, int] = {"interior": 0, "exterior": 0, "unresolved": 0}
    max_seen_depth = 0
    for j in range(height):
        y = centre.imag + view_h / 2 - (j + 0.5) * view_h / height
        for i in range(width):
            x = centre.real - view_w / 2 + (i + 0.5) * view_w / width
            v = classify_center(complex(x, y), n, max_depth=max_depth)
            max_seen_depth = max(max_seen_depth, v.depth)
            if v.code == 1:
                counts["interior"] += 1
                shade = max(80, 235 - 7 * min(v.depth, 20))
                pixels[j, i] = (shade, shade, shade)
            elif v.code == 2:
                counts["exterior"] += 1
                shade = min(150, 45 + 7 * min(v.depth, 20))
                pixels[j, i] = (shade, shade, shade)
            else:
                counts["unresolved"] += 1
                pixels[j, i] = (125, 125, 125)
    im = Image.fromarray(pixels)
    draw = ImageDraw.Draw(im)
    px = int((c0.real - (centre.real - view_w / 2)) / view_w * width)
    py = int(((centre.imag + view_h / 2) - c0.imag) / view_h * height)
    draw.ellipse((px-4, py-4, px+4, py+4), outline=(240, 0, 0), width=2)
    return im, {"n": n, "witness_root": [c0.real, c0.imag], "counts": counts, "max_depth_seen": max_seen_depth}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", default="n345_reference_render.png")
    ap.add_argument("--log", default="n345_reference_render_log.json")
    ap.add_argument("--width", type=int, default=240)
    ap.add_argument("--height", type=int, default=190)
    ap.add_argument("--scale", type=float, default=0.10)
    ap.add_argument("--max-depth", type=int, default=22)
    args = ap.parse_args()

    panels = []
    log = []
    for n in (3, 4, 5):
        im, rec = render_panel(n, args.width, args.height, args.scale, args.max_depth)
        panels.append(im)
        log.append(rec)
    gap = 30
    row = Image.new("RGB", (args.width * 3 + gap * 2, args.height), (255, 255, 255))
    for idx, im in enumerate(panels):
        row.paste(im, (idx * (args.width + gap), 0))
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    row.save(args.output)
    Path(args.log).write_text(json.dumps(log, indent=2))
    print(json.dumps(log, indent=2))


if __name__ == "__main__":
    main()
