# Supplementary verification and rendering material

This directory accompanies the manuscript. It contains coefficient data for the finite algebraic verification layer and reference material for the finite-capture renderings.

Contents:

- `S1_H1_coefficient_data.txt` and `S1_H1_coefficient_data.json`: coefficient data for the H1 edge and Rouché-margin polynomials.
- `S2_H2_H4_certificate_index.md`: index of the H2--H4 verification objects described in Appendices C and D of the manuscript.
- `certified_renderer/`: compact CPU reference implementation of the finite inverse-tree certification rule. It classifies closed pixel boxes by outward interval arithmetic and writes a CSV certificate label for each pixel.
- `certified_render_reference.py`: top-level reference renderer driver for the n=3,4,5 source panels.
- `n345_reference_render.png` and `n345_reference_render_log.json`: reference finite-capture render and metadata for the n=3,4,5 source panels.

The parameter-space figures in the paper are generated from the finite-capture rule stated in Appendix E of the manuscript. The formal proof of the holes uses the algebraic certificates in Appendices C and D, not visual inspection of the figures.
