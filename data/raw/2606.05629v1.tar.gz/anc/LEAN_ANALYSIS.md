# Lean Formalization Analysis: `R(B₈, B₁₀) = 37`

## Verdict

The Lean formalization completes the upper-bound argument from `RamseyProof/main.tex` end-to-end. The project builds cleanly under `lake build` (Lean 4.29.1, mathlib v4.29.1), and `#print axioms` confirms the main theorem `RamseyLean.Actual.b8b10_upper_bound_actual` depends only on:

- `propext`, `Classical.choice`, `Quot.sound` (standard);
- five auto-generated `native_decide` axioms (one for `#orderedTriples = 46620`, four for trivial `ZMod 41` arithmetic facts).

No `sorry`, no `admit`, no project-level `axiom` declarations.

## What the Lean theorem says vs. the LaTeX claim

LaTeX `Theorem 1` (`main.tex:92`) claims `R(B₈, B₁₀) = 37`. The paper proves only the upper bound; the lower bound `R(B₈, B₁₀) ≥ 37` is cited from Lidický–McKinley–Pfender–Van Overberghe (`main.tex:60–68`).

Lean `b8b10_upper_bound_actual` (`RamseyLean/Actual.lean:1188`) has type `B8B10UpperBoundStatement`, defined in `RamseyLean/Basic.lean:71`:

```lean
∀ (G : SimpleGraph (Fin 37)) [DecidableRel G.Adj],
  ContainsBook 8 G ∨ ContainsBook 10 Gᶜ
```

This is exactly the upper-bound reformulation given in the paper at `main.tex:97`: *every graph on 37 vertices contains B₈ or its complement contains B₁₀*.

So **the Lean theorem corresponds to precisely the half of `R(B₈, B₁₀) = 37` that the paper proves itself.**

## Step-by-step correspondence

| LaTeX step (Section 2) | Lean theorem / definition | File:line |
|---|---|---|
| Definition of `B_t` as `t` triangles sharing edge `uv` (`main.tex:55`) | `bookGraph n : SimpleGraph (Fin (n+2))` with `Adj x y ↔ x ≠ y ∧ (x.val ≤ 1 ∨ y.val ≤ 1)` | `Basic.lean:45` |
| "G contains a copy of B_n" | `ContainsBook n G := Nonempty (SimpleGraph.Copy (bookGraph n) G)` | `Basic.lean:57` |
| `c_G(u,v) ≤ 7` on edges of G | `edgeBookCapB8_of_not_containsBook` | `Actual.lean:324` |
| `c_{Ḡ}(u,v) ≤ 9` on edges of Ḡ | `complementBookCapB10_of_not_containsBook_compl` | `Actual.lean:332` |
| Combinatorial extraction of `B_n` from a large codegree | `containsBook_of_le_commonNeighborCount` (constructs the explicit injective `Hom` from `bookGraph n` into `G`) | `Actual.lean:151` |
| Goodman's identity (eq. `goodman`) | `goodman_ordered` and `goodman_actual` (ordered-triple form, using `#orderedTriples = 46620 = 37·36·35` and three permutation symmetries) | `Actual.lean:679, 736` |
| `3T ≤ 7e`, `3T̄ ≤ 9ē` (eq. `trianglecaps`) | `orientedCommonNeighborSum_le_of_edgeBookCapB8` and complement version | `Actual.lean:461, 474` |
| Quadratic `f(d) = 106d − 3d²` has integer max `936` at `d = 18` | `localQuadraticInt_le_936`, `localQuadraticInt_eq_936_iff` (proved by `decide`) | `Actual.lean:99, 102` |
| Quadratic inequality `Σ f(d(x)) ≥ 34632` (eq. `quadraticineq`) | `quadratic_ineq_of_actual_caps` | `Actual.lean:788` |
| Equality propagation forces 18-regularity | `regular_of_actual_caps` (via `regular_of_quadratic_ineq_int`) | `Actual.lean:812, 116` |
| `c_G(u,v) = 7` on edges (eq. `lambda`) | `commonNeighborCount_eq_7_of_actual_caps` | `Actual.lean:868` |
| `c_{Ḡ}(u,v) = 9` on non-edges (eq. `cn`) | `commonNeighborCount_compl_eq_9_of_actual_caps` | `Actual.lean:909` |
| `c_G(u,v) = 10` on non-edges (eq. `mu`) | `commonNeighborCount_eq_10_of_not_adj_of_compl_eq_9` | `Actual.lean:987` |
| Witness is SRG(37, 18, 7, 10) | `isSRGWith37_18_7_10_of_actual_caps` (mathlib's `IsSRGWith`) | `Actual.lean:997` |
| Spectral contradiction for SRG(37, 18, 7, 10) | `no_isSRGWith37_18_7_10` | `Actual.lean:1032` |
| "No such 37-vertex graph exists" | `no_counterexample_of_actual_formalization` | `Actual.lean:1179` |
| Theorem 1 (upper bound) | `b8b10_upper_bound_actual : B8B10UpperBoundStatement` | `Actual.lean:1188` |

## Where Lean diverges from the paper

### 1. Technique used for the spectral step

The **paper** argues that the two irrational eigenvalues `(-3 ± √41)/2` of the SRG adjacency matrix must occur with equal multiplicity (rational characteristic polynomial), so each occurs `18` times in the 36-dimensional space `1⊥`. Then `tr(A) = 18 + 18·(-3) = -36 ≠ 0` contradicts `tr(A) = 0`.

The **Lean proof** works over `ZMod 41` (where `41 ≡ 0`, so `√41 = 0`):
- Let `A` be the adjacency matrix over `ZMod 41`, `J` the all-ones matrix, `B := 2A + 3I`.
- Compute `B² = -J` (i.e. `40·J` mod 41) using `A² = 8I − 3A + 10J`.
- Let `N := B − 21J`. Show `N² = 0`, using `B·J = J·B = 39·J` and `J² = 37·J`.
- `N` is nilpotent ⇒ `tr(N) = 0`.
- But `tr(N) = tr(B) − 21·37 = 3·37 − 777 = −666 ≡ 31 (mod 41) ≠ 0`.

This is the same obstruction (the discriminant `41` blocking integer eigenvalues), repackaged as a nilpotence + trace argument over `𝔽₄₁`. It avoids the multiplicity/dimension bookkeeping of the paper at the cost of a small `ZMod 41` computation.

### 2. Goodman's identity is reproved from scratch

The paper cites Goodman 1959 (`main.tex:288`). The Lean proof gives a self-contained derivation via counting ordered triples and three symmetry equivalences (`swapSecondThird`, `cycleLeft`, `swapFirstSecond`, `rotateRight`), then performing the algebraic combination — see `goodman_ordered` (`Actual.lean:679`). The combinatorial heart is `#orderedTriples = 46620`, proved by `native_decide`.

### 3. The `Basic.lean` "certificate" pass is superseded

`Basic.lean` contains a weaker first pass: `b8b10_upper_bound_formalized` takes Goodman counting and the SRG spectral fact as *certificate inputs* rather than proving them. The comments at `Basic.lean:14–34` are clear about this. It is fully **superseded** by `Actual.lean`, which discharges those inputs from first principles. A reader scanning only `Basic.lean` could be misled into thinking the proof is partial.

## What the Lean files do *not* prove

- **The lower bound** `R(B₈, B₁₀) ≥ 37` is not formalized. `Basic.lean:33–34` explicitly notes this; the paper also takes it from external literature.
- **No Ramsey-number object.** The Lean codebase never defines `R(·,·)` and never states `R(B₈, B₁₀) = 37` as a Lean theorem. The result is expressed entirely in terms of `SimpleGraph.Copy` and complements.
- **Equality `c_G(u,v) = 7` is proved, but the SRG construction goes directly from caps + regularity to `IsSRGWith` without exposing the intermediate `λ = 7`, `μ = 10` as separate named lemmas.** (They are present internally — `commonNeighborCount_eq_7_of_actual_caps`, `commonNeighborCount_eq_10_of_not_adj_of_compl_eq_9` — but bundled into `isSRGWith37_18_7_10_of_actual_caps`.)

## Caveats worth flagging in the paper

1. **`main.tex:261`** states *"formalization in Lean for this particular proof did not work out of the box."* Given that `RamseyLean/Actual.lean` does formalize the upper bound end-to-end, this sentence is out of date.
2. **`main.tex:263`** contains a literal TODO comment `% GIVE FIELD + PROGRESS SUMMARY.` — the formalization paragraph should be updated to reference `b8b10_upper_bound_actual` and describe the `ZMod 41` shortcut.
3. The Lean book-graph definition uses `SimpleGraph.Copy` (an injective hom), which is the right notion for Ramsey containment — matching the paper's informal "contains a copy of `B_n`" but worth noting it is *not* induced subgraph containment.

## Build / verification commands used

```bash
lake build RamseyLean.Actual       # builds cleanly (1771 jobs)
grep -rn 'sorry\|admit\|axiom '    # zero matches in project Lean files
lake env lean CheckAxioms.lean     # #print axioms shows only standard + native_decide
```

## Bottom line

The Lean code proves precisely the graph-theoretic upper bound that the LaTeX paper proves, completely and without unverified inputs. The Lean spectral step uses a slicker `ZMod 41` argument than the paper's eigenvalue-multiplicity argument, but the underlying mathematical obstruction is the same. Neither the paper nor the Lean code formalizes the cited lower bound, so neither establishes `R(B₈, B₁₀) = 37` in a single self-contained artifact — both rely on `[LMPV]` for the matching construction.
